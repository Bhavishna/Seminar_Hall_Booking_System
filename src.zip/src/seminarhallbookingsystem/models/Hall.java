/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seminarhallbookingsystem.models;

/**
 *
 * @author bhavi
 */
public class Hall {
    private int hallId;
    private String hallName;
    private int capacity;
    private String description;
    private String facilities;
    private String imagePath;  // New field for image path
    
    // Default constructor
    public Hall() {
    }
    
    // Constructor without ID (for creating new halls)
    public Hall(String hallName, int capacity, String description, String facilities) {
        this.hallName = hallName;
        this.capacity = capacity;
        this.description = description;
        this.facilities = facilities;
    }
    
    // Constructor without ID but with image path
    public Hall(String hallName, int capacity, String description, String facilities, String imagePath) {
        this.hallName = hallName;
        this.capacity = capacity;
        this.description = description;
        this.facilities = facilities;
        this.imagePath = imagePath;
    }
    
    // Constructor with all fields
    public Hall(int hallId, String hallName, int capacity, String description, String facilities, String imagePath) {
        this.hallId = hallId;
        this.hallName = hallName;
        this.capacity = capacity;
        this.description = description;
        this.facilities = facilities;
        this.imagePath = imagePath;
    }
    
    // Getters and setters
    public int getHallId() {
        return hallId;
    }
    
    public void setHallId(int hallId) {
        this.hallId = hallId;
    }
    
    public String getHallName() {
        return hallName;
    }
    
    public void setHallName(String hallName) {
        this.hallName = hallName;
    }
    
    public int getCapacity() {
        return capacity;
    }
    
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getFacilities() {
        return facilities;
    }
    
    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }
    
    public String getImagePath() {
        return imagePath;
    }
    
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    
    public boolean hasImage() {
        return imagePath != null && !imagePath.isEmpty();
    }
    
    @Override
    public String toString() {
        return hallName + " (Capacity: " + capacity + ")";
    }
}