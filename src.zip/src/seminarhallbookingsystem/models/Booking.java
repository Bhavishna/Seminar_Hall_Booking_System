package seminarhallbookingsystem.models;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

/**
 *
 * @author bhavi
 */
public class Booking {
    private int bookingId;
    private int hallId;
    private int userId;
    private String eventName;
    private String eventDescription;
    private Date bookingDate;
    private Time startTime;
    private Time endTime;
    private String status;
    private String declineReason;
    private Timestamp createdAt;
    
    // Display fields (not stored in database directly)
    private String hallName;
    private String userName;
    
    // Flag to track whether booking has feedback
    private boolean hasFeedback;
    
    // Default constructor
    public Booking() {
    }
    
    // Constructor for creating new bookings
    public Booking(int hallId, int userId, String eventName, String eventDescription, 
                  Date bookingDate, Time startTime, Time endTime) {
        this.hallId = hallId;
        this.userId = userId;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.bookingDate = bookingDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = "pending";
    }
    
    // Constructor with all fields
    public Booking(int bookingId, int hallId, int userId, String eventName, 
                  String eventDescription, Date bookingDate, Time startTime, 
                  Time endTime, String status, String declineReason, 
                  Timestamp createdAt, String hallName, String userName) {
        this.bookingId = bookingId;
        this.hallId = hallId;
        this.userId = userId;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.bookingDate = bookingDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
        this.declineReason = declineReason;
        this.createdAt = createdAt;
        this.hallName = hallName;
        this.userName = userName;
    }

    // Getters and setters
    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public int getHallId() {
        return hallId;
    }

    public void setHallId(int hallId) {
        this.hallId = hallId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    public Time getStartTime() {
        return startTime;
    }

    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDeclineReason() {
        return declineReason;
    }

    public void setDeclineReason(String declineReason) {
        this.declineReason = declineReason;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getHallName() {
        return hallName;
    }

    public void setHallName(String hallName) {
        this.hallName = hallName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public boolean getHasFeedback() {
        return hasFeedback;
    }

    public void setHasFeedback(boolean hasFeedback) {
        this.hasFeedback = hasFeedback;
    }
    
    // Check if booking is eligible for feedback (approved and past date)
    public boolean isEligibleForFeedback() {
        if (!"approved".equals(status)) {
            return false;
        }
        
        java.util.Date today = new java.util.Date();
        return bookingDate.before(new java.sql.Date(today.getTime()));
    }
    
    @Override
    public String toString() {
        return "Booking #" + bookingId + ": " + eventName + " at " + hallName + 
                " on " + bookingDate + " from " + startTime + " to " + endTime + 
                " [Status: " + status + "]";
    }
}
