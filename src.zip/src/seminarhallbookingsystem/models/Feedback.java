package seminarhallbookingsystem.models;

import java.sql.Timestamp;

public class Feedback {
    private int feedbackId;
    private int bookingId;
    private int userId;
    private int hallId;
    private int rating;
    private String comment;
    private Timestamp createdAt;
    
    // Additional fields for displaying feedback
    private String userName;
    private String hallName;
    private String eventName;
    
    // Default constructor
    public Feedback() {
    }
    
    // Constructor for creating new feedback
    public Feedback(int bookingId, int userId, int hallId, int rating, String comment) {
        this.bookingId = bookingId;
        this.userId = userId;
        this.hallId = hallId;
        this.rating = rating;
        this.comment = comment;
    }
    
    // Constructor with all fields
    public Feedback(int feedbackId, int bookingId, int userId, int hallId, int rating, 
                   String comment, Timestamp createdAt) {
        this.feedbackId = feedbackId;
        this.bookingId = bookingId;
        this.userId = userId;
        this.hallId = hallId;
        this.rating = rating;
        this.comment = comment;
        this.createdAt = createdAt;
    }
    
    // Getters and setters
    public int getFeedbackId() {
        return feedbackId;
    }
    
    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }
    
    public int getUserId() {
        return userId;
    }
    
    public void setUserId(int userId) {
        this.userId = userId;
    }
    
    public int getHallId() {
        return hallId;
    }
    
    public void setHallId(int hallId) {
        this.hallId = hallId;
    }
    
    public int getRating() {
        return rating;
    }
    
    public void setRating(int rating) {
        this.rating = rating;
    }
    
    public String getComment() {
        return comment;
    }
    
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getUserName() {
        return userName;
    }
    
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getHallName() {
        return hallName;
    }
    
    public void setHallName(String hallName) {
        this.hallName = hallName;
    }
    
    public String getEventName() {
        return eventName;
    }
    
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
    
    // Get star rating as a string of stars
    public String getStarRating() {
        StringBuilder stars = new StringBuilder();
        for (int i = 0; i < rating; i++) {
            stars.append("★");
        }
        for (int i = rating; i < 5; i++) {
            stars.append("☆");
        }
        return stars.toString();
    }
}
