package seminarhallbookingsystem.dao;

import seminarhallbookingsystem.models.Booking;
import seminarhallbookingsystem.models.Hall;
import seminarhallbookingsystem.util.DatabaseConnection;

import java.sql.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * Data access object for analytics operations
 */
public class AnalyticsDAO {
    
    /**
     * Get hall usage statistics - which halls are used most frequently
     * @return Map with hall name as key and usage count as value, sorted by count (descending)
     */
    public Map<String, Integer> getHallUsageStatistics() {
        Map<String, Integer> hallUsage = new LinkedHashMap<>(); // Preserves insertion order
        
        String query = "SELECT h.hall_name, COUNT(b.booking_id) as booking_count " +
                      "FROM halls h " +
                      "LEFT JOIN bookings b ON h.hall_id = b.hall_id " +
                      "WHERE b.status = 'approved' OR b.status IS NULL " +
                      "GROUP BY h.hall_id, h.hall_name " +
                      "ORDER BY booking_count DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                String hallName = rs.getString("hall_name");
                int count = rs.getInt("booking_count");
                hallUsage.put(hallName, count);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting hall usage statistics: " + e.getMessage());
            e.printStackTrace();
        }
        
        return hallUsage;
    }
    
    /**
     * Get bookings by date range
     * @param startDate Start date (inclusive)
     * @param endDate End date (inclusive)
     * @return List of bookings within the date range
     */
    public List<Booking> getBookingsByDateRange(java.sql.Date startDate, java.sql.Date endDate) {
        List<Booking> bookings = new ArrayList<>();
        
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "WHERE b.booking_date BETWEEN ? AND ? " +
                      "ORDER BY b.booking_date, b.start_time";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setDate(1, startDate);
            stmt.setDate(2, endDate);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.setBookingId(rs.getInt("booking_id"));
                    booking.setHallId(rs.getInt("hall_id"));
                    booking.setUserId(rs.getInt("user_id"));
                    booking.setEventName(rs.getString("event_name"));
                    booking.setEventDescription(rs.getString("event_description"));
                    booking.setBookingDate(rs.getDate("booking_date"));
                    booking.setStartTime(rs.getTime("start_time"));
                    booking.setEndTime(rs.getTime("end_time"));
                    booking.setStatus(rs.getString("status"));
                    booking.setCreatedAt(rs.getTimestamp("created_at"));
                    booking.setHallName(rs.getString("hall_name"));
                    booking.setUserName(rs.getString("user_name"));
                    bookings.add(booking);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting bookings by date range: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }
    
    /**
     * Get bookings by hall
     * @param hallId The hall ID to filter by
     * @return List of bookings for the specified hall
     */
    public List<Booking> getBookingsByHall(int hallId) {
        List<Booking> bookings = new ArrayList<>();
        
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "WHERE b.hall_id = ? " +
                      "ORDER BY b.booking_date, b.start_time";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, hallId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.setBookingId(rs.getInt("booking_id"));
                    booking.setHallId(rs.getInt("hall_id"));
                    booking.setUserId(rs.getInt("user_id"));
                    booking.setEventName(rs.getString("event_name"));
                    booking.setEventDescription(rs.getString("event_description"));
                    booking.setBookingDate(rs.getDate("booking_date"));
                    booking.setStartTime(rs.getTime("start_time"));
                    booking.setEndTime(rs.getTime("end_time"));
                    booking.setStatus(rs.getString("status"));
                    booking.setCreatedAt(rs.getTimestamp("created_at"));
                    booking.setHallName(rs.getString("hall_name"));
                    booking.setUserName(rs.getString("user_name"));
                    bookings.add(booking);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting bookings by hall: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }
    
    /**
     * Get bookings by user
     * @param userId The user ID to filter by
     * @return List of bookings made by the specified user
     */
    public List<Booking> getBookingsByUser(int userId) {
        List<Booking> bookings = new ArrayList<>();
        
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "WHERE b.user_id = ? " +
                      "ORDER BY b.booking_date, b.start_time";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.setBookingId(rs.getInt("booking_id"));
                    booking.setHallId(rs.getInt("hall_id"));
                    booking.setUserId(rs.getInt("user_id"));
                    booking.setEventName(rs.getString("event_name"));
                    booking.setEventDescription(rs.getString("event_description"));
                    booking.setBookingDate(rs.getDate("booking_date"));
                    booking.setStartTime(rs.getTime("start_time"));
                    booking.setEndTime(rs.getTime("end_time"));
                    booking.setStatus(rs.getString("status"));
                    booking.setCreatedAt(rs.getTimestamp("created_at"));
                    booking.setHallName(rs.getString("hall_name"));
                    booking.setUserName(rs.getString("user_name"));
                    bookings.add(booking);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting bookings by user: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }
    
    /**
     * Get usage data by day of week
     * @return Map with day of week as key and usage count as value
     */
    public Map<String, Integer> getUsageByDayOfWeek() {
        Map<String, Integer> usageByDay = new LinkedHashMap<>();
        
        // Initialize with all days of week
        for (int i = 1; i <= 7; i++) {
            DayOfWeek day = DayOfWeek.of(i);
            usageByDay.put(day.getDisplayName(TextStyle.FULL, Locale.getDefault()), 0);
        }
        
        String query = "SELECT DAYOFWEEK(booking_date) as day_of_week, COUNT(*) as booking_count " +
                      "FROM bookings " +
                      "WHERE status = 'approved' " +
                      "GROUP BY DAYOFWEEK(booking_date) " +
                      "ORDER BY DAYOFWEEK(booking_date)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                int dayNumber = rs.getInt("day_of_week");
                int count = rs.getInt("booking_count");
                
                // Convert from SQL's day of week (1=Sunday) to Java's (1=Monday)
                int javaDayNumber = dayNumber == 1 ? 7 : dayNumber - 1;
                
                DayOfWeek day = DayOfWeek.of(javaDayNumber);
                String dayName = day.getDisplayName(TextStyle.FULL, Locale.getDefault());
                
                usageByDay.put(dayName, count);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting usage by day of week: " + e.getMessage());
            e.printStackTrace();
        }
        
        return usageByDay;
    }
    
    /**
     * Get usage data by time of day (hours)
     * @return Map with hour as key and usage count as value
     */
    public Map<Integer, Integer> getUsageByTimeOfDay() {
        Map<Integer, Integer> usageByHour = new TreeMap<>(); // Keeps keys sorted
        
        // Initialize with all hours
        for (int i = 0; i < 24; i++) {
            usageByHour.put(i, 0);
        }
        
        String query = "SELECT HOUR(start_time) as hour, COUNT(*) as booking_count " +
                      "FROM bookings " +
                      "WHERE status = 'approved' " +
                      "GROUP BY HOUR(start_time) " +
                      "ORDER BY HOUR(start_time)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                int hour = rs.getInt("hour");
                int count = rs.getInt("booking_count");
                usageByHour.put(hour, count);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting usage by time of day: " + e.getMessage());
            e.printStackTrace();
        }
        
        return usageByHour;
    }
    
    /**
     * Get monthly booking statistics for the current year
     * @return Map with month name as key and booking count as value
     */
    public Map<String, Integer> getMonthlyBookingStats() {
        Map<String, Integer> monthlyStats = new LinkedHashMap<>();
        
        // Month names
        String[] months = {"January", "February", "March", "April", "May", "June", 
                          "July", "August", "September", "October", "November", "December"};
        
        // Initialize with all months
        for (String month : months) {
            monthlyStats.put(month, 0);
        }
        
        // Get current year
        int currentYear = LocalDate.now().getYear();
        
        String query = "SELECT MONTH(booking_date) as month, COUNT(*) as booking_count " +
                      "FROM bookings " +
                      "WHERE YEAR(booking_date) = ? " +
                      "AND status = 'approved' " +
                      "GROUP BY MONTH(booking_date) " +
                      "ORDER BY MONTH(booking_date)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, currentYear);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int month = rs.getInt("month") - 1; // SQL months are 1-based
                    int count = rs.getInt("booking_count");
                    monthlyStats.put(months[month], count);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting monthly booking stats: " + e.getMessage());
            e.printStackTrace();
        }
        
        return monthlyStats;
    }
}
