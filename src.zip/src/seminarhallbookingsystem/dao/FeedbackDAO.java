package seminarhallbookingsystem.dao;

import seminarhallbookingsystem.models.Feedback;
import seminarhallbookingsystem.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FeedbackDAO {
    
    // Create new feedback
    public boolean createFeedback(Feedback feedback) {
        String query = "INSERT INTO feedback (booking_id, user_id, hall_id, rating, comment) " +
                      "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, feedback.getBookingId());
            stmt.setInt(2, feedback.getUserId());
            stmt.setInt(3, feedback.getHallId());
            stmt.setInt(4, feedback.getRating());
            stmt.setString(5, feedback.getComment());
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the auto-generated ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    feedback.setFeedbackId(rs.getInt(1));
                }
                return true;
            }
            return false;
            
        } catch (SQLException e) {
            System.err.println("Error creating feedback: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Get feedback by ID
    public Feedback getFeedbackById(int feedbackId) {
        String query = "SELECT f.*, u.full_name AS user_name, h.hall_name, b.event_name " +
                      "FROM feedback f " +
                      "JOIN users u ON f.user_id = u.user_id " +
                      "JOIN halls h ON f.hall_id = h.hall_id " +
                      "JOIN bookings b ON f.booking_id = b.booking_id " +
                      "WHERE f.feedback_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, feedbackId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToFeedback(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving feedback by ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    // Get feedback by booking ID
    public Feedback getFeedbackByBookingId(int bookingId) {
        String query = "SELECT f.*, u.full_name AS user_name, h.hall_name, b.event_name " +
                      "FROM feedback f " +
                      "JOIN users u ON f.user_id = u.user_id " +
                      "JOIN halls h ON f.hall_id = h.hall_id " +
                      "JOIN bookings b ON f.booking_id = b.booking_id " +
                      "WHERE f.booking_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, bookingId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToFeedback(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving feedback by booking ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    // Get all feedback for a hall
    public List<Feedback> getFeedbackByHallId(int hallId) {
        List<Feedback> feedbackList = new ArrayList<>();
        String query = "SELECT f.*, u.full_name AS user_name, h.hall_name, b.event_name " +
                      "FROM feedback f " +
                      "JOIN users u ON f.user_id = u.user_id " +
                      "JOIN halls h ON f.hall_id = h.hall_id " +
                      "JOIN bookings b ON f.booking_id = b.booking_id " +
                      "WHERE f.hall_id = ? " +
                      "ORDER BY f.created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, hallId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    feedbackList.add(mapResultSetToFeedback(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving feedback by hall ID: " + e.getMessage());
            e.printStackTrace();
        }
        return feedbackList;
    }
    
    // Get all feedback by user ID
    public List<Feedback> getFeedbackByUserId(int userId) {
        List<Feedback> feedbackList = new ArrayList<>();
        String query = "SELECT f.*, u.full_name AS user_name, h.hall_name, b.event_name " +
                      "FROM feedback f " +
                      "JOIN users u ON f.user_id = u.user_id " +
                      "JOIN halls h ON f.hall_id = h.hall_id " +
                      "JOIN bookings b ON f.booking_id = b.booking_id " +
                      "WHERE f.user_id = ? " +
                      "ORDER BY f.created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    feedbackList.add(mapResultSetToFeedback(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving feedback by user ID: " + e.getMessage());
            e.printStackTrace();
        }
        return feedbackList;
    }
    
    // Get all feedback
    public List<Feedback> getAllFeedback() {
        List<Feedback> feedbackList = new ArrayList<>();
        String query = "SELECT f.*, u.full_name AS user_name, h.hall_name, b.event_name " +
                      "FROM feedback f " +
                      "JOIN users u ON f.user_id = u.user_id " +
                      "JOIN halls h ON f.hall_id = h.hall_id " +
                      "JOIN bookings b ON f.booking_id = b.booking_id " +
                      "ORDER BY f.created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                feedbackList.add(mapResultSetToFeedback(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving all feedback: " + e.getMessage());
            e.printStackTrace();
        }
        return feedbackList;
    }
    
    // Get average rating for each hall
    public Map<Integer, Double> getAverageRatingsByHall() {
        Map<Integer, Double> ratings = new HashMap<>();
        String query = "SELECT hall_id, AVG(rating) as avg_rating FROM feedback GROUP BY hall_id";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                int hallId = rs.getInt("hall_id");
                double avgRating = rs.getDouble("avg_rating");
                ratings.put(hallId, avgRating);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving average ratings: " + e.getMessage());
            e.printStackTrace();
        }
        return ratings;
    }
    
    // Update existing feedback
    public boolean updateFeedback(Feedback feedback) {
        String query = "UPDATE feedback SET rating = ?, comment = ? WHERE feedback_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, feedback.getRating());
            stmt.setString(2, feedback.getComment());
            stmt.setInt(3, feedback.getFeedbackId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating feedback: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Delete feedback
    public boolean deleteFeedback(int feedbackId) {
        String query = "DELETE FROM feedback WHERE feedback_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, feedbackId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting feedback: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Check if a booking has feedback
    public boolean hasBookingFeedback(int bookingId) {
        String query = "SELECT COUNT(*) FROM feedback WHERE booking_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, bookingId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error checking for booking feedback: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    // Helper method to map ResultSet to Feedback object
    private Feedback mapResultSetToFeedback(ResultSet rs) throws SQLException {
        Feedback feedback = new Feedback();
        feedback.setFeedbackId(rs.getInt("feedback_id"));
        feedback.setBookingId(rs.getInt("booking_id"));
        feedback.setUserId(rs.getInt("user_id"));
        feedback.setHallId(rs.getInt("hall_id"));
        feedback.setRating(rs.getInt("rating"));
        feedback.setComment(rs.getString("comment"));
        feedback.setCreatedAt(rs.getTimestamp("created_at"));
        
        // Additional display fields
        feedback.setUserName(rs.getString("user_name"));
        feedback.setHallName(rs.getString("hall_name"));
        feedback.setEventName(rs.getString("event_name"));
        
        return feedback;
    }
}
