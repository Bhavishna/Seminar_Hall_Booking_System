package seminarhallbookingsystem.dao;

import seminarhallbookingsystem.models.Booking;
import seminarhallbookingsystem.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author bhavi
 */
public class BookingDAO {
    // Create a new booking
    public boolean createBooking(Booking booking) {
        String query = "INSERT INTO bookings (hall_id, user_id, event_name, event_description, booking_date, start_time, end_time, status) " +
                      "VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, booking.getHallId());
            stmt.setInt(2, booking.getUserId());
            stmt.setString(3, booking.getEventName());
            stmt.setString(4, booking.getEventDescription());
            stmt.setDate(5, booking.getBookingDate());
            stmt.setTime(6, booking.getStartTime());
            stmt.setTime(7, booking.getEndTime());
            
            System.out.println("Executing SQL: " + query);
            System.out.println("Parameters: hall_id=" + booking.getHallId() + 
                              ", user_id=" + booking.getUserId() + 
                              ", event=" + booking.getEventName() + 
                              ", date=" + booking.getBookingDate());
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the auto-generated ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    booking.setBookingId(rs.getInt(1));
                }
                return true;
            }
            return false;
            
        } catch (SQLException e) {
            System.err.println("Error creating booking: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Get booking by ID
    public Booking getBookingById(int bookingId) {
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name, " +
                      "(SELECT COUNT(*) FROM feedback f WHERE f.booking_id = b.booking_id) > 0 AS has_feedback " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "WHERE b.booking_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, bookingId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Booking booking = new Booking();
                    booking.setBookingId(rs.getInt("booking_id"));
                    booking.setHallId(rs.getInt("hall_id"));
                    booking.setUserId(rs.getInt("user_id"));
                    booking.setEventName(rs.getString("event_name"));
                    booking.setEventDescription(rs.getString("event_description"));
                    booking.setBookingDate(rs.getDate("booking_date"));
                    booking.setStartTime(rs.getTime("start_time"));
                    booking.setEndTime(rs.getTime("end_time"));
                    booking.setStatus(rs.getString("status"));
                    booking.setDeclineReason(rs.getString("decline_reason"));
                    booking.setCreatedAt(rs.getTimestamp("created_at"));
                    booking.setHallName(rs.getString("hall_name"));
                    booking.setUserName(rs.getString("user_name"));
                    booking.setHasFeedback(rs.getBoolean("has_feedback"));
                    return booking;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving booking: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    // Get bookings by user ID
    public List<Booking> getBookingsByUserId(int userId) {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT b.*, h.hall_name, " +
                      "(SELECT COUNT(*) FROM feedback f WHERE f.booking_id = b.booking_id) > 0 AS has_feedback " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "WHERE b.user_id = ? " +
                      "ORDER BY b.booking_date DESC, b.start_time ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.setBookingId(rs.getInt("booking_id"));
                    booking.setHallId(rs.getInt("hall_id"));
                    booking.setUserId(rs.getInt("user_id"));
                    booking.setEventName(rs.getString("event_name"));
                    booking.setEventDescription(rs.getString("event_description"));
                    booking.setBookingDate(rs.getDate("booking_date"));
                    booking.setStartTime(rs.getTime("start_time"));
                    booking.setEndTime(rs.getTime("end_time"));
                    booking.setStatus(rs.getString("status"));
                    booking.setDeclineReason(rs.getString("decline_reason"));
                    booking.setCreatedAt(rs.getTimestamp("created_at"));
                    booking.setHallName(rs.getString("hall_name"));
                    booking.setHasFeedback(rs.getBoolean("has_feedback"));
                    bookings.add(booking);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving user bookings: " + e.getMessage());
            e.printStackTrace();
        }
        return bookings;
    }
    
    // Get all bookings (for admin)
    public List<Booking> getAllBookings() {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name, " +
                      "(SELECT COUNT(*) FROM feedback f WHERE f.booking_id = b.booking_id) > 0 AS has_feedback " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "ORDER BY b.booking_date DESC, b.start_time ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Booking booking = new Booking();
                booking.setBookingId(rs.getInt("booking_id"));
                booking.setHallId(rs.getInt("hall_id"));
                booking.setUserId(rs.getInt("user_id"));
                booking.setEventName(rs.getString("event_name"));
                booking.setEventDescription(rs.getString("event_description"));
                booking.setBookingDate(rs.getDate("booking_date"));
                booking.setStartTime(rs.getTime("start_time"));
                booking.setEndTime(rs.getTime("end_time"));
                booking.setStatus(rs.getString("status"));
                booking.setDeclineReason(rs.getString("decline_reason"));
                booking.setCreatedAt(rs.getTimestamp("created_at"));
                booking.setHallName(rs.getString("hall_name"));
                booking.setUserName(rs.getString("user_name"));
                booking.setHasFeedback(rs.getBoolean("has_feedback"));
                bookings.add(booking);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving all bookings: " + e.getMessage());
            e.printStackTrace();
        }
        return bookings;
    }
    
    // Get pending bookings (for admin)
    public List<Booking> getPendingBookings() {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name, " +
                      "(SELECT COUNT(*) FROM feedback f WHERE f.booking_id = b.booking_id) > 0 AS has_feedback " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "WHERE b.status = 'pending' " +
                      "ORDER BY b.booking_date ASC, b.start_time ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Booking booking = new Booking();
                booking.setBookingId(rs.getInt("booking_id"));
                booking.setHallId(rs.getInt("hall_id"));
                booking.setUserId(rs.getInt("user_id"));
                booking.setEventName(rs.getString("event_name"));
                booking.setEventDescription(rs.getString("event_description"));
                booking.setBookingDate(rs.getDate("booking_date"));
                booking.setStartTime(rs.getTime("start_time"));
                booking.setEndTime(rs.getTime("end_time"));
                booking.setStatus(rs.getString("status"));
                booking.setDeclineReason(rs.getString("decline_reason"));
                booking.setCreatedAt(rs.getTimestamp("created_at"));
                booking.setHallName(rs.getString("hall_name"));
                booking.setUserName(rs.getString("user_name"));
                booking.setHasFeedback(rs.getBoolean("has_feedback"));
                bookings.add(booking);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving pending bookings: " + e.getMessage());
            e.printStackTrace();
        }
        return bookings;
    }
    
    // Get upcoming approved bookings (for calendar)
    public List<Booking> getUpcomingApprovedBookings() {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name, " +
                      "(SELECT COUNT(*) FROM feedback f WHERE f.booking_id = b.booking_id) > 0 AS has_feedback " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "WHERE b.status = 'approved' " +
                      "AND b.booking_date >= CURRENT_DATE " +
                      "ORDER BY b.booking_date ASC, b.start_time ASC " +
                      "LIMIT 10"; // Limit to 10 upcoming events
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Booking booking = new Booking();
                booking.setBookingId(rs.getInt("booking_id"));
                booking.setHallId(rs.getInt("hall_id"));
                booking.setUserId(rs.getInt("user_id"));
                booking.setEventName(rs.getString("event_name"));
                booking.setEventDescription(rs.getString("event_description"));
                booking.setBookingDate(rs.getDate("booking_date"));
                booking.setStartTime(rs.getTime("start_time"));
                booking.setEndTime(rs.getTime("end_time"));
                booking.setStatus(rs.getString("status"));
                booking.setDeclineReason(rs.getString("decline_reason"));
                booking.setCreatedAt(rs.getTimestamp("created_at"));
                booking.setHallName(rs.getString("hall_name"));
                booking.setUserName(rs.getString("user_name"));
                booking.setHasFeedback(rs.getBoolean("has_feedback"));
                bookings.add(booking);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving upcoming bookings: " + e.getMessage());
            e.printStackTrace();
        }
        return bookings;
    }
    
    // Get completed bookings without feedback
    public List<Booking> getCompletedBookingsWithoutFeedback(int userId) {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT b.*, h.hall_name " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "WHERE b.user_id = ? " +
                      "AND b.status = 'approved' " +
                      "AND b.booking_date < CURRENT_DATE " +
                      "AND NOT EXISTS (SELECT 1 FROM feedback f WHERE f.booking_id = b.booking_id) " +
                      "ORDER BY b.booking_date DESC, b.start_time ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.setBookingId(rs.getInt("booking_id"));
                    booking.setHallId(rs.getInt("hall_id"));
                    booking.setUserId(rs.getInt("user_id"));
                    booking.setEventName(rs.getString("event_name"));
                    booking.setEventDescription(rs.getString("event_description"));
                    booking.setBookingDate(rs.getDate("booking_date"));
                    booking.setStartTime(rs.getTime("start_time"));
                    booking.setEndTime(rs.getTime("end_time"));
                    booking.setStatus(rs.getString("status"));
                    booking.setDeclineReason(rs.getString("decline_reason"));
                    booking.setCreatedAt(rs.getTimestamp("created_at"));
                    booking.setHallName(rs.getString("hall_name"));
                    booking.setHasFeedback(false);
                    bookings.add(booking);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving completed bookings without feedback: " + e.getMessage());
            e.printStackTrace();
        }
        return bookings;
    }
    
    // Update booking status (approve/reject/cancel)
    public boolean updateBookingStatus(int bookingId, String status) {
        // If status is 'declined', convert it to 'rejected' for compatibility
        if ("declined".equals(status)) {
            status = "rejected";
        }
        
        String query = "UPDATE bookings SET status = ? WHERE booking_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, status);
            stmt.setInt(2, bookingId);
            
            System.out.println("Executing SQL: " + query);
            System.out.println("Parameters: status=" + status + ", booking_id=" + bookingId);
            
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Rows affected: " + rowsAffected);
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating booking status: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Update booking status with decline reason
    public boolean updateBookingStatus(int bookingId, String status, String declineReason) {
        // Convert 'declined' to 'rejected' if that's what your database expects
        if ("declined".equals(status)) {
            status = "rejected";
        }
        
        String query = "UPDATE bookings SET status = ?, decline_reason = ? WHERE booking_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, status);
            stmt.setString(2, declineReason);
            stmt.setInt(3, bookingId);
            
            System.out.println("Executing SQL: " + query);
            System.out.println("Parameters: status=" + status + 
                             ", decline_reason=" + declineReason +
                             ", booking_id=" + bookingId);
            
            int rowsAffected = stmt.executeUpdate();
            System.out.println("Rows affected: " + rowsAffected);
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("SQL Error Code: " + e.getErrorCode());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Error updating booking status with reason: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Cancel a booking (user function)
    public boolean cancelBooking(int bookingId, int userId) {
        // First verify this booking belongs to the user
        String checkQuery = "SELECT COUNT(*) FROM bookings WHERE booking_id = ? AND user_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
            
            checkStmt.setInt(1, bookingId);
            checkStmt.setInt(2, userId);
            
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    // Booking belongs to user, proceed with cancellation
                    return updateBookingStatus(bookingId, "cancelled");
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error canceling booking: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // Get bookings by status
    public List<Booking> getBookingsByStatus(String status) {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name, " +
                      "(SELECT COUNT(*) FROM feedback f WHERE f.booking_id = b.booking_id) > 0 AS has_feedback " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "WHERE b.status = ? " +
                      "ORDER BY b.booking_date DESC, b.start_time ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, status.toLowerCase());
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.setBookingId(rs.getInt("booking_id"));
                    booking.setHallId(rs.getInt("hall_id"));
                    booking.setUserId(rs.getInt("user_id"));
                    booking.setEventName(rs.getString("event_name"));
                    booking.setEventDescription(rs.getString("event_description"));
                    booking.setBookingDate(rs.getDate("booking_date"));
                    booking.setStartTime(rs.getTime("start_time"));
                    booking.setEndTime(rs.getTime("end_time"));
                    booking.setStatus(rs.getString("status"));
                    booking.setDeclineReason(rs.getString("decline_reason"));
                    booking.setCreatedAt(rs.getTimestamp("created_at"));
                    booking.setHallName(rs.getString("hall_name"));
                    booking.setUserName(rs.getString("user_name"));
                    booking.setHasFeedback(rs.getBoolean("has_feedback"));
                    bookings.add(booking);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving bookings by status: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }

    // Get recent bookings
    public List<Booking> getRecentBookings(int limit) {
        List<Booking> bookings = new ArrayList<>();
        String query = "SELECT b.*, h.hall_name, u.full_name AS user_name, " +
                      "(SELECT COUNT(*) FROM feedback f WHERE f.booking_id = b.booking_id) > 0 AS has_feedback " +
                      "FROM bookings b " +
                      "JOIN halls h ON b.hall_id = h.hall_id " +
                      "JOIN users u ON b.user_id = u.user_id " +
                      "ORDER BY b.created_at DESC " +
                      "LIMIT ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, limit);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Booking booking = new Booking();
                    booking.setBookingId(rs.getInt("booking_id"));
                    booking.setHallId(rs.getInt("hall_id"));
                    booking.setUserId(rs.getInt("user_id"));
                    booking.setEventName(rs.getString("event_name"));
                    booking.setEventDescription(rs.getString("event_description"));
                    booking.setBookingDate(rs.getDate("booking_date"));
                    booking.setStartTime(rs.getTime("start_time"));
                    booking.setEndTime(rs.getTime("end_time"));
                    booking.setStatus(rs.getString("status"));
                    booking.setDeclineReason(rs.getString("decline_reason"));
                    booking.setCreatedAt(rs.getTimestamp("created_at"));
                    booking.setHallName(rs.getString("hall_name"));
                    booking.setUserName(rs.getString("user_name"));
                    booking.setHasFeedback(rs.getBoolean("has_feedback"));
                    bookings.add(booking);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving recent bookings: " + e.getMessage());
            e.printStackTrace();
        }
        
        return bookings;
    }

    // Get hall booking counts (for analytics)
    public Map<Integer, Integer> getHallBookingCounts() {
        Map<Integer, Integer> hallBookingCounts = new HashMap<>();
        String query = "SELECT hall_id, COUNT(*) as booking_count " +
                      "FROM bookings " +
                      "WHERE status = 'approved' " +
                      "GROUP BY hall_id";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                int hallId = rs.getInt("hall_id");
                int count = rs.getInt("booking_count");
                hallBookingCounts.put(hallId, count);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving hall booking counts: " + e.getMessage());
            e.printStackTrace();
        }
        
        return hallBookingCounts;
    }
    
    // Check if booking is eligible for feedback
    public boolean isBookingEligibleForFeedback(int bookingId, int userId) {
        String query = "SELECT * FROM bookings " +
                      "WHERE booking_id = ? AND user_id = ? " +
                      "AND status = 'approved' " +
                      "AND booking_date < CURRENT_DATE " +
                      "AND NOT EXISTS (SELECT 1 FROM feedback f WHERE f.booking_id = ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, bookingId);
            stmt.setInt(2, userId);
            stmt.setInt(3, bookingId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next(); // Returns true if booking is eligible for feedback
            }
        } catch (SQLException e) {
            System.err.println("Error checking if booking is eligible for feedback: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Reject a booking with reason
    public boolean rejectBooking(int bookingId, String reason) {
        return updateBookingStatus(bookingId, "rejected", reason);
    }
}
