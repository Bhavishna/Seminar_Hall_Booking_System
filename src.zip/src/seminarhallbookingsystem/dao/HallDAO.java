/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seminarhallbookingsystem.dao;

import seminarhallbookingsystem.models.Hall;
import seminarhallbookingsystem.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bhavi
 */
public class HallDAO {
    
    // Create a new hall
    public boolean addHall(Hall hall) {
        String query = "INSERT INTO halls (hall_name, capacity, description, facilities, image_path) " +
                      "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, hall.getHallName());
            stmt.setInt(2, hall.getCapacity());
            stmt.setString(3, hall.getDescription());
            stmt.setString(4, hall.getFacilities());
            stmt.setString(5, hall.getImagePath());
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the auto-generated ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    hall.setHallId(rs.getInt(1));
                }
                return true;
            }
            return false;
            
        } catch (SQLException e) {
            System.err.println("Error adding hall: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Get hall by ID
    public Hall getHallById(int hallId) {
        String query = "SELECT * FROM halls WHERE hall_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, hallId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Hall hall = new Hall();
                    hall.setHallId(rs.getInt("hall_id"));
                    hall.setHallName(rs.getString("hall_name"));
                    hall.setCapacity(rs.getInt("capacity"));
                    hall.setDescription(rs.getString("description"));
                    hall.setFacilities(rs.getString("facilities"));
                    hall.setImagePath(rs.getString("image_path"));
                    return hall;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving hall by ID: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    
    // Get all halls
    public List<Hall> getAllHalls() {
        List<Hall> halls = new ArrayList<>();
        String query = "SELECT * FROM halls ORDER BY hall_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                Hall hall = new Hall();
                hall.setHallId(rs.getInt("hall_id"));
                hall.setHallName(rs.getString("hall_name"));
                hall.setCapacity(rs.getInt("capacity"));
                hall.setDescription(rs.getString("description"));
                hall.setFacilities(rs.getString("facilities"));
                hall.setImagePath(rs.getString("image_path"));
                halls.add(hall);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving all halls: " + e.getMessage());
            e.printStackTrace();
        }
        return halls;
    }
    
    // Update an existing hall
    public boolean updateHall(Hall hall) {
        String query = "UPDATE halls SET hall_name = ?, capacity = ?, description = ?, facilities = ?, image_path = ? " +
                      "WHERE hall_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, hall.getHallName());
            stmt.setInt(2, hall.getCapacity());
            stmt.setString(3, hall.getDescription());
            stmt.setString(4, hall.getFacilities());
            stmt.setString(5, hall.getImagePath());
            stmt.setInt(6, hall.getHallId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating hall: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Delete a hall
    public boolean deleteHall(int hallId) {
        // First check if any bookings reference this hall
        String checkQuery = "SELECT COUNT(*) FROM bookings WHERE hall_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
            
            checkStmt.setInt(1, hallId);
            
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    // Hall has bookings, don't delete
                    return false;
                }
            }
            
            // If no bookings, proceed with deletion
            String deleteQuery = "DELETE FROM halls WHERE hall_id = ?";
            try (PreparedStatement deleteStmt = conn.prepareStatement(deleteQuery)) {
                deleteStmt.setInt(1, hallId);
                
                int rowsAffected = deleteStmt.executeUpdate();
                return rowsAffected > 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error deleting hall: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Check hall availability
    public boolean isHallAvailable(int hallId, Date date, Time startTime, Time endTime) {
        String query = "SELECT COUNT(*) FROM bookings " +
                      "WHERE hall_id = ? AND booking_date = ? AND " +
                      "((start_time <= ? AND end_time > ?) OR " +
                      "(start_time < ? AND end_time >= ?) OR " +
                      "(start_time >= ? AND end_time <= ?)) AND " +
                      "status IN ('pending', 'approved')";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, hallId);
            stmt.setDate(2, date);
            stmt.setTime(3, endTime);
            stmt.setTime(4, endTime);
            stmt.setTime(5, startTime);
            stmt.setTime(6, startTime);
            stmt.setTime(7, startTime);
            stmt.setTime(8, endTime);
            
            System.out.println("Availability check for hall " + hallId + 
                              " on " + date + 
                              " from " + startTime + 
                              " to " + endTime + ": ");
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    boolean isAvailable = count == 0;
                    System.out.println(isAvailable);
                    return isAvailable;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking hall availability: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    // Get available halls for a time slot
    public List<Hall> getAvailableHalls(Date date, Time startTime, Time endTime) {
        List<Hall> availableHalls = new ArrayList<>();
        String query = "SELECT h.* FROM halls h " +
                      "WHERE NOT EXISTS (" +
                      "    SELECT 1 FROM bookings b " +
                      "    WHERE b.hall_id = h.hall_id AND b.booking_date = ? AND " +
                      "    ((b.start_time <= ? AND b.end_time > ?) OR " +
                      "     (b.start_time < ? AND b.end_time >= ?) OR " +
                      "     (b.start_time >= ? AND b.end_time <= ?)) AND " +
                      "    b.status IN ('pending', 'approved')" +
                      ") " +
                      "ORDER BY h.hall_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setDate(1, date);
            stmt.setTime(2, endTime);
            stmt.setTime(3, endTime);
            stmt.setTime(4, startTime);
            stmt.setTime(5, startTime);
            stmt.setTime(6, startTime);
            stmt.setTime(7, endTime);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Hall hall = new Hall();
                    hall.setHallId(rs.getInt("hall_id"));
                    hall.setHallName(rs.getString("hall_name"));
                    hall.setCapacity(rs.getInt("capacity"));
                    hall.setDescription(rs.getString("description"));
                    hall.setFacilities(rs.getString("facilities"));
                    hall.setImagePath(rs.getString("image_path"));
                    availableHalls.add(hall);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving available halls: " + e.getMessage());
            e.printStackTrace();
        }
        
        return availableHalls;
    }
    
    // Update just the image path of a hall
    public boolean updateHallImage(int hallId, String imagePath) {
        String query = "UPDATE halls SET image_path = ? WHERE hall_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setString(1, imagePath);
            stmt.setInt(2, hallId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating hall image: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Get halls by capacity range
    public List<Hall> getHallsByCapacity(int minCapacity, int maxCapacity) {
        List<Hall> halls = new ArrayList<>();
        String query = "SELECT * FROM halls WHERE capacity >= ? AND capacity <= ? ORDER BY capacity";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            stmt.setInt(1, minCapacity);
            stmt.setInt(2, maxCapacity);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Hall hall = new Hall();
                    hall.setHallId(rs.getInt("hall_id"));
                    hall.setHallName(rs.getString("hall_name"));
                    hall.setCapacity(rs.getInt("capacity"));
                    hall.setDescription(rs.getString("description"));
                    hall.setFacilities(rs.getString("facilities"));
                    hall.setImagePath(rs.getString("image_path"));
                    halls.add(hall);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving halls by capacity: " + e.getMessage());
            e.printStackTrace();
        }
        
        return halls;
    }
    
    // Search halls by name or description
    public List<Hall> searchHalls(String searchTerm) {
        List<Hall> halls = new ArrayList<>();
        String query = "SELECT * FROM halls " +
                      "WHERE hall_name LIKE ? OR description LIKE ? OR facilities LIKE ? " +
                      "ORDER BY hall_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            
            String searchPattern = "%" + searchTerm + "%";
            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Hall hall = new Hall();
                    hall.setHallId(rs.getInt("hall_id"));
                    hall.setHallName(rs.getString("hall_name"));
                    hall.setCapacity(rs.getInt("capacity"));
                    hall.setDescription(rs.getString("description"));
                    hall.setFacilities(rs.getString("facilities"));
                    hall.setImagePath(rs.getString("image_path"));
                    halls.add(hall);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error searching halls: " + e.getMessage());
            e.printStackTrace();
        }
        
        return halls;
    }
    // Search halls by name and capacity
public List<Hall> searchHallsByNameAndCapacity(String hallName, Integer minCapacity, Integer maxCapacity) {
    List<Hall> halls = new ArrayList<>();
    
    // Build the query based on the provided filters
    StringBuilder queryBuilder = new StringBuilder("SELECT * FROM halls WHERE 1=1");
    List<Object> params = new ArrayList<>();
    
    // Add hall name filter if provided
    if (hallName != null && !hallName.trim().isEmpty()) {
        queryBuilder.append(" AND hall_name LIKE ?");
        params.add("%" + hallName.trim() + "%");
    }
    
    // Add minimum capacity filter if provided
    if (minCapacity != null && minCapacity > 0) {
        queryBuilder.append(" AND capacity >= ?");
        params.add(minCapacity);
    }
    
    // Add maximum capacity filter if provided
    if (maxCapacity != null && maxCapacity > 0) {
        queryBuilder.append(" AND capacity <= ?");
        params.add(maxCapacity);
    }
    
    // Add ordering
    queryBuilder.append(" ORDER BY hall_name");
    
    // Execute the query
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(queryBuilder.toString())) {
        
        // Set parameters
        for (int i = 0; i < params.size(); i++) {
            stmt.setObject(i + 1, params.get(i));
        }
        
        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Hall hall = new Hall();
                hall.setHallId(rs.getInt("hall_id"));
                hall.setHallName(rs.getString("hall_name"));
                hall.setCapacity(rs.getInt("capacity"));
                hall.setDescription(rs.getString("description"));
                hall.setFacilities(rs.getString("facilities"));
                hall.setImagePath(rs.getString("image_path"));
                halls.add(hall);
            }
        }
        
    } catch (SQLException e) {
        System.err.println("Error searching halls by name and capacity: " + e.getMessage());
        e.printStackTrace();
    }
    
    return halls;
}
// Search halls by facilities
public List<Hall> searchHallsByFacilities(String facilities) {
    List<Hall> halls = new ArrayList<>();
    String query = "SELECT * FROM halls WHERE facilities LIKE ? ORDER BY hall_name";
    
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        
        stmt.setString(1, "%" + facilities + "%");
        
        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Hall hall = new Hall();
                hall.setHallId(rs.getInt("hall_id"));
                hall.setHallName(rs.getString("hall_name"));
                hall.setCapacity(rs.getInt("capacity"));
                hall.setDescription(rs.getString("description"));
                hall.setFacilities(rs.getString("facilities"));
                hall.setImagePath(rs.getString("image_path"));
                halls.add(hall);
            }
        }
        
    } catch (SQLException e) {
        System.err.println("Error searching halls by facilities: " + e.getMessage());
        e.printStackTrace();
    }
    
    return halls;
}

}