/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seminarhallbookingsystem.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/seminar_hall_booking";
    private static final String USER = "root"; // Change to your MySQL username
    private static final String PASSWORD = "prithivya@1"; // Change to your MySQL password
    
    public static Connection getConnection() throws SQLException {
        try {
            // Try the modern driver class
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                System.out.println("Modern MySQL driver loaded successfully");
            } catch (ClassNotFoundException e1) {
                // If modern driver fails, try the older one
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    System.out.println("Legacy MySQL driver loaded successfully");
                } catch (ClassNotFoundException e2) {
                    System.out.println("Warning: MySQL JDBC Driver class not found, continuing without explicit loading");
                }
            }
            
            // Attempt connection
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            return conn;
        } catch (SQLException e) {
            System.err.println("Connection error: " + e.getMessage());
            throw e;
        }
    }
    
    // Test the connection
    public static void main(String[] args) {
        try {
            Connection conn = getConnection();
            System.out.println("Database connection successful!");
            conn.close();
        } catch (Exception e) {
            System.err.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
