package seminarhallbookingsystem.util;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import seminarhallbookingsystem.models.Booking;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dialog;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Button;
import java.awt.BorderLayout;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class ReportGenerator {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm");
    
    /**
     * Export bookings to PDF
     * @param bookings List of bookings to export
     * @param outputPath File path for the PDF
     * @param title Report title
     * @return true if PDF was generated successfully
     */
    public static boolean exportToPDF(List<Booking> bookings, String outputPath, String title) {
        try {
            Document document = new Document(PageSize.A4, 50, 50, 50, 50);
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(outputPath));
            
            document.open();
            
            // Add title
            com.itextpdf.text.Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK);
            Paragraph titleParagraph = new Paragraph(title, titleFont);
            titleParagraph.setAlignment(Element.ALIGN_CENTER);
            titleParagraph.setSpacingAfter(20);
            document.add(titleParagraph);
            
            // Add generation date
            com.itextpdf.text.Font dateFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.ITALIC, BaseColor.DARK_GRAY);
            Paragraph dateParagraph = new Paragraph("Generated on: " + 
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()), dateFont);
            dateParagraph.setAlignment(Element.ALIGN_RIGHT);
            dateParagraph.setSpacingAfter(20);
            document.add(dateParagraph);
            
            // Create table
            PdfPTable table = new PdfPTable(7); // 7 columns
            table.setWidthPercentage(100);
            
            // Set column widths (total should be 100)
            float[] columnWidths = {8, 15, 12, 20, 15, 15, 15};
            table.setWidths(columnWidths);
            
            // Add table headers
            com.itextpdf.text.Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.WHITE);
            
            // Header background
            PdfPCell headerCell = new PdfPCell();
            headerCell.setBackgroundColor(new BaseColor(66, 133, 244)); // Blue
            headerCell.setPadding(5);
            
            String[] headers = {"ID", "Hall", "User", "Event", "Date", "Time", "Status"};
            
            for (String header : headers) {
                headerCell.setPhrase(new Phrase(header, headerFont));
                table.addCell(headerCell);
            }
            
            // Add data rows
            com.itextpdf.text.Font dataFont = FontFactory.getFont(FontFactory.HELVETICA, 10, BaseColor.BLACK);
            
            for (Booking booking : bookings) {
                // ID
                PdfPCell cell = new PdfPCell(new Phrase(String.valueOf(booking.getBookingId()), dataFont));
                cell.setPadding(5);
                table.addCell(cell);
                
                // Hall
                cell = new PdfPCell(new Phrase(booking.getHallName(), dataFont));
                cell.setPadding(5);
                table.addCell(cell);
                
                // User
                cell = new PdfPCell(new Phrase(booking.getUserName(), dataFont));
                cell.setPadding(5);
                table.addCell(cell);
                
                // Event
                cell = new PdfPCell(new Phrase(booking.getEventName(), dataFont));
                cell.setPadding(5);
                table.addCell(cell);
                
                // Date
                String date = DATE_FORMAT.format(booking.getBookingDate());
                cell = new PdfPCell(new Phrase(date, dataFont));
                cell.setPadding(5);
                table.addCell(cell);
                
                // Time
                String time = TIME_FORMAT.format(booking.getStartTime()) + " - " + 
                              TIME_FORMAT.format(booking.getEndTime());
                cell = new PdfPCell(new Phrase(time, dataFont));
                cell.setPadding(5);
                table.addCell(cell);
                
                // Status
                cell = new PdfPCell(new Phrase(booking.getStatus(), dataFont));
                cell.setPadding(5);
                
                // Color-code status
                if ("approved".equalsIgnoreCase(booking.getStatus())) {
                    cell.setBackgroundColor(new BaseColor(200, 230, 201)); // Light green
                } else if ("rejected".equalsIgnoreCase(booking.getStatus()) || 
                           "cancelled".equalsIgnoreCase(booking.getStatus())) {
                    cell.setBackgroundColor(new BaseColor(255, 205, 210)); // Light red
                } else if ("pending".equalsIgnoreCase(booking.getStatus())) {
                    cell.setBackgroundColor(new BaseColor(255, 241, 118)); // Light yellow
                }
                
                table.addCell(cell);
            }
            
            document.add(table);
            
            // Add summary
            com.itextpdf.text.Font summaryFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.BLACK);
            Paragraph summaryParagraph = new Paragraph("Total Bookings: " + bookings.size(), summaryFont);
            summaryParagraph.setSpacingBefore(20);
            document.add(summaryParagraph);
            
            // Add footer
            com.itextpdf.text.Font footerFont = FontFactory.getFont(FontFactory.HELVETICA, 8, Font.ITALIC, BaseColor.GRAY);
            Paragraph footerParagraph = new Paragraph(
                "Generated by Seminar Hall Booking System | Copyright © " + 
                Calendar.getInstance().get(Calendar.YEAR), footerFont);
            footerParagraph.setAlignment(Element.ALIGN_CENTER);
            document.add(footerParagraph);
            
            document.close();
            
            return true;
        } catch (Exception e) {
            System.err.println("Error exporting to PDF: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Export bookings to CSV
     * @param bookings List of bookings to export
     * @param outputPath File path for the CSV
     * @return true if CSV was generated successfully
     */
    public static boolean exportToCSV(List<Booking> bookings, String outputPath) {
        try (PrintWriter writer = new PrintWriter(new File(outputPath))) {
            StringBuilder sb = new StringBuilder();
            
            // Add CSV headers
            sb.append("Booking ID,Hall,User,Event,Date,Start Time,End Time,Status,Created At\n");
            
            // Add booking data
            for (Booking booking : bookings) {
                sb.append(booking.getBookingId()).append(",");
                sb.append(escapeCSV(booking.getHallName())).append(",");
                sb.append(escapeCSV(booking.getUserName())).append(",");
                sb.append(escapeCSV(booking.getEventName())).append(",");
                sb.append(DATE_FORMAT.format(booking.getBookingDate())).append(",");
                sb.append(TIME_FORMAT.format(booking.getStartTime())).append(",");
                sb.append(TIME_FORMAT.format(booking.getEndTime())).append(",");
                sb.append(booking.getStatus()).append(",");
                sb.append(booking.getCreatedAt()).append("\n");
            }
            
            writer.write(sb.toString());
            
            return true;
        } catch (Exception e) {
            System.err.println("Error exporting to CSV: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Escape special characters for CSV
     */
    private static String escapeCSV(String value) {
        if (value == null) {
            return "";
        }
        
        // If value contains commas, quotes, or newlines, wrap in quotes
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            // Replace quotes with double quotes
            String escaped = value.replace("\"", "\"\"");
            return "\"" + escaped + "\"";
        }
        
        return value;
    }
    
    /**
     * Create a bar chart for hall usage
     * @param data Map with hall name as key and usage count as value
     * @return BufferedImage containing the chart
     */
    public static BufferedImage createHallUsageBarChart(Map<String, Integer> data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
        // Add data to dataset
        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            dataset.addValue(entry.getValue(), "Bookings", entry.getKey());
        }
        
        // Create chart
        JFreeChart chart = ChartFactory.createBarChart(
            "Hall Usage Statistics",     // chart title
            "Hall",                      // domain axis label
            "Number of Bookings",        // range axis label
            dataset,                     // data
            PlotOrientation.VERTICAL,    // orientation
            false,                       // include legend
            true,                        // tooltips
            false                        // URLs
        );
        
        // Customize chart
        chart.setBackgroundPaint(Color.white);
        
        // Create image
        BufferedImage image = chart.createBufferedImage(800, 500);
        
        return image;
    }
    
    /**
     * Create a pie chart for hall usage
     * @param data Map with hall name as key and usage count as value
     * @return BufferedImage containing the chart
     */
    public static BufferedImage createHallUsagePieChart(Map<String, Integer> data) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        
        // Add data to dataset
        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());
        }
        
        // Create chart
        JFreeChart chart = ChartFactory.createPieChart(
            "Hall Usage Distribution",   // chart title
            dataset,                     // data
            true,                        // include legend
            true,                        // tooltips
            false                        // URLs
        );
        
        // Customize chart
        chart.setBackgroundPaint(Color.white);
        
        // Create image
        BufferedImage image = chart.createBufferedImage(600, 500);
        
        return image;
    }
    
    /**
     * Create a bar chart for day of week usage
     * @param data Map with day of week as key and usage count as value
     * @return BufferedImage containing the chart
     */
    public static BufferedImage createDayOfWeekChart(Map<String, Integer> data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
        // Define the correct order of days
        String[] daysInOrder = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        
        // Add data to dataset in the correct order
        for (String day : daysInOrder) {
            Integer value = data.get(day);
            if (value != null) {
                dataset.addValue(value, "Bookings", day);
            }
        }
        
        // Create chart
        JFreeChart chart = ChartFactory.createBarChart(
            "Bookings by Day of Week",   // chart title
            "Day",                       // domain axis label
            "Number of Bookings",        // range axis label
            dataset,                     // data
            PlotOrientation.VERTICAL,    // orientation
            false,                       // include legend
            true,                        // tooltips
            false                        // URLs
        );
        
        // Customize chart
        chart.setBackgroundPaint(Color.white);
        
        // Create image
        BufferedImage image = chart.createBufferedImage(800, 500);
        
        return image;
    }
    
    /**
     * Create a line chart for time of day usage
     * @param data Map with hour as key and usage count as value
     * @return BufferedImage containing the chart
     */
    public static BufferedImage createTimeOfDayChart(Map<Integer, Integer> data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
        // Add data to dataset
        for (int hour = 0; hour < 24; hour++) {
            Integer value = data.get(hour);
            if (value != null) {
                // Format hour as "00:00" style
                String hourLabel = String.format("%02d:00", hour);
                dataset.addValue(value, "Bookings", hourLabel);
            }
        }
        
        // Create chart
        JFreeChart chart = ChartFactory.createLineChart(
            "Bookings by Time of Day",   // chart title
            "Hour",                      // domain axis label
            "Number of Bookings",        // range axis label
            dataset,                     // data
            PlotOrientation.VERTICAL,    // orientation
            false,                       // include legend
            true,                        // tooltips
            false                        // URLs
        );
        
        // Customize chart
        chart.setBackgroundPaint(Color.white);
        
        // Create image
        BufferedImage image = chart.createBufferedImage(800, 500);
        
        return image;
    }
    
    /**
     * Save chart to a file
     * @param chart The chart image
     * @param filePath File path to save the chart
     * @return true if successful
     */
    public static boolean saveChartToFile(BufferedImage chart, String filePath) {
        try {
            File outputFile = new File(filePath);
            ImageIO.write(chart, "PNG", outputFile);
            return true;
        } catch (IOException e) {
            System.err.println("Error saving chart: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Show a file download dialog and generate a PDF report at the selected location
     * @param bookings List of bookings to export
     * @param title Report title
     * @param parent The parent Frame for the dialog
     * @return true if successful, false otherwise
     */
    public static boolean downloadPDFReport(List<Booking> bookings, String title, Frame parent) {
        // Default filename with timestamp
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String defaultFilename = "bookings_report_" + dateFormat.format(new Date()) + ".pdf";
        
        // Show file save dialog
        FileDialog fileDialog = new FileDialog(parent, "Save PDF Report As", FileDialog.SAVE);
        fileDialog.setFile(defaultFilename);
        fileDialog.setFilenameFilter((dir, name) -> name.toLowerCase().endsWith(".pdf"));
        fileDialog.setVisible(true);
        
        // Get the selected file path
        String directory = fileDialog.getDirectory();
        String filename = fileDialog.getFile();
        
        if (directory != null && filename != null) {
            // If the user didn't add .pdf extension, add it
            if (!filename.toLowerCase().endsWith(".pdf")) {
                filename += ".pdf";
            }
            
            String filePath = directory + filename;
            
            // Generate the PDF report
            boolean success = exportToPDF(bookings, filePath, title);
            
            if (success) {
                // Show success dialog
                Dialog successDialog = new Dialog(parent, "Download Successful", true);
                successDialog.setLayout(new BorderLayout(10, 10));
                
                Label msgLabel = new Label("Report has been downloaded successfully.", Label.CENTER);
                msgLabel.setFont(new Font("Arial", Font.BOLD, 14));
                
                Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
                Button openButton = new Button("Open Report");
                Button closeButton = new Button("Close");
                
                openButton.addActionListener(e -> {
                    try {
                        if (Desktop.isDesktopSupported()) {
                            Desktop.getDesktop().open(new File(filePath));
                        }
                    } catch (Exception ex) {
                        System.err.println("Error opening file: " + ex.getMessage());
                    }
                    successDialog.dispose();
                });
                
                closeButton.addActionListener(e -> successDialog.dispose());
                
                buttonPanel.add(openButton);
                buttonPanel.add(closeButton);
                
                successDialog.add(msgLabel, BorderLayout.CENTER);
                successDialog.add(buttonPanel, BorderLayout.SOUTH);
                successDialog.setSize(350, 150);
                successDialog.setLocationRelativeTo(parent);
                successDialog.setVisible(true);
            } else {
                // Show error dialog
                Dialog errorDialog = new Dialog(parent, "Download Failed", true);
                errorDialog.setLayout(new FlowLayout());
                errorDialog.add(new Label("Failed to generate and download the report."));
                Button okButton = new Button("OK");
                okButton.addActionListener(e -> errorDialog.dispose());
                errorDialog.add(okButton);
                errorDialog.setSize(350, 100);
                errorDialog.setLocationRelativeTo(parent);
                errorDialog.setVisible(true);
            }
            
            return success;
        }
        
        return false; // User canceled the dialog
    }

    /**
     * Show a file download dialog and generate a CSV report at the selected location
     * @param bookings List of bookings to export
     * @param parent The parent Frame for the dialog
     * @return true if successful, false otherwise
     */
    public static boolean downloadCSVReport(List<Booking> bookings, Frame parent) {
        // Default filename with timestamp
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String defaultFilename = "bookings_data_" + dateFormat.format(new Date()) + ".csv";
        
        // Show file save dialog
        FileDialog fileDialog = new FileDialog(parent, "Save CSV Report As", FileDialog.SAVE);
        fileDialog.setFile(defaultFilename);
        fileDialog.setFilenameFilter((dir, name) -> name.toLowerCase().endsWith(".csv"));
        fileDialog.setVisible(true);
        
        // Get the selected file path
        String directory = fileDialog.getDirectory();
        String filename = fileDialog.getFile();
        
        if (directory != null && filename != null) {
            // If the user didn't add .csv extension, add it
            if (!filename.toLowerCase().endsWith(".csv")) {
                filename += ".csv";
            }
            
            String filePath = directory + filename;
            
            // Generate the CSV report
            boolean success = exportToCSV(bookings, filePath);
            
            if (success) {
                // Show success dialog
                Dialog successDialog = new Dialog(parent, "Download Successful", true);
                successDialog.setLayout(new BorderLayout(10, 10));
                
                Label msgLabel = new Label("CSV data has been downloaded successfully.", Label.CENTER);
                msgLabel.setFont(new Font("Arial", Font.BOLD, 14));
                
                Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
                Button openButton = new Button("Open File");
                Button closeButton = new Button("Close");
                
                openButton.addActionListener(e -> {
                    try {
                        if (Desktop.isDesktopSupported()) {
                            Desktop.getDesktop().open(new File(filePath));
                        }
                    } catch (Exception ex) {
                        System.err.println("Error opening file: " + ex.getMessage());
                    }
                    successDialog.dispose();
                });
                
                closeButton.addActionListener(e -> successDialog.dispose());
                
                buttonPanel.add(openButton);
                buttonPanel.add(closeButton);
                
                successDialog.add(msgLabel, BorderLayout.CENTER);
                successDialog.add(buttonPanel, BorderLayout.SOUTH);
                successDialog.setSize(350, 150);
                successDialog.setLocationRelativeTo(parent);
                successDialog.setVisible(true);
            } else {
                // Show error dialog
                Dialog errorDialog = new Dialog(parent, "Download Failed", true);
                errorDialog.setLayout(new FlowLayout());
                errorDialog.add(new Label("Failed to generate and download the CSV file."));
                Button okButton = new Button("OK");
                okButton.addActionListener(e -> errorDialog.dispose());
                errorDialog.add(okButton);
                errorDialog.setSize(350, 100);
                errorDialog.setLocationRelativeTo(parent);
                errorDialog.setVisible(true);
            }
            
            return success;
        }
        
        return false; // User canceled the dialog
    }

    /**
     * Show a file download dialog and save a chart at the selected location
     * @param chart The chart image
     * @param chartType Type of chart for the default filename
     * @param parent The parent Frame for the dialog
     * @return true if successful, false otherwise
     */
    public static boolean downloadChart(BufferedImage chart, String chartType, Frame parent) {
        // Default filename with timestamp
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String defaultFilename = chartType + "_chart_" + dateFormat.format(new Date()) + ".png";
        
        // Show file save dialog
        FileDialog fileDialog = new FileDialog(parent, "Save Chart As", FileDialog.SAVE);
        fileDialog.setFile(defaultFilename);
        fileDialog.setFilenameFilter((dir, name) -> {
            String lowerCase = name.toLowerCase();
            return lowerCase.endsWith(".png") || lowerCase.endsWith(".jpg") || 
                   lowerCase.endsWith(".jpeg") || lowerCase.endsWith(".gif");
        });
        fileDialog.setVisible(true);
        
        // Get the selected file path
        String directory = fileDialog.getDirectory();
        String filename = fileDialog.getFile();
        
        if (directory != null && filename != null) {
            // If the user didn't add an extension, add .png
            if (!filename.toLowerCase().matches(".*\\.(png|jpg|jpeg|gif)$")) {
                filename += ".png";
            }
            
            String filePath = directory + filename;
            String format = "png";  // Default format
            
            // Determine format from filename
            if (filename.toLowerCase().endsWith(".jpg") || filename.toLowerCase().endsWith(".jpeg")) {
                format = "jpg";
            } else if (filename.toLowerCase().endsWith(".gif")) {
                format = "gif";
            }
            
            // Save the chart
            try {
                File outputFile = new File(filePath);
                boolean success = ImageIO.write(chart, format, outputFile);
                
                if (success) {
                    // Show success dialog
                    Dialog successDialog = new Dialog(parent, "Download Successful", true);
                    successDialog.setLayout(new BorderLayout(10, 10));
                    
                    Label msgLabel = new Label("Chart has been downloaded successfully.", Label.CENTER);
                    msgLabel.setFont(new Font("Arial", Font.BOLD, 14));
                    
                    Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
                    Button openButton = new Button("View Image");
                    Button closeButton = new Button("Close");
                    
                    openButton.addActionListener(e -> {
                        try {
                            if (Desktop.isDesktopSupported()) {
                                Desktop.getDesktop().open(new File(filePath));
                            }
                        } catch (Exception ex) {
                            System.err.println("Error opening image: " + ex.getMessage());
                        }
                        successDialog.dispose();
                    });
                    
                    closeButton.addActionListener(e -> successDialog.dispose());
                    
                    buttonPanel.add(openButton);
                    buttonPanel.add(closeButton);
                    
                    successDialog.add(msgLabel, BorderLayout.CENTER);
                    successDialog.add(buttonPanel, BorderLayout.SOUTH);
                    successDialog.setSize(350, 150);
                    successDialog.setLocationRelativeTo(parent);
                    successDialog.setVisible(true);
                } else {
                    showErrorDialog(parent, "Failed to save the chart image.");
                }
                
                return success;
            } catch (IOException e) {
                System.err.println("Error saving chart: " + e.getMessage());
                e.printStackTrace();
                showErrorDialog(parent, "Error: " + e.getMessage());
                return false;
            }
        }
        
        return false; // User canceled the dialog
    }

    /**
     * Helper method to show error dialogs
     */
    private static void showErrorDialog(Frame parent, String message) {
        Dialog errorDialog = new Dialog(parent, "Error", true);
        errorDialog.setLayout(new FlowLayout());
        errorDialog.add(new Label(message));
        Button okButton = new Button("OK");
        okButton.addActionListener(e -> errorDialog.dispose());
        errorDialog.add(okButton);
        errorDialog.setSize(350, 100);
        errorDialog.setLocationRelativeTo(parent);
        errorDialog.setVisible(true);
    }
}
