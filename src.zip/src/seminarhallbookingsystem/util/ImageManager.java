package seminarhallbookingsystem.util;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import javax.imageio.ImageIO;

public class ImageManager {
    // Define the directory where hall images will be stored
    private static final String IMAGE_DIRECTORY = "hall_images/";
    
    // Initialize the directory
    static {
        File directory = new File(IMAGE_DIRECTORY);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }
    
    // Method to save an image file and return the path
    public static String saveHallImage(File sourceFile) throws IOException {
        // Generate a unique filename to avoid conflicts
        String fileName = "hall_" + UUID.randomUUID().toString() + getFileExtension(sourceFile.getName());
        Path targetPath = Paths.get(IMAGE_DIRECTORY + fileName);
        
        // Copy the file to our image directory
        Files.copy(sourceFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);
        
        return targetPath.toString();
    }
    
    // Method to load an image from path
    public static Image loadHallImage(String imagePath) throws IOException {
        if (imagePath == null || imagePath.isEmpty()) {
            return null;
        }
        
        File imageFile = new File(imagePath);
        if (!imageFile.exists()) {
            return null;
        }
        
        return ImageIO.read(imageFile);
    }
    
    // Method to load a thumbnail-sized version of the image
    public static Image loadHallThumbnail(String imagePath, int width, int height) throws IOException {
        Image originalImage = loadHallImage(imagePath);
        if (originalImage == null) {
            return null;
        }
        
        return originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
    }
    
    // Helper method to get file extension
    private static String getFileExtension(String filename) {
        int lastDotIndex = filename.lastIndexOf('.');
        if (lastDotIndex == -1 || lastDotIndex == filename.length() - 1) {
            return ".jpg"; // Default extension
        }
        return filename.substring(lastDotIndex);
    }
    
    // Method to resize an image
    public static BufferedImage resizeImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        Image resultingImage = originalImage.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
        BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
        resizedImage.getGraphics().drawImage(resultingImage, 0, 0, null);
        return resizedImage;
    }

    public static void deleteHallImage(String imagePath) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
