package seminarhallbookingsystem.ui;

import seminarhallbookingsystem.dao.UserDAO;
import seminarhallbookingsystem.models.User;
import java.awt.*;
import java.awt.event.*;

/**
 * Enhanced Login Frame with improved UI while maintaining AWT components
 * @author bhavi
 */
public class LoginFrame extends Frame {
    private TextField usernameField;
    private TextField passwordField;
    private Button loginButton;
    private Button registerButton;
    private Label statusLabel;
    private Label usernameLabel;
    
    // Colors
    private final Color PRIMARY_COLOR = new Color(70, 130, 180);  // Steel blue
    private final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Light gray
    private final Color TEXT_COLOR = new Color(25, 25, 25);       // Near black
    private final Color ERROR_COLOR = new Color(178, 34, 34);     // Firebrick red
    
    public LoginFrame() {
        // Frame setup
        setTitle("Seminar Hall Booking System");
        setSize(450, 350);
        setLayout(null); // Keep the null layout as in original
        setLocationRelativeTo(null); // Center on screen
        setResizable(false);
        setBackground(BACKGROUND_COLOR);
        
        // Add title at the top
        Label titleLabel = new Label("Seminar Hall Booking System", Label.CENTER);
        titleLabel.setBounds(50, 40, 350, 30);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(PRIMARY_COLOR);
        add(titleLabel);
        
        // Add separator line
        Canvas separator = new Canvas();
        separator.setBounds(50, 80, 350, 1);
        separator.setBackground(Color.LIGHT_GRAY);
        add(separator);
        
        // Username label and field
        usernameLabel = new Label("Username:");
        usernameLabel.setBounds(100, 100, 100, 25);
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        usernameLabel.setForeground(TEXT_COLOR);
        add(usernameLabel);
        
        usernameField = new TextField();
        usernameField.setBounds(100, 130, 250, 30);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        add(usernameField);
        
        // Password label and field
        Label passwordLabel = new Label("Password:");
        passwordLabel.setBounds(100, 170, 100, 25);
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordLabel.setForeground(TEXT_COLOR);
        add(passwordLabel);
        
        passwordField = new TextField();
        passwordField.setEchoChar('*');
        passwordField.setBounds(100, 200, 250, 30);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        add(passwordField);
        
        // Buttons with better positioning and styling
        loginButton = new Button("Login");
        loginButton.setBounds(100, 250, 120, 35);
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(PRIMARY_COLOR);
        add(loginButton);
        
        registerButton = new Button("Register");
        registerButton.setBounds(230, 250, 120, 35);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        registerButton.setForeground(PRIMARY_COLOR);
        registerButton.setBackground(Color.WHITE);
        add(registerButton);
        
        // Status label for feedback
        statusLabel = new Label("", Label.CENTER);
        statusLabel.setBounds(75, 295, 300, 25);
        statusLabel.setForeground(ERROR_COLOR);
        add(statusLabel);
        
        // Add event listeners
        loginButton.addActionListener(e -> login());
        
        registerButton.addActionListener(e -> openRegistrationFrame());
        
        // Close window handler
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                dispose();
                System.exit(0);
            }
        });
        
        // Keyboard listener for Enter key
        KeyAdapter enterKeyListener = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    login();
                }
            }
        };
        
        usernameField.addKeyListener(enterKeyListener);
        passwordField.addKeyListener(enterKeyListener);
    }
    
    private void login() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        
        if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Please enter both username and password");
            return;
        }
        
        try {
            UserDAO userDao = new UserDAO();
            User user = userDao.authenticate(username, password);
            
            if (user != null) {
                statusLabel.setText("Login successful!");
                statusLabel.setForeground(new Color(46, 139, 87)); // Sea green
                
                // Debug statement
                System.out.println("Login successful for user: " + user.getUsername() + ", Admin: " + user.isAdmin());
                
                if (user.isAdmin()) {
                    // Create and show admin dashboard
                    AdminDashboard adminDashboard = new AdminDashboard(user);
                    adminDashboard.setSize(900, 650);
                    adminDashboard.setLocationRelativeTo(null);
                    adminDashboard.setVisible(true);
                    System.out.println("Admin dashboard created and set visible");
                } else {
                    // Create and show user dashboard
                    UserDashboard userDashboard = new UserDashboard(user);
                    userDashboard.setSize(800, 600);
                    userDashboard.setLocationRelativeTo(null);
                    userDashboard.setVisible(true);
                    System.out.println("User dashboard created and set visible");
                }
                
                // Close the login window
                dispose();
            } else {
                statusLabel.setText("Invalid username or password");
                statusLabel.setForeground(ERROR_COLOR);
            }
        } catch (Exception ex) {
            statusLabel.setText("Error: " + ex.getMessage());
            System.err.println("Exception in login: " + ex.getMessage());
        }
    }
    
    private void openRegistrationFrame() {
        new RegistrationFrame().setVisible(true);
        dispose(); // Close login window
    }
    
    public static void main(String[] args) {
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }
}
