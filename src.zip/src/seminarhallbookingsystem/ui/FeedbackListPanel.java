package seminarhallbookingsystem.ui;

import seminarhallbookingsystem.dao.FeedbackDAO;
import seminarhallbookingsystem.models.Feedback;

import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;
import javax.swing.BoxLayout;

/**
 * Enhanced Panel component for displaying a list of feedback with filtering options
 */
public class FeedbackListPanel extends Panel {
    private Frame parentFrame;
    private List<Feedback> feedbackList;
    private Panel feedbackContainer;
    private boolean isAdmin;
    private int hallId; // Optional, for filtering by hall
    
    // Filters
    private Choice ratingFilter;
    private TextField searchField;
    private Button filterButton;
    private Button resetButton;
    
    // Colors - matching the application theme
    private final Color PRIMARY_COLOR = new Color(70, 130, 180);  // Steel blue
    private final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Light gray
    private final Color CARD_BACKGROUND = new Color(255, 255, 255); // White for cards
    private final Color TEXT_COLOR = new Color(25, 25, 25);       // Near black
    private final Color SECONDARY_BG = new Color(230, 240, 250);  // Light blue
    private final Color ACCENT_COLOR = new Color(255, 165, 0);    // Orange for ratings
    private final Color ERROR_COLOR = new Color(178, 34, 34);     // Firebrick red
    private final Color SUCCESS_COLOR = new Color(46, 139, 87);   // Sea green
    private final Color HOVER_COLOR = new Color(60, 110, 160);    // Darker primary
    
    /**
     * Constructor for all feedback
     * @param parentFrame The parent frame
     * @param isAdmin Whether the user is an admin
     */
    public FeedbackListPanel(Frame parentFrame, boolean isAdmin) {
        this(parentFrame, isAdmin, 0);
    }
    
    /**
     * Constructor with hall filter
     * @param parentFrame The parent frame
     * @param isAdmin Whether the user is an admin
     * @param hallId The hall ID to filter by (0 for all halls)
     */
    public FeedbackListPanel(Frame parentFrame, boolean isAdmin, int hallId) {
        this.parentFrame = parentFrame;
        this.isAdmin = isAdmin;
        this.hallId = hallId;
        
        setLayout(new BorderLayout(10, 10));
        setBackground(BACKGROUND_COLOR);
        
        // Header Panel with improved styling
        Panel headerPanel = new Panel(new BorderLayout(0, 10));
        headerPanel.setBackground(BACKGROUND_COLOR);
        
        // Title label
        Label headerLabel = new Label(hallId > 0 ? "Feedback for Hall" : "All Feedback", Label.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerLabel.setForeground(PRIMARY_COLOR);
        
        // Separator
        Canvas separator = new Canvas();
        separator.setBackground(Color.LIGHT_GRAY);
        separator.setSize(getWidth(), 1);
        
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.add(headerLabel, BorderLayout.CENTER);
        titlePanel.add(separator, BorderLayout.SOUTH);
        titlePanel.setBackground(BACKGROUND_COLOR);
        
        headerPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Filter panel with improved styling
        Panel filterPanel = new Panel(new GridBagLayout());
        filterPanel.setBackground(SECONDARY_BG);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Rating filter with improved styling
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        
        Label ratingLabel = new Label("Rating:", Label.LEFT);
        ratingLabel.setFont(new Font("Arial", Font.BOLD, 14));
        ratingLabel.setForeground(TEXT_COLOR);
        filterPanel.add(ratingLabel, gbc);
        
        ratingFilter = new Choice();
        ratingFilter.setFont(new Font("Arial", Font.PLAIN, 14));
        ratingFilter.add("All Ratings");
        ratingFilter.add("5 Stars");
        ratingFilter.add("4 Stars");
        ratingFilter.add("3 Stars");
        ratingFilter.add("2 Stars");
        ratingFilter.add("1 Star");
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        filterPanel.add(ratingFilter, gbc);
        
        // Search field with improved styling
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        
        Label searchLabel = new Label("Search:", Label.LEFT);
        searchLabel.setFont(new Font("Arial", Font.BOLD, 14));
        searchLabel.setForeground(TEXT_COLOR);
        filterPanel.add(searchLabel, gbc);
        
        searchField = new TextField(20);
        searchField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        filterPanel.add(searchField, gbc);
        
        // Button panel with improved styling
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(SECONDARY_BG);
        
        filterButton = new Button("Apply Filters");
        filterButton.setBackground(PRIMARY_COLOR);
        filterButton.setForeground(Color.WHITE);
        filterButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        resetButton = new Button("Reset");
        resetButton.setBackground(Color.WHITE);
        resetButton.setForeground(PRIMARY_COLOR);
        resetButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Add hover effects to buttons
        MouseAdapter buttonHover = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                Button button = (Button) e.getSource();
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
                
                if (button == filterButton) {
                    button.setBackground(HOVER_COLOR);
                } else if (button == resetButton) {
                    button.setBackground(new Color(240, 240, 240));
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                Button button = (Button) e.getSource();
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                
                if (button == filterButton) {
                    button.setBackground(PRIMARY_COLOR);
                } else if (button == resetButton) {
                    button.setBackground(Color.WHITE);
                }
            }
        };
        
        filterButton.addMouseListener(buttonHover);
        resetButton.addMouseListener(buttonHover);
        
        buttonPanel.add(filterButton);
        buttonPanel.add(resetButton);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        filterPanel.add(buttonPanel, gbc);
        
        headerPanel.add(filterPanel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);
        
        // Feedback container with improved styling
        feedbackContainer = new Panel();
        feedbackContainer.setLayout(new BoxLayout(feedbackContainer, BoxLayout.Y_AXIS));
        feedbackContainer.setBackground(BACKGROUND_COLOR);
        
        ScrollPane scrollPane = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
        scrollPane.add(feedbackContainer);
        
        add(scrollPane, BorderLayout.CENTER);
        
        // Load feedback
        loadFeedback();
        
        // Add action listeners
        filterButton.addActionListener(e -> applyFilters());
        resetButton.addActionListener(e -> resetFilters());
        
        // Add Enter key listener for search field
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    applyFilters();
                }
            }
        });
    }
    
    /**
     * Load feedback data from the database
     */
    private void loadFeedback() {
        FeedbackDAO feedbackDAO = new FeedbackDAO();
        
        if (hallId > 0) {
            feedbackList = feedbackDAO.getFeedbackByHallId(hallId);
        } else {
            feedbackList = feedbackDAO.getAllFeedback();
        }
        
        displayFeedback(feedbackList);
    }
    
    /**
     * Display the provided list of feedback
     * @param feedbackToDisplay The list of feedback to display
     */
    private void displayFeedback(List<Feedback> feedbackToDisplay) {
        feedbackContainer.removeAll();
        
        if (feedbackToDisplay.isEmpty()) {
            Panel emptyPanel = new Panel(new BorderLayout());
            emptyPanel.setBackground(CARD_BACKGROUND);
            
            Label emptyLabel = new Label("No feedback available", Label.CENTER);
            emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            emptyLabel.setForeground(Color.GRAY);
            
            emptyPanel.add(emptyLabel, BorderLayout.CENTER);
            emptyPanel.setSize(feedbackContainer.getWidth(), 100);
            
            feedbackContainer.add(emptyPanel);
        } else {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy, HH:mm");
            
            for (Feedback feedback : feedbackToDisplay) {
                // Create a card-style panel for each feedback
                Panel feedbackCard = new Panel();
                feedbackCard.setLayout(new BorderLayout(0, 10));
                feedbackCard.setBackground(CARD_BACKGROUND);
                
                // Card Header with user info and date
                Panel cardHeader = new Panel(new BorderLayout(10, 0));
                cardHeader.setBackground(PRIMARY_COLOR);
                cardHeader.setForeground(Color.WHITE);
                
                Label userLabel = new Label(" User: " + feedback.getUserName(), Label.LEFT);
                userLabel.setFont(new Font("Arial", Font.BOLD, 14));
                userLabel.setForeground(Color.WHITE);
                
                Label dateLabel = new Label(dateFormat.format(feedback.getCreatedAt()) + " ", Label.RIGHT);
                dateLabel.setFont(new Font("Arial", Font.PLAIN, 12));
                dateLabel.setForeground(Color.WHITE);
                
                cardHeader.add(userLabel, BorderLayout.WEST);
                cardHeader.add(dateLabel, BorderLayout.EAST);
                
                feedbackCard.add(cardHeader, BorderLayout.NORTH);
                
                // Card Content
                Panel cardContent = new Panel();
                cardContent.setLayout(new BorderLayout(15, 10));
                cardContent.setBackground(CARD_BACKGROUND);
                
                // Left side with rating and event details
                Panel infoPanel = new Panel(new GridLayout(0, 1, 0, 5));
                infoPanel.setBackground(CARD_BACKGROUND);
                
                // Rating display with stars
                Panel ratingPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 5, 0));
                ratingPanel.setBackground(CARD_BACKGROUND);
                
                Label ratingPrefixLabel = new Label("Rating:", Label.LEFT);
                ratingPrefixLabel.setFont(new Font("Arial", Font.BOLD, 14));
                ratingPanel.add(ratingPrefixLabel);
                
                // Add star icons based on rating
                for (int i = 0; i < 5; i++) {
                    Label starLabel = new Label(i < feedback.getRating() ? "★" : "☆");
                    starLabel.setFont(new Font("Arial", Font.BOLD, 16));
                    starLabel.setForeground(ACCENT_COLOR);
                    ratingPanel.add(starLabel);
                }
                
                // Event and hall info
                Panel eventPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
                eventPanel.setBackground(CARD_BACKGROUND);
                
                Label eventLabel = new Label("Event: " + feedback.getEventName());
                eventLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                eventPanel.add(eventLabel);
                
                Panel hallPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
                hallPanel.setBackground(CARD_BACKGROUND);
                
                Label hallLabel = new Label("Hall: " + feedback.getHallName());
                hallLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                hallPanel.add(hallLabel);
                
                infoPanel.add(ratingPanel);
                infoPanel.add(eventPanel);
                infoPanel.add(hallPanel);
                
                // Comment section
                Panel commentPanel = new Panel(new BorderLayout(5, 5));
                commentPanel.setBackground(CARD_BACKGROUND);
                
                Label commentHeader = new Label("Comments:", Label.LEFT);
                commentHeader.setFont(new Font("Arial", Font.BOLD, 14));
                commentPanel.add(commentHeader, BorderLayout.NORTH);
                
                TextArea commentText = new TextArea(feedback.getComment(), 3, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
                commentText.setEditable(false);
                commentText.setBackground(new Color(250, 250, 250));
                commentText.setFont(new Font("Arial", Font.PLAIN, 14));
                commentPanel.add(commentText, BorderLayout.CENTER);
                
                // Add to content panel
                cardContent.add(infoPanel, BorderLayout.NORTH);
                cardContent.add(commentPanel, BorderLayout.CENTER);
                
                // Add padding to card content
                Panel paddedContent = new Panel(new BorderLayout());
                paddedContent.setBackground(CARD_BACKGROUND);
                paddedContent.add(cardContent, BorderLayout.CENTER);
                
                // Create empty borders by using panels with background color
                Panel leftPadding = new Panel();
                leftPadding.setBackground(CARD_BACKGROUND);
                leftPadding.setPreferredSize(new Dimension(15, 0));
                
                Panel rightPadding = new Panel();
                rightPadding.setBackground(CARD_BACKGROUND);
                rightPadding.setPreferredSize(new Dimension(15, 0));
                
                Panel topPadding = new Panel();
                topPadding.setBackground(CARD_BACKGROUND);
                topPadding.setPreferredSize(new Dimension(0, 10));
                
                Panel bottomPadding = new Panel();
                bottomPadding.setBackground(CARD_BACKGROUND);
                bottomPadding.setPreferredSize(new Dimension(0, 10));
                
                paddedContent.add(leftPadding, BorderLayout.WEST);
                paddedContent.add(rightPadding, BorderLayout.EAST);
                paddedContent.add(topPadding, BorderLayout.NORTH);
                paddedContent.add(bottomPadding, BorderLayout.SOUTH);
                
                feedbackCard.add(paddedContent, BorderLayout.CENTER);
                
                // Admin actions
                if (isAdmin) {
                    Panel actionsPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
                    actionsPanel.setBackground(CARD_BACKGROUND);
                    
                    Button deleteButton = new Button("Delete Feedback");
                    deleteButton.setFont(new Font("Arial", Font.BOLD, 12));
                    deleteButton.setBackground(ERROR_COLOR);
                    deleteButton.setForeground(Color.WHITE);
                    
                    final int feedbackId = feedback.getFeedbackId();
                    deleteButton.addActionListener(e -> deleteFeedback(feedbackId));
                    
                    // Hover effect
                    deleteButton.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseEntered(MouseEvent e) {
                            deleteButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                            deleteButton.setBackground(new Color(150, 20, 20)); // Darker red
                        }
                        
                        @Override
                        public void mouseExited(MouseEvent e) {
                            deleteButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                            deleteButton.setBackground(ERROR_COLOR);
                        }
                    });
                    
                    actionsPanel.add(deleteButton);
                    feedbackCard.add(actionsPanel, BorderLayout.SOUTH);
                }
                
                // Add each feedback card to the container with spacing
                Panel cardContainer = new Panel(new BorderLayout(0, 15));
                cardContainer.setBackground(BACKGROUND_COLOR);
                cardContainer.add(feedbackCard, BorderLayout.CENTER);
                
                // Add a shadow effect (simulated with a line)
                Canvas shadow = new Canvas();
                shadow.setBackground(Color.LIGHT_GRAY);
                shadow.setSize(feedbackCard.getWidth(), 1);
                cardContainer.add(shadow, BorderLayout.SOUTH);
                
                feedbackContainer.add(cardContainer);
            }
        }
        
        feedbackContainer.validate();
        feedbackContainer.repaint();
    }
    
    /**
     * Apply filters to the feedback list
     */
    private void applyFilters() {
        // Filter by rating
        String ratingSelection = ratingFilter.getSelectedItem();
        final int ratingValue; // Must be final for use in lambda
        
        if (ratingSelection.startsWith("5")) {
            ratingValue = 5;
        } else if (ratingSelection.startsWith("4")) {
            ratingValue = 4;
        } else if (ratingSelection.startsWith("3")) {
            ratingValue = 3;
        } else if (ratingSelection.startsWith("2")) {
            ratingValue = 2;
        } else if (ratingSelection.startsWith("1")) {
            ratingValue = 1;
        } else {
            ratingValue = 0; // All ratings
        }
        
        // Filter by search text
        final String searchText = searchField.getText().trim().toLowerCase();
        
        // Apply filters using Java 8 streams
        List<Feedback> filteredList = feedbackList.stream()
            .filter(f -> ratingValue == 0 || f.getRating() == ratingValue)
            .filter(f -> searchText.isEmpty() || 
                         f.getComment().toLowerCase().contains(searchText) ||
                         f.getHallName().toLowerCase().contains(searchText) ||
                         f.getEventName().toLowerCase().contains(searchText) ||
                         f.getUserName().toLowerCase().contains(searchText))
            .collect(Collectors.toList());
        
        displayFeedback(filteredList);
    }
    
    /**
     * Reset all filters and display full feedback list
     */
    private void resetFilters() {
        ratingFilter.select(0); // All ratings
        searchField.setText("");
        displayFeedback(feedbackList);
    }
    
    /**
     * Delete a feedback entry (admin only)
     * @param feedbackId The ID of the feedback to delete
     */
    private void deleteFeedback(int feedbackId) {
        // Confirm deletion with improved dialog
        Dialog confirmDialog = new Dialog(parentFrame, "Confirm Deletion", true);
        confirmDialog.setLayout(new BorderLayout());
        confirmDialog.setSize(350, 180);
        confirmDialog.setLocationRelativeTo(parentFrame);
        confirmDialog.setBackground(BACKGROUND_COLOR);
        
        // Title panel
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(PRIMARY_COLOR);
        
        Label titleLabel = new Label("Confirm Deletion", Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        confirmDialog.add(titlePanel, BorderLayout.NORTH);
        
        // Content panel
        Panel contentPanel = new Panel(new BorderLayout(20, 20));
        contentPanel.setBackground(BACKGROUND_COLOR);
        
        Label confirmLabel = new Label("Are you sure you want to delete this feedback?", Label.CENTER);
        confirmLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        contentPanel.add(confirmLabel, BorderLayout.CENTER);
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        
        Button yesButton = new Button("Yes, Delete");
        yesButton.setBackground(ERROR_COLOR);
        yesButton.setForeground(Color.WHITE);
        yesButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        Button noButton = new Button("Cancel");
        noButton.setBackground(Color.WHITE);
        noButton.setForeground(PRIMARY_COLOR);
        noButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Add hover effects
        MouseAdapter dialogButtonHover = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                Button button = (Button) e.getSource();
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
                
                if (button == yesButton) {
                    button.setBackground(new Color(150, 20, 20)); // Darker red
                } else if (button == noButton) {
                    button.setBackground(new Color(240, 240, 240)); // Light gray
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                Button button = (Button) e.getSource();
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                
                if (button == yesButton) {
                    button.setBackground(ERROR_COLOR);
                } else if (button == noButton) {
                    button.setBackground(Color.WHITE);
                }
            }
        };
        
        yesButton.addMouseListener(dialogButtonHover);
        noButton.addMouseListener(dialogButtonHover);
        
        yesButton.addActionListener(e -> {
            confirmDialog.dispose();
            
            // Delete feedback
            FeedbackDAO feedbackDAO = new FeedbackDAO();
            boolean success = feedbackDAO.deleteFeedback(feedbackId);
            
            if (success) {
                showStatusDialog("Success", "Feedback deleted successfully", SUCCESS_COLOR);
                // Reload feedback
                loadFeedback();
            } else {
                showStatusDialog("Error", "Failed to delete feedback", ERROR_COLOR);
            }
        });
        
        noButton.addActionListener(e -> confirmDialog.dispose());
        
        buttonPanel.add(yesButton);
        buttonPanel.add(noButton);
        
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
        confirmDialog.add(contentPanel, BorderLayout.CENTER);
        
        // Add some padding
        Panel paddingEast = new Panel();
        paddingEast.setBackground(BACKGROUND_COLOR);
        paddingEast.setPreferredSize(new Dimension(20, 0));
        
        Panel paddingWest = new Panel();
        paddingWest.setBackground(BACKGROUND_COLOR);
        paddingWest.setPreferredSize(new Dimension(20, 0));
        
        Panel paddingSouth = new Panel();
        paddingSouth.setBackground(BACKGROUND_COLOR);
        paddingSouth.setPreferredSize(new Dimension(0, 20));
        
        confirmDialog.add(paddingEast, BorderLayout.EAST);
        confirmDialog.add(paddingWest, BorderLayout.WEST);
        confirmDialog.add(paddingSouth, BorderLayout.SOUTH);
        
        confirmDialog.setVisible(true);
    }
    
    /**
     * Show a status dialog with consistent styling
     */
    private void showStatusDialog(String title, String message, Color headerColor) {
        Dialog dialog = new Dialog(parentFrame, title, true);
        dialog.setLayout(new BorderLayout());
        dialog.setSize(300, 150);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setBackground(BACKGROUND_COLOR);
        
        // Title panel
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(headerColor);
        
        Label titleLabel = new Label(title, Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        
        dialog.add(titlePanel, BorderLayout.NORTH);
        
        // Message panel
        Panel messagePanel = new Panel(new BorderLayout(20, 20));
        messagePanel.setBackground(BACKGROUND_COLOR);
        
        Label messageLabel = new Label(message, Label.CENTER);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        messagePanel.add(messageLabel, BorderLayout.CENTER);
        
        Button okButton = new Button("OK");
        okButton.setBackground(PRIMARY_COLOR);
        okButton.setForeground(Color.WHITE);
        okButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Add hover effect
        okButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                okButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                okButton.setBackground(HOVER_COLOR);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                okButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                okButton.setBackground(PRIMARY_COLOR);
            }
        });
        
        okButton.addActionListener(e -> dialog.dispose());
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.add(okButton);
        
        messagePanel.add(buttonPanel, BorderLayout.SOUTH);
        dialog.add(messagePanel, BorderLayout.CENTER);
        
        // Add padding
        Panel paddingEast = new Panel();
        paddingEast.setBackground(BACKGROUND_COLOR);
        paddingEast.setPreferredSize(new Dimension(20, 0));
        
        Panel paddingWest = new Panel();
        paddingWest.setBackground(BACKGROUND_COLOR);
        paddingWest.setPreferredSize(new Dimension(20, 0));
        
        Panel paddingSouth = new Panel();
        paddingSouth.setBackground(BACKGROUND_COLOR);
        paddingSouth.setPreferredSize(new Dimension(0, 10));
        
        dialog.add(paddingEast, BorderLayout.EAST);
        dialog.add(paddingWest, BorderLayout.WEST);
        dialog.add(paddingSouth, BorderLayout.SOUTH);
        
        dialog.setVisible(true);
    }
    
    /**
     * Refresh the feedback list
     */
    public void refresh() {
        loadFeedback();
    }
}
