package seminarhallbookingsystem.ui;

import seminarhallbookingsystem.dao.FeedbackDAO;
import seminarhallbookingsystem.models.Booking;
import seminarhallbookingsystem.models.Feedback;
import seminarhallbookingsystem.models.User;

import java.awt.*;
import java.awt.event.*;

/**
 * Enhanced Feedback Form with improved UI
 */
public class FeedbackForm extends Dialog {
    private Booking booking;
    private User currentUser;
    private Runnable onFeedbackSubmitted;
    
    // UI components
    private Label titleLabel;
    private Label hallNameLabel;
    private Label eventNameLabel;
    private Panel starPanel;
    private TextArea commentArea;
    private Button submitButton;
    private Button cancelButton;
    private Label statusLabel;
    private Label ratingValueLabel;
    
    // Current rating value
    private int currentRating = 0;
    
    // Colors - matching the application theme
    private final Color PRIMARY_COLOR = new Color(70, 130, 180);  // Steel blue
    private final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Light gray
    private final Color TEXT_COLOR = new Color(25, 25, 25);       // Near black
    private final Color ERROR_COLOR = new Color(178, 34, 34);     // Firebrick red
    private final Color SUCCESS_COLOR = new Color(46, 139, 87);   // Sea green
    private final Color STAR_COLOR = new Color(255, 165, 0);      // Orange
    
    public FeedbackForm(Frame parent, Booking booking, User currentUser, Runnable onFeedbackSubmitted) {
        super(parent, "Provide Feedback", true);
        this.booking = booking;
        this.currentUser = currentUser;
        this.onFeedbackSubmitted = onFeedbackSubmitted;
        
        // Check if feedback already exists for this booking
        FeedbackDAO feedbackDAO = new FeedbackDAO();
        Feedback existingFeedback = feedbackDAO.getFeedbackByBookingId(booking.getBookingId());
        
        setSize(500, 500);
        setLocationRelativeTo(parent);
        setLayout(null); // Using absolute positioning for precise control
        setBackground(BACKGROUND_COLOR);
        
        Font titleFont = new Font("Arial", Font.BOLD, 18);
        Font labelFont = new Font("Arial", Font.BOLD, 14);
        Font contentFont = new Font("Arial", Font.PLAIN, 14);
        
        // Title with separator
        titleLabel = new Label(existingFeedback != null ? "Update Your Feedback" : "Rate Your Experience", Label.CENTER);
        titleLabel.setBounds(50, 30, 400, 30);
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(PRIMARY_COLOR);
        add(titleLabel);
        
        // Separator line
        Canvas separator = new Canvas();
        separator.setBounds(50, 70, 400, 1);
        separator.setBackground(Color.LIGHT_GRAY);
        add(separator);
        
        // Booking details
        Label hallPromptLabel = new Label("Hall:");
        hallPromptLabel.setBounds(80, 90, 100, 25);
        hallPromptLabel.setFont(labelFont);
        hallPromptLabel.setForeground(TEXT_COLOR);
        add(hallPromptLabel);
        
        hallNameLabel = new Label(booking.getHallName());
        hallNameLabel.setBounds(190, 90, 250, 25);
        hallNameLabel.setFont(contentFont);
        add(hallNameLabel);
        
        Label eventPromptLabel = new Label("Event:");
        eventPromptLabel.setBounds(80, 125, 100, 25);
        eventPromptLabel.setFont(labelFont);
        eventPromptLabel.setForeground(TEXT_COLOR);
        add(eventPromptLabel);
        
        eventNameLabel = new Label(booking.getEventName());
        eventNameLabel.setBounds(190, 125, 250, 25);
        eventNameLabel.setFont(contentFont);
        add(eventNameLabel);
        
        // Rating section
        Label ratingLabel = new Label("Rating:");
        ratingLabel.setBounds(80, 170, 100, 25);
        ratingLabel.setFont(labelFont);
        ratingLabel.setForeground(TEXT_COLOR);
        add(ratingLabel);
        
        // Star rating buttons
        Panel starsPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        starsPanel.setBounds(190, 165, 250, 35);
        starsPanel.setBackground(BACKGROUND_COLOR);
        
        Button[] starButtons = new Button[5];
        for (int i = 0; i < 5; i++) {
            final int rating = i + 1;
            starButtons[i] = new Button("☆");
            starButtons[i].setFont(new Font("Arial", Font.BOLD, 20));
            starButtons[i].setForeground(STAR_COLOR);
            
            // Add hover effect
            starButtons[i].addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    ((Button)e.getSource()).setCursor(new Cursor(Cursor.HAND_CURSOR));
                }
                
                @Override
                public void mouseExited(MouseEvent e) {
                    ((Button)e.getSource()).setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            });
            
            starButtons[i].addActionListener(e -> {
                setRating(rating);
                updateStarButtons(starButtons);
            });
            
            starsPanel.add(starButtons[i]);
        }
        add(starsPanel);
        
        // Rating value label
        ratingValueLabel = new Label("No Rating Selected", Label.LEFT);
        ratingValueLabel.setBounds(190, 200, 250, 25);
        ratingValueLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        add(ratingValueLabel);
        
        // Comment section
        Label commentLabel = new Label("Comments:");
        commentLabel.setBounds(80, 235, 100, 25);
        commentLabel.setFont(labelFont);
        commentLabel.setForeground(TEXT_COLOR);
        add(commentLabel);
        
        commentArea = new TextArea("", 5, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
        commentArea.setBounds(80, 270, 340, 100);
        commentArea.setFont(contentFont);
        add(commentArea);
        
        // Status label
        statusLabel = new Label("", Label.CENTER);
        statusLabel.setBounds(80, 385, 340, 25);
        statusLabel.setForeground(ERROR_COLOR);
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        add(statusLabel);
        
        // Buttons
        submitButton = new Button(existingFeedback != null ? "Update Feedback" : "Submit Feedback");
        submitButton.setBounds(120, 420, 120, 35);
        submitButton.setBackground(PRIMARY_COLOR);
        submitButton.setForeground(Color.WHITE);
        submitButton.setFont(labelFont);
        add(submitButton);
        
        cancelButton = new Button("Cancel");
        cancelButton.setBounds(260, 420, 120, 35);
        cancelButton.setBackground(Color.WHITE);
        cancelButton.setForeground(PRIMARY_COLOR);
        cancelButton.setFont(labelFont);
        add(cancelButton);
        
        // If feedback exists, populate the form
        if (existingFeedback != null) {
            setRating(existingFeedback.getRating());
            updateStarButtons(starButtons);
            ratingValueLabel.setText("Rating: " + existingFeedback.getRating() + " stars");
            commentArea.setText(existingFeedback.getComment());
        }
        
        // Add action listeners
        submitButton.addActionListener(e -> {
            if (submitFeedback(existingFeedback)) {
                statusLabel.setText("Feedback submitted successfully!");
                statusLabel.setForeground(SUCCESS_COLOR);
                
                // Delay before closing
                new Thread(() -> {
                    try {
                        Thread.sleep(1000);
                        dispose();
                        if (onFeedbackSubmitted != null) {
                            onFeedbackSubmitted.run();
                        }
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                    }
                }).start();
            }
        });
        
        cancelButton.addActionListener(e -> dispose());
        
        // Add hover effects to buttons
        MouseAdapter buttonHover = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                Button button = (Button) e.getSource();
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
                
                if (button == submitButton) {
                    button.setBackground(new Color(60, 110, 160)); // Darker primary color
                } else if (button == cancelButton) {
                    button.setBackground(new Color(240, 240, 240)); // Slight gray on hover
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                Button button = (Button) e.getSource();
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                
                if (button == submitButton) {
                    button.setBackground(PRIMARY_COLOR);
                } else if (button == cancelButton) {
                    button.setBackground(Color.WHITE);
                }
            }
        };
        
        submitButton.addMouseListener(buttonHover);
        cancelButton.addMouseListener(buttonHover);
        
        // Close on window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }
    
    private void setRating(int rating) {
        int oldRating = currentRating;
        currentRating = rating;
        firePropertyChange("rating", oldRating, currentRating);
        
        // Update rating value label
        if (currentRating > 0) {
            ratingValueLabel.setText("Rating: " + currentRating + " " + 
                    (currentRating == 1 ? "star" : "stars"));
        } else {
            ratingValueLabel.setText("No Rating Selected");
        }
    }
    
    private void updateStarButtons(Button[] buttons) {
        for (int i = 0; i < buttons.length; i++) {
            if (i < currentRating) {
                buttons[i].setLabel("★");  // Filled star
            } else {
                buttons[i].setLabel("☆");  // Empty star
            }
        }
    }
    
    private boolean submitFeedback(Feedback existingFeedback) {
        // Validate input
        if (currentRating == 0) {
            statusLabel.setText("Please select a rating before submitting");
            statusLabel.setForeground(ERROR_COLOR);
            return false;
        }
        
        String comment = commentArea.getText().trim();
        
        // Create or update feedback
        FeedbackDAO feedbackDAO = new FeedbackDAO();
        boolean success;
        
        if (existingFeedback != null) {
            // Update existing feedback
            existingFeedback.setRating(currentRating);
            existingFeedback.setComment(comment);
            success = feedbackDAO.updateFeedback(existingFeedback);
        } else {
            // Create new feedback
            Feedback newFeedback = new Feedback(
                booking.getBookingId(),
                currentUser.getUserId(),
                booking.getHallId(),
                currentRating,
                comment
            );
            success = feedbackDAO.createFeedback(newFeedback);
        }
        
        if (!success) {
            statusLabel.setText("Failed to submit feedback. Please try again.");
            statusLabel.setForeground(ERROR_COLOR);
            return false;
        }
        
        return true;
    }
}
