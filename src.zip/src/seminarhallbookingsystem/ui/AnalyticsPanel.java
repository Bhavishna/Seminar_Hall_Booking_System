package seminarhallbookingsystem.ui;

import seminarhallbookingsystem.dao.AnalyticsDAO;
import seminarhallbookingsystem.dao.BookingDAO;
import seminarhallbookingsystem.dao.HallDAO;
import seminarhallbookingsystem.dao.UserDAO;
import seminarhallbookingsystem.models.Booking;
import seminarhallbookingsystem.models.Hall;
import seminarhallbookingsystem.models.User;
import seminarhallbookingsystem.util.ReportGenerator;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

/**
 * Enhanced Analytics Panel with improved UI, maintaining compatibility
 * with the original implementation
 */
public class AnalyticsPanel extends Panel {
    private Frame parentFrame;
    private Panel mainPanel;
    private CardLayout cardLayout;
    
    // Constants for card names
    private static final String OVERVIEW_PANEL = "OVERVIEW";
    private static final String HALL_USAGE_PANEL = "HALL_USAGE";
    private static final String TIME_ANALYSIS_PANEL = "TIME_ANALYSIS";
    private static final String REPORT_GENERATOR_PANEL = "REPORT_GENERATOR";
    
    // Data for charts
    private BufferedImage hallUsageBarChart;
    private BufferedImage hallUsagePieChart;
    private BufferedImage dayOfWeekChart;
    private BufferedImage timeOfDayChart;
    
    // Colors - matching the application theme
    private final Color PRIMARY_COLOR = new Color(70, 130, 180);  // Steel blue
    private final Color DARK_PRIMARY = new Color(60, 110, 160);   // Darker blue for hover
    private final Color SECONDARY_COLOR = new Color(230, 240, 250); // Light blue
    private final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Light gray
    private final Color CARD_COLOR = new Color(255, 255, 255);    // White
    private final Color TEXT_COLOR = new Color(25, 25, 25);       // Near black
    private final Color ACCENT_GREEN = new Color(46, 139, 87);    // Sea green
    private final Color ACCENT_RED = new Color(178, 34, 34);      // Firebrick red
    private final Color ACCENT_PURPLE = new Color(123, 104, 238); // Medium slate blue
    
    /**
     * Constructor to ensure compatibility with the original implementation
     */
    public AnalyticsPanel(Frame parentFrame) {
        this.parentFrame = parentFrame;
        setupPanel();
    }
    
    /**
     * Extracted setup logic for better organization
     */
    private void setupPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(BACKGROUND_COLOR);
        
        // Create header with improved styling
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        
        Label headerLabel = new Label("Hall Usage Analytics & Reports", Label.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setBackground(PRIMARY_COLOR);
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        
        // Add padding to header
        Panel headerPadding = new Panel();
        headerPadding.setBackground(PRIMARY_COLOR);
        headerPadding.setPreferredSize(new Dimension(0, 10));
        headerPanel.add(headerPadding, BorderLayout.SOUTH);
        
        add(headerPanel, BorderLayout.NORTH);
        
        // Content panel with sidebar and main area
        Panel contentPanel = new Panel(new BorderLayout(0, 0));
        contentPanel.setBackground(BACKGROUND_COLOR);
        
        // Create sidebar with improved styling
        Panel sidebarPanel = createSidebarPanel();
        
        // Create main content area with card layout
        cardLayout = new CardLayout();
        mainPanel = new Panel(cardLayout);
        mainPanel.setBackground(BACKGROUND_COLOR);
        
        // Add cards to main panel
        mainPanel.add(createOverviewPanel(), OVERVIEW_PANEL);
        mainPanel.add(createHallUsagePanel(), HALL_USAGE_PANEL);
        mainPanel.add(createTimeAnalysisPanel(), TIME_ANALYSIS_PANEL);
        mainPanel.add(createReportGeneratorPanel(), REPORT_GENERATOR_PANEL);
        
        // Add sidebar and main panel to content
        contentPanel.add(sidebarPanel, BorderLayout.WEST);
        contentPanel.add(mainPanel, BorderLayout.CENTER);
        
        // Add content panel to main layout
        add(contentPanel, BorderLayout.CENTER);
        
        // Show the overview panel by default
        cardLayout.show(mainPanel, OVERVIEW_PANEL);
    }
    
    private Panel createSidebarPanel() {
        Panel sidebar = new Panel(new BorderLayout());
        sidebar.setBackground(SECONDARY_COLOR);
        sidebar.setPreferredSize(new Dimension(200, 600));
        
        // Title for sidebar
        Label sidebarTitle = new Label("Navigation", Label.CENTER);
        sidebarTitle.setFont(new Font("Arial", Font.BOLD, 14));
        sidebarTitle.setForeground(PRIMARY_COLOR);
        sidebarTitle.setBackground(SECONDARY_COLOR);
        
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(SECONDARY_COLOR);
        titlePanel.add(sidebarTitle, BorderLayout.CENTER);
        
        // Add padding to title
        Panel titlePadding = new Panel();
        titlePadding.setBackground(SECONDARY_COLOR);
        titlePadding.setPreferredSize(new Dimension(0, 20));
        titlePanel.add(titlePadding, BorderLayout.SOUTH);
        
        sidebar.add(titlePanel, BorderLayout.NORTH);
        
        // Create nav buttons panel
        Panel navPanel = new Panel();
        navPanel.setLayout(new GridLayout(6, 1, 0, 10));
        navPanel.setBackground(SECONDARY_COLOR);
        
        // Create styled menu buttons
        Button overviewButton = new Button("Dashboard Overview");
        overviewButton.setFont(new Font("Arial", Font.BOLD, 12));
        overviewButton.setBackground(SECONDARY_COLOR);
        overviewButton.setForeground(PRIMARY_COLOR);
        overviewButton.addActionListener(e -> cardLayout.show(mainPanel, OVERVIEW_PANEL));
        
        Button hallUsageButton = new Button("Hall Usage Statistics");
        hallUsageButton.setFont(new Font("Arial", Font.BOLD, 12));
        hallUsageButton.setBackground(SECONDARY_COLOR);
        hallUsageButton.setForeground(PRIMARY_COLOR);
        hallUsageButton.addActionListener(e -> cardLayout.show(mainPanel, HALL_USAGE_PANEL));
        
        Button timeAnalysisButton = new Button("Time-based Analysis");
        timeAnalysisButton.setFont(new Font("Arial", Font.BOLD, 12));
        timeAnalysisButton.setBackground(SECONDARY_COLOR);
        timeAnalysisButton.setForeground(PRIMARY_COLOR);
        timeAnalysisButton.addActionListener(e -> cardLayout.show(mainPanel, TIME_ANALYSIS_PANEL));
        
        Button reportGeneratorButton = new Button("Report Generator");
        reportGeneratorButton.setFont(new Font("Arial", Font.BOLD, 12));
        reportGeneratorButton.setBackground(SECONDARY_COLOR);
        reportGeneratorButton.setForeground(PRIMARY_COLOR);
        reportGeneratorButton.addActionListener(e -> cardLayout.show(mainPanel, REPORT_GENERATOR_PANEL));
        
        Button refreshButton = new Button("Refresh Data");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 12));
        refreshButton.setBackground(SECONDARY_COLOR);
        refreshButton.setForeground(PRIMARY_COLOR);
        refreshButton.addActionListener(e -> refreshData());
        
        // Add buttons to the panel with padding at top
        navPanel.add(new Label());  // Empty label for padding
        navPanel.add(overviewButton);
        navPanel.add(hallUsageButton);
        navPanel.add(timeAnalysisButton);
        navPanel.add(reportGeneratorButton);
        navPanel.add(refreshButton);
        
        // Add hover effects
        addButtonHoverEffect(overviewButton);
        addButtonHoverEffect(hallUsageButton);
        addButtonHoverEffect(timeAnalysisButton);
        addButtonHoverEffect(reportGeneratorButton);
        addButtonHoverEffect(refreshButton);
        
        sidebar.add(navPanel, BorderLayout.CENTER);
        
        return sidebar;
    }
    
    /**
     * Add hover effect to buttons
     */
    private void addButtonHoverEffect(Button button) {
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
                button.setBackground(CARD_COLOR);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                button.setBackground(SECONDARY_COLOR);
            }
        });
    }
    
    /**
     * Create an overview panel with stats
     */
    private Panel createOverviewPanel() {
        Panel panel = new Panel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.BOTH;
        
        // Get data for the cards
        BookingDAO bookingDAO = new BookingDAO();
        List<Booking> recentBookings = bookingDAO.getRecentBookings(5);
        
        HallDAO hallDAO = new HallDAO();
        List<Hall> halls = hallDAO.getAllHalls();
        
        AnalyticsDAO analyticsDAO = new AnalyticsDAO();
        Map<String, Integer> hallUsage = analyticsDAO.getHallUsageStatistics();
        
        UserDAO userDAO = new UserDAO();
        List<User> users = userDAO.getAllUsers();
        
        // Create dashboard title
        Label dashboardTitle = new Label("Analytics Dashboard", Label.LEFT);
        dashboardTitle.setFont(new Font("Arial", Font.BOLD, 18));
        dashboardTitle.setForeground(PRIMARY_COLOR);
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.weighty = 0.0;
        panel.add(dashboardTitle, gbc);
        
        // Booking stats card
        Panel bookingStatsPanel = createStatPanel("Booking Statistics", PRIMARY_COLOR);
        
        Panel bookingStatsContent = new Panel(new GridLayout(6, 2, 10, 5));
        bookingStatsContent.add(new Label("Total Bookings:", Label.RIGHT));
        bookingStatsContent.add(new Label(String.valueOf(bookingDAO.getAllBookings().size()), Label.LEFT));
        
        bookingStatsContent.add(new Label("Pending Bookings:", Label.RIGHT));
        bookingStatsContent.add(new Label(String.valueOf(bookingDAO.getBookingsByStatus("pending").size()), Label.LEFT));
        
        bookingStatsContent.add(new Label("Approved Bookings:", Label.RIGHT));
        bookingStatsContent.add(new Label(String.valueOf(bookingDAO.getBookingsByStatus("approved").size()), Label.LEFT));
        
        bookingStatsContent.add(new Label("Rejected Bookings:", Label.RIGHT));
        bookingStatsContent.add(new Label(String.valueOf(bookingDAO.getBookingsByStatus("rejected").size()), Label.LEFT));
        
        bookingStatsContent.add(new Label("Cancelled Bookings:", Label.RIGHT));
        bookingStatsContent.add(new Label(String.valueOf(bookingDAO.getBookingsByStatus("cancelled").size()), Label.LEFT));
        
        bookingStatsContent.add(new Label("Recent Bookings:", Label.RIGHT));
        bookingStatsContent.add(new Label(String.valueOf(recentBookings.size()), Label.LEFT));
        
        bookingStatsPanel.add(bookingStatsContent, BorderLayout.CENTER);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        panel.add(bookingStatsPanel, gbc);
        
        // Hall stats card
        Panel hallStatsPanel = createStatPanel("Hall Statistics", ACCENT_RED);
        
        // Find most used hall
        String mostUsedHall = "None";
        int maxUsage = 0;
        for (Map.Entry<String, Integer> entry : hallUsage.entrySet()) {
            if (entry.getValue() > maxUsage) {
                maxUsage = entry.getValue();
                mostUsedHall = entry.getKey();
            }
        }
        
        Panel hallStatsContent = new Panel(new GridLayout(3, 2, 10, 5));
        hallStatsContent.add(new Label("Total Halls:", Label.RIGHT));
        hallStatsContent.add(new Label(String.valueOf(halls.size()), Label.LEFT));
        
        hallStatsContent.add(new Label("Most Used Hall:", Label.RIGHT));
        hallStatsContent.add(new Label(mostUsedHall, Label.LEFT));
        
        hallStatsContent.add(new Label("Total Usage Count:", Label.RIGHT));
        int totalUsage = hallUsage.values().stream().mapToInt(Integer::intValue).sum();
        hallStatsContent.add(new Label(String.valueOf(totalUsage), Label.LEFT));
        
        hallStatsPanel.add(hallStatsContent, BorderLayout.CENTER);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(hallStatsPanel, gbc);
        
        // User stats card
        Panel userStatsPanel = createStatPanel("User Statistics", ACCENT_GREEN);
        
        long adminCount = users.stream().filter(User::isAdmin).count();
        
        Panel userStatsContent = new Panel(new GridLayout(3, 2, 10, 5));
        userStatsContent.add(new Label("Total Users:", Label.RIGHT));
        userStatsContent.add(new Label(String.valueOf(users.size()), Label.LEFT));
        
        userStatsContent.add(new Label("Administrators:", Label.RIGHT));
        userStatsContent.add(new Label(String.valueOf(adminCount), Label.LEFT));
        
        userStatsContent.add(new Label("Regular Users:", Label.RIGHT));
        userStatsContent.add(new Label(String.valueOf(users.size() - adminCount), Label.LEFT));
        
        userStatsPanel.add(userStatsContent, BorderLayout.CENTER);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(userStatsPanel, gbc);
        
        // Recent activity card
        Panel recentActivityPanel = createStatPanel("Recent Activity", ACCENT_PURPLE);
        
        // List recent bookings
        Panel recentActivityContent = new Panel(new BorderLayout());
        
        Label recentHeader = new Label("Recent Bookings:", Label.LEFT);
        recentHeader.setFont(new Font("Arial", Font.BOLD, 12));
        recentActivityContent.add(recentHeader, BorderLayout.NORTH);
        
        Panel bookingListPanel = new Panel(new GridLayout(5, 1, 0, 5));
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        
        for (Booking booking : recentBookings) {
            String bookingInfo = booking.getEventName() + " - " + booking.getHallName() + 
                               " (" + dateFormat.format(booking.getCreatedAt()) + ")";
            Label bookingLabel = new Label(bookingInfo, Label.LEFT);
            bookingListPanel.add(bookingLabel);
        }
        
        if (recentBookings.isEmpty()) {
            bookingListPanel.add(new Label("No recent bookings", Label.CENTER));
        }
        
        recentActivityContent.add(bookingListPanel, BorderLayout.CENTER);
        recentActivityPanel.add(recentActivityContent, BorderLayout.CENTER);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(recentActivityPanel, gbc);
        
        return panel;
    }
    
    private Panel createStatPanel(String title, Color color) {
        Panel panel = new Panel(new BorderLayout(0, 10));
        panel.setBackground(new Color(240, 240, 240));
        
        // Panel header
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(color);
        headerPanel.setPreferredSize(new Dimension(100, 30));
        
        Label titleLabel = new Label(title, Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        panel.add(headerPanel, BorderLayout.NORTH);
        
        return panel;
    }
    
    private Panel createHallUsagePanel() {
        Panel panel = new Panel(new BorderLayout(10, 10));
        
        // Create charts if not already created
        if (hallUsageBarChart == null || hallUsagePieChart == null) {
            AnalyticsDAO analyticsDAO = new AnalyticsDAO();
            Map<String, Integer> hallUsage = analyticsDAO.getHallUsageStatistics();
            
            hallUsageBarChart = ReportGenerator.createHallUsageBarChart(hallUsage);
            hallUsagePieChart = ReportGenerator.createHallUsagePieChart(hallUsage);
        }
        
        // Top section for title and export options
        Panel topPanel = new Panel(new BorderLayout());
        
        Label titleLabel = new Label("Hall Usage Statistics", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        topPanel.add(titleLabel, BorderLayout.WEST);
        
        Panel exportPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        Button exportBarChartButton = new Button("Download Bar Chart");
        Button exportPieChartButton = new Button("Download Pie Chart");
        
        // Add action listeners to download charts
        exportBarChartButton.addActionListener(e -> {
            ReportGenerator.downloadChart(hallUsageBarChart, "hall_usage_bar", parentFrame);
        });
        
        exportPieChartButton.addActionListener(e -> {
            ReportGenerator.downloadChart(hallUsagePieChart, "hall_usage_pie", parentFrame);
        });
        
        exportPanel.add(exportBarChartButton);
        exportPanel.add(exportPieChartButton);
        topPanel.add(exportPanel, BorderLayout.EAST);
        
        panel.add(topPanel, BorderLayout.NORTH);
        
        // Charts panel
        Panel chartsPanel = new Panel(new GridLayout(1, 2, 10, 10));
        
        // Bar chart
        Panel barChartPanel = new Panel(new BorderLayout());
        Label barChartLabel = new Label("Hall Usage (Bar Chart)", Label.CENTER);
        barChartLabel.setFont(new Font("Arial", Font.BOLD, 14));
        barChartPanel.add(barChartLabel, BorderLayout.NORTH);
        
        Canvas barChartCanvas = new Canvas() {
            @Override
            public void paint(Graphics g) {
                if (hallUsageBarChart != null) {
                    g.drawImage(hallUsageBarChart, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        barChartPanel.add(barChartCanvas, BorderLayout.CENTER);
        chartsPanel.add(barChartPanel);
        
        // Pie chart
        Panel pieChartPanel = new Panel(new BorderLayout());
        Label pieChartLabel = new Label("Hall Usage Distribution (Pie Chart)", Label.CENTER);
        pieChartLabel.setFont(new Font("Arial", Font.BOLD, 14));
        pieChartPanel.add(pieChartLabel, BorderLayout.NORTH);
        
        Canvas pieChartCanvas = new Canvas() {
            @Override
            public void paint(Graphics g) {
                if (hallUsagePieChart != null) {
                    g.drawImage(hallUsagePieChart, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        pieChartPanel.add(pieChartCanvas, BorderLayout.CENTER);
        chartsPanel.add(pieChartPanel);
        
        panel.add(chartsPanel, BorderLayout.CENTER);
        
        // Table view of the data
        Panel dataPanel = new Panel(new BorderLayout());
        
        Label dataLabel = new Label("Hall Usage Data", Label.LEFT);
        dataLabel.setFont(new Font("Arial", Font.BOLD, 14));
        dataPanel.add(dataLabel, BorderLayout.NORTH);
        
        Panel tablePanel = new Panel(new BorderLayout());
        
        AnalyticsDAO analyticsDAO = new AnalyticsDAO();
        Map<String, Integer> hallUsage = analyticsDAO.getHallUsageStatistics();
        
        Panel headerRow = new Panel(new GridLayout(1, 3));
        headerRow.add(new Label("Rank", Label.CENTER));
        headerRow.add(new Label("Hall Name", Label.CENTER));
        headerRow.add(new Label("Usage Count", Label.CENTER));
        tablePanel.add(headerRow, BorderLayout.NORTH);
        
        Panel dataRows = new Panel(new GridLayout(hallUsage.size(), 3));
        
        int rank = 1;
        for (Map.Entry<String, Integer> entry : hallUsage.entrySet()) {
            dataRows.add(new Label(String.valueOf(rank), Label.CENTER));
            dataRows.add(new Label(entry.getKey(), Label.LEFT));
            dataRows.add(new Label(String.valueOf(entry.getValue()), Label.CENTER));
            rank++;
        }
        
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.add(dataRows);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        dataPanel.add(tablePanel, BorderLayout.CENTER);
        panel.add(dataPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private Panel createTimeAnalysisPanel() {
        Panel panel = new Panel(new BorderLayout(10, 10));
        
        // Create charts if not already created
        if (dayOfWeekChart == null || timeOfDayChart == null) {
            AnalyticsDAO analyticsDAO = new AnalyticsDAO();
            Map<String, Integer> dayUsage = analyticsDAO.getUsageByDayOfWeek();
            Map<Integer, Integer> timeUsage = analyticsDAO.getUsageByTimeOfDay();
            
            dayOfWeekChart = ReportGenerator.createDayOfWeekChart(dayUsage);
            timeOfDayChart = ReportGenerator.createTimeOfDayChart(timeUsage);
        }
        
        // Top section for title and export options
        Panel topPanel = new Panel(new BorderLayout());
        
        Label titleLabel = new Label("Time-Based Analysis", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        topPanel.add(titleLabel, BorderLayout.WEST);
        
        Panel exportPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        Button exportDayChartButton = new Button("Download Day Chart");
        Button exportTimeChartButton = new Button("Download Time Chart");
        
        // Add action listeners to download charts
        exportDayChartButton.addActionListener(e -> {
            ReportGenerator.downloadChart(dayOfWeekChart, "day_of_week", parentFrame);
        });
        
        exportTimeChartButton.addActionListener(e -> {
            ReportGenerator.downloadChart(timeOfDayChart, "time_of_day", parentFrame);
        });
        
        exportPanel.add(exportDayChartButton);
        exportPanel.add(exportTimeChartButton);
        topPanel.add(exportPanel, BorderLayout.EAST);
        
        panel.add(topPanel, BorderLayout.NORTH);
        
        // Charts panel - vertical layout this time
        Panel chartsPanel = new Panel(new GridLayout(2, 1, 10, 10));
        
        // Day of week chart
        Panel dayChartPanel = new Panel(new BorderLayout());
        Label dayChartLabel = new Label("Bookings by Day of Week", Label.CENTER);
        dayChartLabel.setFont(new Font("Arial", Font.BOLD, 14));
        dayChartPanel.add(dayChartLabel, BorderLayout.NORTH);
        
        Canvas dayChartCanvas = new Canvas() {
            @Override
            public void paint(Graphics g) {
                if (dayOfWeekChart != null) {
                    g.drawImage(dayOfWeekChart, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        dayChartPanel.add(dayChartCanvas, BorderLayout.CENTER);
        chartsPanel.add(dayChartPanel);
        
        // Time of day chart
        Panel timeChartPanel = new Panel(new BorderLayout());
        Label timeChartLabel = new Label("Bookings by Time of Day", Label.CENTER);
        timeChartLabel.setFont(new Font("Arial", Font.BOLD, 14));
        timeChartPanel.add(timeChartLabel, BorderLayout.NORTH);
        
        Canvas timeChartCanvas = new Canvas() {
            @Override
            public void paint(Graphics g) {
                if (timeOfDayChart != null) {
                    g.drawImage(timeOfDayChart, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        timeChartPanel.add(timeChartCanvas, BorderLayout.CENTER);
        chartsPanel.add(timeChartPanel);
        
        panel.add(chartsPanel, BorderLayout.CENTER);
        
        // Analysis summary
        Panel summaryPanel = new Panel(new BorderLayout(0, 10));
        summaryPanel.setBackground(new Color(240, 240, 240));
        
        Label summaryLabel = new Label("Usage Patterns Analysis", Label.LEFT);
        summaryLabel.setFont(new Font("Arial", Font.BOLD, 14));
        summaryPanel.add(summaryLabel, BorderLayout.NORTH);
        
        // Add analysis text - this would be dynamic based on actual data in a real implementation
        AnalyticsDAO analyticsDAO = new AnalyticsDAO();
        Map<String, Integer> dayUsage = analyticsDAO.getUsageByDayOfWeek();
        
        // Find busiest day
        String busiestDay = "None";
        int maxDayUsage = 0;
        for (Map.Entry<String, Integer> entry : dayUsage.entrySet()) {
            if (entry.getValue() > maxDayUsage) {
                maxDayUsage = entry.getValue();
                busiestDay = entry.getKey();
            }
        }
        
        // Find busiest hour
        Map<Integer, Integer> timeUsage = analyticsDAO.getUsageByTimeOfDay();
        int busiestHour = 0;
        int maxHourUsage = 0;
        for (Map.Entry<Integer, Integer> entry : timeUsage.entrySet()) {
            if (entry.getValue() > maxHourUsage) {
                maxHourUsage = entry.getValue();
                busiestHour = entry.getKey();
            }
        }
        
        Panel analysisPanel = new Panel(new GridLayout(3, 1, 0, 5));
        analysisPanel.add(new Label("Busiest day of the week: " + busiestDay + " (" + maxDayUsage + " bookings)"));
        analysisPanel.add(new Label("Busiest time of day: " + String.format("%02d:00", busiestHour) + " (" + maxHourUsage + " bookings)"));
        analysisPanel.add(new Label("Recommendation: Schedule maintenance outside these peak times."));
        
        summaryPanel.add(analysisPanel, BorderLayout.CENTER);
        panel.add(summaryPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private Panel createReportGeneratorPanel() {
        Panel panel = new Panel(new BorderLayout(10, 10));
        
        // Top panel for title
        Label titleLabel = new Label("Report Generator", Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        // Main form panel
        Panel formPanel = new Panel(new GridBagLayout());
        formPanel.setBackground(new Color(240, 240, 240));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Report type selection
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new Label("Report Type:"), gbc);
        
        Choice reportTypeChoice = new Choice();
        reportTypeChoice.add("Bookings by Date Range");
        reportTypeChoice.add("Bookings by Hall");
        reportTypeChoice.add("Bookings by User");
        reportTypeChoice.add("All Bookings");
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        formPanel.add(reportTypeChoice, gbc);
        
        // Date range selection (initially visible)
        Panel dateRangePanel = new Panel(new GridLayout(2, 2, 10, 5));
        dateRangePanel.add(new Label("Start Date (yyyy-mm-dd):"));
        TextField startDateField = new TextField(10);
        dateRangePanel.add(startDateField);
        
        dateRangePanel.add(new Label("End Date (yyyy-mm-dd):"));
        TextField endDateField = new TextField(10);
        dateRangePanel.add(endDateField);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(dateRangePanel, gbc);
        
        // Hall selection (initially invisible)
        Panel hallPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
        hallPanel.add(new Label("Select Hall:"));
        
        Choice hallChoice = new Choice();
        HallDAO hallDAO = new HallDAO();
        List<Hall> halls = hallDAO.getAllHalls();
        for (Hall hall : halls) {
            hallChoice.add(hall.getHallName() + " (ID: " + hall.getHallId() + ")");
        }
        
        hallPanel.add(hallChoice);
        hallPanel.setVisible(false);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(hallPanel, gbc);
        
        // User selection (initially invisible)
        Panel userPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
        userPanel.add(new Label("Select User:"));
        
        Choice userChoice = new Choice();
        UserDAO userDAO = new UserDAO();
        List<User> users = userDAO.getAllUsers();
        for (User user : users) {
            userChoice.add(user.getFullName() + " (ID: " + user.getUserId() + ")");
        }
        
        userPanel.add(userChoice);
        userPanel.setVisible(false);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(userPanel, gbc);
        
        // File format selection
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        formPanel.add(new Label("Export Format:"), gbc);
        
        Panel formatPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
        CheckboxGroup formatGroup = new CheckboxGroup();
        Checkbox pdfCheckbox = new Checkbox("PDF", formatGroup, true);
        Checkbox csvCheckbox = new Checkbox("CSV", formatGroup, false);
        
        formatPanel.add(pdfCheckbox);
        formatPanel.add(csvCheckbox);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        formPanel.add(formatPanel, gbc);
        
        // Status message
        Label statusLabel = new Label("", Label.LEFT);
        statusLabel.setForeground(Color.RED);
        
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        formPanel.add(statusLabel, gbc);
        
        // Generate button
        Button generateButton = new Button("Generate & Download Report");
        generateButton.setFont(new Font("Arial", Font.BOLD, 12));
        generateButton.setBackground(PRIMARY_COLOR);
        generateButton.setForeground(Color.WHITE);
        
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(generateButton, gbc);
        
        // Report type change listener
        reportTypeChoice.addItemListener(e -> {
            String selectedType = reportTypeChoice.getSelectedItem();
            
            dateRangePanel.setVisible(false);
            hallPanel.setVisible(false);
            userPanel.setVisible(false);
            
            if (selectedType.equals("Bookings by Date Range")) {
                dateRangePanel.setVisible(true);
            } else if (selectedType.equals("Bookings by Hall")) {
                hallPanel.setVisible(true);
            } else if (selectedType.equals("Bookings by User")) {
                userPanel.setVisible(true);
            }
            
            formPanel.validate();
            formPanel.repaint();
        });
        
        // Generate button click handler
        generateButton.addActionListener(e -> {
            statusLabel.setText("");
            
            String selectedType = reportTypeChoice.getSelectedItem();
            boolean isPdfFormat = pdfCheckbox.getState();
            List<Booking> reportBookings = null;
            
            try {
                BookingDAO bookingDAO = new BookingDAO();
                
                if (selectedType.equals("Bookings by Date Range")) {
                    // Validate date format
                    String startDateStr = startDateField.getText().trim();
                    String endDateStr = endDateField.getText().trim();
                    
                    if (startDateStr.isEmpty() || endDateStr.isEmpty()) {
                        statusLabel.setText("Please enter both start and end dates");
                        return;
                    }
                    
                    if (!startDateStr.matches("\\d{4}-\\d{2}-\\d{2}") || 
                        !endDateStr.matches("\\d{4}-\\d{2}-\\d{2}")) {
                        statusLabel.setText("Dates must be in format yyyy-mm-dd");
                        return;
                    }
                    
                    java.sql.Date startDate = java.sql.Date.valueOf(startDateStr);
                    java.sql.Date endDate = java.sql.Date.valueOf(endDateStr);
                    
                    if (startDate.after(endDate)) {
                        statusLabel.setText("Start date must be before or equal to end date");
                        return;
                    }
                    
                    AnalyticsDAO analyticsDAO = new AnalyticsDAO();
                    reportBookings = analyticsDAO.getBookingsByDateRange(startDate, endDate);
                    
                } else if (selectedType.equals("Bookings by Hall")) {
                    String selectedHall = hallChoice.getSelectedItem();
                    int hallId = Integer.parseInt(selectedHall.substring(selectedHall.lastIndexOf("ID: ") + 4, selectedHall.lastIndexOf(")")));
                    
                    AnalyticsDAO analyticsDAO = new AnalyticsDAO();
                    reportBookings = analyticsDAO.getBookingsByHall(hallId);
                    
                } else if (selectedType.equals("Bookings by User")) {
                    String selectedUser = userChoice.getSelectedItem();
                    int userId = Integer.parseInt(selectedUser.substring(selectedUser.lastIndexOf("ID: ") + 4, selectedUser.lastIndexOf(")")));
                    
                    AnalyticsDAO analyticsDAO = new AnalyticsDAO();
                    reportBookings = analyticsDAO.getBookingsByUser(userId);
                    
                } else { // All Bookings
                    reportBookings = bookingDAO.getAllBookings();
                }
                
                // Check if we have bookings
                if (reportBookings == null || reportBookings.isEmpty()) {
                    statusLabel.setText("No bookings found for the selected criteria");
                    return;
                }
                
                // Generate report title
                String reportTitle = "Booking Report: " + selectedType;
                
                // Download the report
                boolean success;
                if (isPdfFormat) {
                    success = ReportGenerator.downloadPDFReport(reportBookings, reportTitle, parentFrame);
                } else {
                    success = ReportGenerator.downloadCSVReport(reportBookings, parentFrame);
                }
                
                if (!success) {
                    statusLabel.setForeground(Color.RED);
                    statusLabel.setText("Download canceled or failed");
                }
                                // Handle success
                else {
                    statusLabel.setForeground(ACCENT_GREEN);
                    statusLabel.setText("Report generated successfully!");
                }
                
            } catch (Exception ex) {
                statusLabel.setForeground(Color.RED);
                statusLabel.setText("Error: " + ex.getMessage());
                ex.printStackTrace();
            }
        });
        
        // Add hover effect to generate button
        generateButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                generateButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                generateButton.setBackground(DARK_PRIMARY);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                generateButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                generateButton.setBackground(PRIMARY_COLOR);
            }
        });
        
        panel.add(formPanel, BorderLayout.CENTER);
        
        // Bottom panel with additional info
        Panel bottomPanel = new Panel(new BorderLayout());
        Label infoLabel = new Label("Note: All reports will be saved to your selected location", Label.CENTER);
        infoLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        bottomPanel.add(infoLabel, BorderLayout.CENTER);
        
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void refreshData() {
        // Clear cached charts
        hallUsageBarChart = null;
        hallUsagePieChart = null;
        dayOfWeekChart = null;
        timeOfDayChart = null;
        
        // Recreate panels
        mainPanel.removeAll();
        mainPanel.add(createOverviewPanel(), OVERVIEW_PANEL);
        mainPanel.add(createHallUsagePanel(), HALL_USAGE_PANEL);
        mainPanel.add(createTimeAnalysisPanel(), TIME_ANALYSIS_PANEL);
        mainPanel.add(createReportGeneratorPanel(), REPORT_GENERATOR_PANEL);
        
        // Show current panel
        String currentPanel = OVERVIEW_PANEL;
        
        // Force repaint
        mainPanel.validate();
        mainPanel.repaint();
        
        cardLayout.show(mainPanel, currentPanel);
        
        showInfoDialog("Data Refreshed", "Analytics data has been refreshed.");
    }
    
    private void showErrorDialog(String title, String message) {
        Dialog dialog = new Dialog(parentFrame, title, true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setSize(350, 150);
        
        Label messageLabel = new Label(message, Label.CENTER);
        dialog.add(messageLabel, BorderLayout.CENTER);
        
        Button okButton = new Button("OK");
        okButton.setBackground(PRIMARY_COLOR);
        okButton.setForeground(Color.WHITE);
        okButton.addActionListener(e -> dialog.dispose());
        
        // Add hover effect
        okButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                okButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                okButton.setBackground(DARK_PRIMARY);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                okButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                okButton.setBackground(PRIMARY_COLOR);
            }
        });
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(okButton);
        
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setVisible(true);
    }
    
    private void showInfoDialog(String title, String message) {
        Dialog dialog = new Dialog(parentFrame, title, true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setSize(350, 150);
        
        Label messageLabel = new Label(message, Label.CENTER);
        dialog.add(messageLabel, BorderLayout.CENTER);
        
        Button okButton = new Button("OK");
        okButton.setBackground(PRIMARY_COLOR);
        okButton.setForeground(Color.WHITE);
        okButton.addActionListener(e -> dialog.dispose());
        
        // Add hover effect
        okButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                okButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
                okButton.setBackground(DARK_PRIMARY);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                okButton.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                okButton.setBackground(PRIMARY_COLOR);
            }
        });
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(okButton);
        
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setLocationRelativeTo(parentFrame);
        dialog.setVisible(true);
    }
}
