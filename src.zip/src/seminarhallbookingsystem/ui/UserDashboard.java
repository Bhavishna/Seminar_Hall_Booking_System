package seminarhallbookingsystem.ui;

import seminarhallbookingsystem.dao.BookingDAO;
import seminarhallbookingsystem.dao.FeedbackDAO;
import seminarhallbookingsystem.dao.HallDAO;
import seminarhallbookingsystem.models.Booking;
import seminarhallbookingsystem.models.Feedback;
import seminarhallbookingsystem.models.Hall;
import seminarhallbookingsystem.models.User;
import seminarhallbookingsystem.util.ImageManager;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.BoxLayout;
import javax.swing.border.EmptyBorder;

public class UserDashboard extends Frame {
    // Colors
    private final Color PRIMARY_COLOR = new Color(41, 128, 185);
    private final Color SECONDARY_COLOR = new Color(52, 152, 219);
    private final Color ACCENT_COLOR = new Color(231, 76, 60);
    private final Color BG_COLOR = new Color(245, 245, 245);
    private final Color PANEL_BG = new Color(255, 255, 255);
    private final Color TEXT_PRIMARY = new Color(44, 62, 80);
    private final Color TEXT_SECONDARY = new Color(127, 140, 141);
    private final Color SUCCESS_COLOR = new Color(46, 204, 113);
    private final Color WARNING_COLOR = new Color(241, 196, 15);
    private final Color ERROR_COLOR = new Color(231, 76, 60);
    
    private User currentUser;
    private List<Hall> hallList;
    private List<Booking> userBookings;
    private Panel mainPanel;
    private CardLayout cardLayout;
    
    // Constants for card names
    private static final String VIEW_HALLS_PANEL = "VIEW_HALLS";
    private static final String MY_BOOKINGS_PANEL = "MY_BOOKINGS";
    private static final String BOOK_HALL_PANEL = "BOOK_HALL";
    private static final String EVENT_CALENDAR_PANEL = "EVENT_CALENDAR";
    private static final String MY_FEEDBACK_PANEL = "MY_FEEDBACK";
    
    // Keep track of active menu button
    private Button activeMenuButton;
    
    public UserDashboard(User user) {
        this.currentUser = user;
        
        // Load data from database
        HallDAO hallDao = new HallDAO();
        hallList = hallDao.getAllHalls();
        
        BookingDAO bookingDao = new BookingDAO();
        userBookings = bookingDao.getBookingsByUserId(currentUser.getUserId());
        
        // Setup frame
        setTitle("Seminar Hall Booking System");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setBackground(BG_COLOR);
        setLayout(new BorderLayout());
        
        // Create header panel
        Panel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        // Create sidebar panel
        Panel sidebarPanel = createSidebarPanel();
        add(sidebarPanel, BorderLayout.WEST);
        
        // Create main panel with card layout
        cardLayout = new CardLayout();
        mainPanel = new Panel(cardLayout);
        mainPanel.setBackground(BG_COLOR);
        
        // Add cards to main panel
        mainPanel.add(createViewHallsPanel(), VIEW_HALLS_PANEL);
        mainPanel.add(createMyBookingsPanel(), MY_BOOKINGS_PANEL);
        mainPanel.add(createBookHallPanel(), BOOK_HALL_PANEL);
        mainPanel.add(createEventCalendarPanel(), EVENT_CALENDAR_PANEL);
        mainPanel.add(createMyFeedbackPanel(), MY_FEEDBACK_PANEL);
        
        add(mainPanel, BorderLayout.CENTER);
        
        // Show the first card
        cardLayout.show(mainPanel, VIEW_HALLS_PANEL);
        
        // Handle window close
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                logout();
            }
        });
    }
    
    private Panel createHeaderPanel() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(PRIMARY_COLOR);
        panel.setPreferredSize(new Dimension(1000, 60));
        
        // Add padding to the panel
        Panel innerPanel = new Panel(new BorderLayout());
        innerPanel.setBackground(PRIMARY_COLOR);
        
        Label titleLabel = new Label("Seminar Hall Booking System", Label.LEFT);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        innerPanel.add(titleLabel, BorderLayout.WEST);
        
        Panel userInfoPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        userInfoPanel.setBackground(PRIMARY_COLOR);
        
        Label userLabel = new Label("Welcome, " + currentUser.getFullName());
        userLabel.setForeground(Color.WHITE);
        userLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        Button logoutButton = new Button("Logout");
        logoutButton.setBackground(ACCENT_COLOR);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.addActionListener(e -> logout());
        
        userInfoPanel.add(userLabel);
        userInfoPanel.add(logoutButton);
        innerPanel.add(userInfoPanel, BorderLayout.EAST);
        
        panel.add(innerPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private Panel createSidebarPanel() {
    Panel panel = new Panel(new BorderLayout());
    panel.setBackground(new Color(34, 49, 63));
    panel.setPreferredSize(new Dimension(200, 700));
    
    // Logo or user profile section
    Panel profilePanel = new Panel(new BorderLayout());
    profilePanel.setBackground(new Color(25, 35, 45));
    profilePanel.setPreferredSize(new Dimension(200, 100));
    
    Label userInitialLabel = new Label(getUserInitial(), Label.CENTER);
    userInitialLabel.setForeground(Color.WHITE);
    userInitialLabel.setFont(new Font("Arial", Font.BOLD, 36));
    
    Label userNameLabel = new Label(currentUser.getFullName(), Label.CENTER);
    userNameLabel.setForeground(Color.WHITE);
    userNameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
    
    Label userRoleLabel = new Label("User", Label.CENTER);
    userRoleLabel.setForeground(new Color(189, 195, 199));
    userRoleLabel.setFont(new Font("Arial", Font.ITALIC, 12));
    
    Panel userTextPanel = new Panel(new GridLayout(2, 1));
    userTextPanel.setBackground(new Color(25, 35, 45));
    userTextPanel.add(userNameLabel);
    userTextPanel.add(userRoleLabel);
    
    profilePanel.add(userInitialLabel, BorderLayout.CENTER);
    profilePanel.add(userTextPanel, BorderLayout.SOUTH);
    
    panel.add(profilePanel, BorderLayout.NORTH);
    
    // Navigation menu - FIX THE MENU BUTTONS
    Panel menuPanel = new Panel();
    menuPanel.setLayout(new GridLayout(8, 1, 0, 10));
    menuPanel.setBackground(new Color(34, 49, 63));
    
    // Add empty cell for spacing
    menuPanel.add(new Label(""));
    
    // View Halls button
    Button viewHallsButton = new Button("View Halls");
    viewHallsButton.setFont(new Font("Arial", Font.BOLD, 14));
    viewHallsButton.setForeground(Color.WHITE);
    viewHallsButton.setBackground(SECONDARY_COLOR); // Initially selected
    viewHallsButton.addActionListener(e -> {
        setActiveMenuButton(viewHallsButton);
        cardLayout.show(mainPanel, VIEW_HALLS_PANEL);
    });
    menuPanel.add(viewHallsButton);
    
    // My Bookings button
    Button myBookingsButton = new Button("My Bookings");
    myBookingsButton.setFont(new Font("Arial", Font.BOLD, 14));
    myBookingsButton.setForeground(Color.WHITE);
    myBookingsButton.setBackground(new Color(34, 49, 63));
    myBookingsButton.addActionListener(e -> {
        setActiveMenuButton(myBookingsButton);
        refreshMyBookings();
        cardLayout.show(mainPanel, MY_BOOKINGS_PANEL);
    });
    menuPanel.add(myBookingsButton);
    
    // Calendar button
    Button calendarButton = new Button("Event Calendar");
    calendarButton.setFont(new Font("Arial", Font.BOLD, 14));
    calendarButton.setForeground(Color.WHITE);
    calendarButton.setBackground(new Color(34, 49, 63));
    calendarButton.addActionListener(e -> {
        setActiveMenuButton(calendarButton);
        refreshCalendar();
        cardLayout.show(mainPanel, EVENT_CALENDAR_PANEL);
    });
    menuPanel.add(calendarButton);
    
    // Book Hall button
    Button bookHallButton = new Button("Book a Hall");
    bookHallButton.setFont(new Font("Arial", Font.BOLD, 14));
    bookHallButton.setForeground(Color.WHITE);
    bookHallButton.setBackground(new Color(34, 49, 63));
    bookHallButton.addActionListener(e -> {
        setActiveMenuButton(bookHallButton);
        cardLayout.show(mainPanel, BOOK_HALL_PANEL);
    });
    menuPanel.add(bookHallButton);
    
    // Feedback button
    Button myFeedbackButton = new Button("My Feedback");
    myFeedbackButton.setFont(new Font("Arial", Font.BOLD, 14));
    myFeedbackButton.setForeground(Color.WHITE);
    myFeedbackButton.setBackground(new Color(34, 49, 63));
    myFeedbackButton.addActionListener(e -> {
        setActiveMenuButton(myFeedbackButton);
        refreshMyFeedback();
        cardLayout.show(mainPanel, MY_FEEDBACK_PANEL);
    });
    menuPanel.add(myFeedbackButton);
    
    // Add empty cells for spacing
    menuPanel.add(new Label(""));
    menuPanel.add(new Label(""));
    
    panel.add(menuPanel, BorderLayout.CENTER);
    
    // Save the initial active button
    activeMenuButton = viewHallsButton;
    
    return panel;
}


    private Button createMenuButton(String text, ActionListener listener) {
        Button button = new Button(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(34, 49, 63));
        button.addActionListener(listener);
        return button;
    }
    
    private void setActiveMenuButton(Button button) {
        if (activeMenuButton != null) {
            activeMenuButton.setBackground(new Color(34, 49, 63));
        }
        button.setBackground(SECONDARY_COLOR);
        activeMenuButton = button;
    }
    
    private String getUserInitial() {
        if (currentUser.getFullName() != null && !currentUser.getFullName().isEmpty()) {
            return currentUser.getFullName().substring(0, 1).toUpperCase();
        }
        return "U";
    }
    
    private Panel createViewHallsPanel() {
    Panel panel = new Panel(new BorderLayout(0, 15));
    panel.setBackground(BG_COLOR);
    
    // Combined header with title and search
    Panel headerPanel = new Panel(new BorderLayout(0, 10));
    headerPanel.setBackground(BG_COLOR);
    
    // Title section
    Panel titlePanel = new Panel(new BorderLayout());
    titlePanel.setBackground(BG_COLOR);
    
    Label titleLabel = new Label("Available Seminar Halls", Label.LEFT);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
    titleLabel.setForeground(TEXT_PRIMARY);
    
    titlePanel.add(titleLabel, BorderLayout.WEST);
    
    // Search panel - COMPACT VERSION
    Panel searchPanel = new Panel(new BorderLayout(10, 10));
    searchPanel.setBackground(PANEL_BG);
    
    // Horizontal layout for search controls
    Panel searchControlsPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 5, 5));
    searchControlsPanel.setBackground(PANEL_BG);
    
    // Search type dropdown
    Label searchByLabel = new Label("Search by:");
    searchByLabel.setFont(new Font("Arial", Font.BOLD, 14));
    searchByLabel.setForeground(TEXT_PRIMARY);
    
    Choice searchTypeChoice = new Choice();
    searchTypeChoice.add("Select Search Criteria");
    searchTypeChoice.add("Hall Name");
    searchTypeChoice.add("Capacity");
    searchTypeChoice.add("Facilities/Requirements");
    
    // Create search option fields
    TextField nameField = new TextField(20);
    
    Panel capacityInputPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 5, 0));
    capacityInputPanel.setBackground(PANEL_BG);
    Label minLabel = new Label("Min:");
    TextField minCapacityField = new TextField(5);
    Label maxLabel = new Label("Max:");
    TextField maxCapacityField = new TextField(5);
    capacityInputPanel.add(minLabel);
    capacityInputPanel.add(minCapacityField);
    capacityInputPanel.add(maxLabel);
    capacityInputPanel.add(maxCapacityField);
    
    TextField facilitiesField = new TextField(20);
    
    // Search button
    Button searchButton = new Button("Search");
    searchButton.setBackground(PRIMARY_COLOR);
    searchButton.setForeground(Color.WHITE);
    
    // Reset button
    Button resetButton = new Button("Reset");
    resetButton.setBackground(TEXT_SECONDARY);
    resetButton.setForeground(Color.WHITE);
    resetButton.setVisible(false);
    
    // Add base controls that are always visible
    searchControlsPanel.add(searchByLabel);
    searchControlsPanel.add(searchTypeChoice);
    
    // Create a panel for the dynamically shown search field
    Panel dynamicFieldPanel = new Panel(new CardLayout());
    dynamicFieldPanel.setBackground(PANEL_BG);
    
    // Empty panel (default)
    Panel defaultPanel = new Panel();
    defaultPanel.setBackground(PANEL_BG);
    dynamicFieldPanel.add(defaultPanel, "DEFAULT");
    
    // Name search panel
    Panel nameSearchPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
    nameSearchPanel.setBackground(PANEL_BG);
    nameSearchPanel.add(new Label("Hall Name:"));
    nameSearchPanel.add(nameField);
    dynamicFieldPanel.add(nameSearchPanel, "NAME");
    
    // Capacity search panel
    Panel capacitySearchPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
    capacitySearchPanel.setBackground(PANEL_BG);
    capacitySearchPanel.add(capacityInputPanel);
    dynamicFieldPanel.add(capacitySearchPanel, "CAPACITY");
    
    // Facilities search panel
    Panel facilitiesSearchPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
    facilitiesSearchPanel.setBackground(PANEL_BG);
    facilitiesSearchPanel.add(new Label("Facilities:"));
    facilitiesSearchPanel.add(facilitiesField);
    dynamicFieldPanel.add(facilitiesSearchPanel, "FACILITIES");
    
    // Add dynamic field panel to controls
    searchControlsPanel.add(dynamicFieldPanel);
    searchControlsPanel.add(searchButton);
    searchControlsPanel.add(resetButton);
    
    searchPanel.add(searchControlsPanel, BorderLayout.CENTER);
    
    // Combine title and search in header
    headerPanel.add(titlePanel, BorderLayout.NORTH);
    headerPanel.add(searchPanel, BorderLayout.CENTER);
    
    // Main content area for hall listings
    Panel contentPanel = new Panel(new BorderLayout());
    contentPanel.setBackground(BG_COLOR);
    
    // Create a panel to hold all hall cards
    Panel hallsContainer = new Panel();
    hallsContainer.setLayout(new GridLayout(0, 2, 15, 15)); // Two columns of hall cards
    hallsContainer.setBackground(BG_COLOR);
    
    // Create scrollable view for halls
    ScrollPane scrollPane = new ScrollPane();
    scrollPane.setBackground(BG_COLOR);
    scrollPane.add(hallsContainer);
    
    contentPanel.add(scrollPane, BorderLayout.CENTER);
    
    // Add all components to main panel - NOW FIXED
    panel.add(headerPanel, BorderLayout.NORTH); // Header with title AND search
    panel.add(contentPanel, BorderLayout.CENTER); // Content takes most space
    
    // Get the CardLayout for dynamic fields
    CardLayout cardLayout = (CardLayout)(dynamicFieldPanel.getLayout());
    
    // Action listener for search type dropdown
    searchTypeChoice.addItemListener(e -> {
        String selected = searchTypeChoice.getSelectedItem();
        switch (selected) {
            case "Hall Name":
                cardLayout.show(dynamicFieldPanel, "NAME");
                nameField.requestFocus();
                break;
            case "Capacity":
                cardLayout.show(dynamicFieldPanel, "CAPACITY");
                minCapacityField.requestFocus();
                break;
            case "Facilities/Requirements":
                cardLayout.show(dynamicFieldPanel, "FACILITIES");
                facilitiesField.requestFocus();
                break;
            default:
                cardLayout.show(dynamicFieldPanel, "DEFAULT");
                break;
        }
        
        // Show reset button if search criteria selected
        resetButton.setVisible(!selected.equals("Select Search Criteria"));
    });
    
    // Function to display halls
    Runnable displayHalls = new Runnable() {
        @Override
        public void run() {
            hallsContainer.removeAll();
            
            if (hallList.isEmpty()) {
                Panel emptyPanel = new Panel(new BorderLayout());
                emptyPanel.setBackground(PANEL_BG);
                
                Label emptyLabel = new Label("No halls found matching your criteria.", Label.CENTER);
                emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
                emptyLabel.setForeground(TEXT_SECONDARY);
                
                emptyPanel.add(emptyLabel, BorderLayout.CENTER);
                hallsContainer.add(emptyPanel);
            } else {
                // Get hall ratings
                FeedbackDAO feedbackDAO = new FeedbackDAO();
                Map<Integer, Double> hallRatings = feedbackDAO.getAverageRatingsByHall();
                
                // For each hall, create a card-like panel
                for (Hall hall : hallList) {
                    Panel hallPanel = createHallCard(hall, hallRatings);
                    hallsContainer.add(hallPanel);
                }
            }
            
            // Force redraw
            hallsContainer.validate();
            scrollPane.validate();
        }
    };
    
    // Search button action
    searchButton.addActionListener(e -> {
        String searchType = searchTypeChoice.getSelectedItem();
        HallDAO hallDao = new HallDAO();
        
        if ("Select Search Criteria".equals(searchType)) {
            showInfoDialog("Please select a search criteria first", "Search Error");
            return;
        }
        
        switch (searchType) {
            case "Hall Name":
                String hallName = nameField.getText().trim();
                if (hallName.isEmpty()) {
                    showInfoDialog("Please enter a hall name to search", "Search Error");
                    return;
                }
                hallList = hallDao.searchHallsByNameAndCapacity(hallName, null, null);
                break;
                
            case "Capacity":
                Integer minCapacity = null;
                Integer maxCapacity = null;
                
                try {
                    if (!minCapacityField.getText().trim().isEmpty()) {
                        minCapacity = Integer.parseInt(minCapacityField.getText().trim());
                    }
                } catch (NumberFormatException ex) {
                    showInfoDialog("Please enter a valid minimum capacity (numeric value)", "Input Error");
                    return;
                }
                
                try {
                    if (!maxCapacityField.getText().trim().isEmpty()) {
                        maxCapacity = Integer.parseInt(maxCapacityField.getText().trim());
                    }
                } catch (NumberFormatException ex) {
                    showInfoDialog("Please enter a valid maximum capacity (numeric value)", "Input Error");
                    return;
                }
                
                if (minCapacity == null && maxCapacity == null) {
                    showInfoDialog("Please enter at least one capacity value", "Search Error");
                    return;
                }
                
                // Validate capacity range
                if (minCapacity != null && maxCapacity != null && minCapacity > maxCapacity) {
                    showInfoDialog("Minimum capacity cannot be greater than maximum capacity", "Input Error");
                    return;
                }
                
                hallList = hallDao.searchHallsByNameAndCapacity(null, minCapacity, maxCapacity);
                break;
                
            case "Facilities/Requirements":
                String facilities = facilitiesField.getText().trim();
                if (facilities.isEmpty()) {
                    showInfoDialog("Please enter facilities to search", "Search Error");
                    return;
                }
                hallList = hallDao.searchHalls(facilities);
                break;
        }
        
        // Display results
        displayHalls.run();
    });
    
    // Reset button action
    resetButton.addActionListener(e -> {
        // Clear all search fields
        nameField.setText("");
        minCapacityField.setText("");
        maxCapacityField.setText("");
        facilitiesField.setText("");
        
        // Reset dropdown
        searchTypeChoice.select(0);
        cardLayout.show(dynamicFieldPanel, "DEFAULT");
        
        // Hide reset button
        resetButton.setVisible(false);
        
        // Reset to all halls
        HallDAO hallDao = new HallDAO();
        hallList = hallDao.getAllHalls();
        
        // Display all halls
        displayHalls.run();
    });
    
    // Initial display of all halls
    displayHalls.run();
    
    return panel;
}


    private Panel createHallCard(Hall hall, Map<Integer, Double> hallRatings) {
        Panel hallPanel = new Panel(new BorderLayout(10, 10));
        hallPanel.setBackground(PANEL_BG);
        
        // Hall name header with rating
        Panel nameHeaderPanel = new Panel(new BorderLayout());
        nameHeaderPanel.setBackground(new Color(52, 73, 94));
        
        Label nameLabel = new Label(hall.getHallName(), Label.LEFT);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        nameLabel.setForeground(Color.WHITE);
        
        // Add rating if available
        Panel ratingPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        ratingPanel.setBackground(new Color(52, 73, 94));
        
        if (hallRatings.containsKey(hall.getHallId())) {
            double avgRating = hallRatings.get(hall.getHallId());
            String ratingText = String.format("★ %.1f", avgRating);
            Label ratingLabel = new Label(ratingText, Label.RIGHT);
            ratingLabel.setForeground(Color.ORANGE);
            ratingLabel.setFont(new Font("Arial", Font.BOLD, 14));
            ratingPanel.add(ratingLabel);
        }
        
        nameHeaderPanel.add(nameLabel, BorderLayout.WEST);
        nameHeaderPanel.add(ratingPanel, BorderLayout.EAST);
        
        // Left panel for image
        Panel leftPanel = new Panel(new BorderLayout());
        leftPanel.setBackground(PANEL_BG);
        leftPanel.setPreferredSize(new Dimension(200, 150));
        
        // Add image if available
        if (hall.getImagePath() != null && !hall.getImagePath().isEmpty()) {
            try {
                Image thumbnail = ImageManager.loadHallThumbnail(hall.getImagePath(), 180, 140);
                if (thumbnail != null) {
                    Canvas imageCanvas = new Canvas() {
                        @Override
                        public void paint(Graphics g) {
                            // Draw rounded rectangle border
                            g.setColor(PANEL_BG);
                            g.fillRect(0, 0, getWidth(), getHeight());
                            g.drawImage(thumbnail, 0, 0, this);
                        }
                    };
                    imageCanvas.setSize(180, 140);
                    
                    // Add click handler to view full size
                    imageCanvas.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent e) {
                            viewFullSizeImage(hall.getImagePath());
                        }
                    });
                    leftPanel.add(imageCanvas, BorderLayout.CENTER);
                } else {
                    Label noImageLabel = new Label("No Image Available", Label.CENTER);
                    noImageLabel.setFont(new Font("Arial", Font.ITALIC, 12));
                    noImageLabel.setForeground(TEXT_SECONDARY);
                    leftPanel.add(noImageLabel, BorderLayout.CENTER);
                }
            } catch (IOException ex) {
                Label errorLabel = new Label("Error Loading Image", Label.CENTER);
                errorLabel.setFont(new Font("Arial", Font.ITALIC, 12));
                errorLabel.setForeground(ERROR_COLOR);
                leftPanel.add(errorLabel, BorderLayout.CENTER);
            }
        } else {
            Label noImageLabel = new Label("No Image Available", Label.CENTER);
            noImageLabel.setFont(new Font("Arial", Font.ITALIC, 12));
            noImageLabel.setForeground(TEXT_SECONDARY);
            leftPanel.add(noImageLabel, BorderLayout.CENTER);
        }
        
        // Right panel for details
        Panel rightPanel = new Panel(new BorderLayout(5, 5));
        rightPanel.setBackground(PANEL_BG);
        
        Panel detailsPanel = new Panel(new GridLayout(0, 1, 5, 5));
        detailsPanel.setBackground(PANEL_BG);
        
        Label capacityLabel = new Label("Capacity: " + hall.getCapacity() + " people");
        capacityLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        capacityLabel.setForeground(TEXT_PRIMARY);
        
        Label facilitiesLabel = new Label("Facilities: " + getTruncatedText(hall.getFacilities(), 40));
        facilitiesLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        facilitiesLabel.setForeground(TEXT_PRIMARY);
        
        Label descriptionLabel = new Label("Description: " + getTruncatedText(hall.getDescription(), 60));
        descriptionLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        descriptionLabel.setForeground(TEXT_PRIMARY);
        
        detailsPanel.add(capacityLabel);
        detailsPanel.add(facilitiesLabel);
        detailsPanel.add(descriptionLabel);
        
        // Button panel with multiple actions
        Panel actionPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        actionPanel.setBackground(PANEL_BG);
        
        // View details button
        Button viewButton = new Button("View Details");
        viewButton.setBackground(SECONDARY_COLOR);
        viewButton.setForeground(Color.WHITE);
        viewButton.addActionListener(e -> viewHallDetails(hall));
        actionPanel.add(viewButton);
        
        // Book button
        Button bookButton = new Button("Book This Hall");
        bookButton.setBackground(PRIMARY_COLOR);
        bookButton.setForeground(Color.WHITE);
        
        bookButton.addActionListener(e -> {
            // Switch to booking panel
            cardLayout.show(mainPanel, BOOK_HALL_PANEL);
            // Pre-select this hall in booking form if you have that feature
        });
        actionPanel.add(bookButton);
        
        rightPanel.add(detailsPanel, BorderLayout.CENTER);
        rightPanel.add(actionPanel, BorderLayout.SOUTH);
        
        // Add all components to main panel
        hallPanel.add(nameHeaderPanel, BorderLayout.NORTH);
        hallPanel.add(leftPanel, BorderLayout.WEST);
        hallPanel.add(rightPanel, BorderLayout.CENTER);
        
        return hallPanel;
    }
    
    private String getTruncatedText(String text, int maxLength) {
        if (text == null) return "";
        return text.length() > maxLength ? text.substring(0, maxLength) + "..." : text;
    }
    
    private void viewHallDetails(Hall hall) {
        Dialog detailsDialog = new Dialog(this, "Hall Details", true);
        detailsDialog.setSize(800, 600);
        detailsDialog.setLocationRelativeTo(this);
        detailsDialog.setLayout(new BorderLayout());
        detailsDialog.setBackground(PANEL_BG);
        
        Panel contentPanel = new Panel(new BorderLayout(15, 15));
        contentPanel.setBackground(PANEL_BG);
        
        // Header with hall name
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(800, 60));
        
        Label titleLabel = new Label(hall.getHallName(), Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        // Main content area
        Panel mainContentPanel = new Panel(new BorderLayout(20, 0));
        mainContentPanel.setBackground(PANEL_BG);
        
        // Image panel on left
        Panel imagePanel = new Panel(new BorderLayout());
        imagePanel.setBackground(PANEL_BG);
        imagePanel.setPreferredSize(new Dimension(350, 250));
        
        // Add image if available
        if (hall.getImagePath() != null && !hall.getImagePath().isEmpty()) {
            try {
                Image fullImage = ImageManager.loadHallImage(hall.getImagePath());
                if (fullImage != null) {
                    // Create a scaled version to fit the panel
                    Image scaledImage = fullImage.getScaledInstance(350, 250, Image.SCALE_SMOOTH);
                    
                    Canvas imageCanvas = new Canvas() {
                        @Override
                        public void paint(Graphics g) {
                            g.drawImage(scaledImage, 0, 0, this);
                        }
                    };
                    imageCanvas.setSize(350, 250);
                    imagePanel.add(imageCanvas, BorderLayout.CENTER);
                } else {
                    Label noImageLabel = new Label("No Image Available", Label.CENTER);
                    noImageLabel.setFont(new Font("Arial", Font.ITALIC, 16));
                    noImageLabel.setForeground(TEXT_SECONDARY);
                    imagePanel.add(noImageLabel, BorderLayout.CENTER);
                }
            } catch (IOException ex) {
                Label errorLabel = new Label("Error Loading Image", Label.CENTER);
                errorLabel.setFont(new Font("Arial", Font.ITALIC, 16));
                errorLabel.setForeground(ERROR_COLOR);
                imagePanel.add(errorLabel, BorderLayout.CENTER);
            }
        } else {
            Label noImageLabel = new Label("No Image Available", Label.CENTER);
            noImageLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            noImageLabel.setForeground(TEXT_SECONDARY);
            imagePanel.add(noImageLabel, BorderLayout.CENTER);
        }
        
        // Hall info on right
        Panel infoPanel = new Panel(new BorderLayout(0, 15));
        infoPanel.setBackground(PANEL_BG);
        
        // Basic details section
        Panel detailsPanel = new Panel(new GridLayout(0, 2, 10, 10));
        detailsPanel.setBackground(PANEL_BG);
        
        // Add styled label pairs
        addDetailRow(detailsPanel, "Capacity:", hall.getCapacity() + " people");
        
        // Facilities with styled textarea
        Label facilitiesHeader = new Label("Facilities:");
        facilitiesHeader.setFont(new Font("Arial", Font.BOLD, 14));
        facilitiesHeader.setForeground(TEXT_PRIMARY);
        
        TextArea facilitiesArea = new TextArea(hall.getFacilities(), 3, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
        facilitiesArea.setEditable(false);
        facilitiesArea.setBackground(new Color(245, 245, 245));
        
        // Description with styled textarea
        Label descriptionHeader = new Label("Description:");
        descriptionHeader.setFont(new Font("Arial", Font.BOLD, 14));
        descriptionHeader.setForeground(TEXT_PRIMARY);
        
        TextArea descriptionArea = new TextArea(hall.getDescription(), 5, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
        descriptionArea.setEditable(false);
        descriptionArea.setBackground(new Color(245, 245, 245));
        
        // Add rating information
        FeedbackDAO feedbackDAO = new FeedbackDAO();
        Map<Integer, Double> hallRatings = feedbackDAO.getAverageRatingsByHall();
        
        Panel ratingPanel = new Panel(new BorderLayout(5, 5));
        ratingPanel.setBackground(new Color(240, 240, 240));
        
        Label ratingHeaderLabel = new Label("Rating & Reviews", Label.CENTER);
        ratingHeaderLabel.setFont(new Font("Arial", Font.BOLD, 16));
        ratingHeaderLabel.setForeground(TEXT_PRIMARY);
        ratingPanel.add(ratingHeaderLabel, BorderLayout.NORTH);
        
        if (hallRatings.containsKey(hall.getHallId())) {
            double avgRating = hallRatings.get(hall.getHallId());
            int stars = (int) Math.round(avgRating);
            
            StringBuilder starRating = new StringBuilder();
            for (int i = 0; i < 5; i++) {
                starRating.append(i < stars ? "★" : "☆");
            }
            
            Panel avgRatingPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
            avgRatingPanel.setBackground(new Color(240, 240, 240));
            
            Label starRatingLabel = new Label(starRating.toString());
            starRatingLabel.setFont(new Font("Arial", Font.BOLD, 24));
            starRatingLabel.setForeground(Color.ORANGE);
            
            Label avgRatingLabel = new Label(String.format("%.1f out of 5", avgRating));
            avgRatingLabel.setFont(new Font("Arial", Font.PLAIN, 16));
            avgRatingLabel.setForeground(TEXT_PRIMARY);
            
            avgRatingPanel.add(starRatingLabel);
            avgRatingPanel.add(avgRatingLabel);
            
            ratingPanel.add(avgRatingPanel, BorderLayout.CENTER);
            
            // Button to view all feedback
            Button viewFeedbackButton = new Button("Read All Reviews");
            viewFeedbackButton.setBackground(SECONDARY_COLOR);
            viewFeedbackButton.setForeground(Color.WHITE);
            viewFeedbackButton.addActionListener(e -> {
                detailsDialog.dispose();
                showHallFeedback(hall.getHallId(), hall.getHallName());
            });
            
            Panel feedbackButtonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
            feedbackButtonPanel.setBackground(new Color(240, 240, 240));
            feedbackButtonPanel.add(viewFeedbackButton);
            ratingPanel.add(feedbackButtonPanel, BorderLayout.SOUTH);
        } else {
            Panel noRatingPanel = new Panel(new BorderLayout());
            noRatingPanel.setBackground(new Color(240, 240, 240));
            
            Label noRatingLabel = new Label("No ratings yet", Label.CENTER);
            noRatingLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            noRatingLabel.setForeground(TEXT_SECONDARY);
            
            noRatingPanel.add(noRatingLabel, BorderLayout.CENTER);
            ratingPanel.add(noRatingPanel, BorderLayout.CENTER);
        }
        
        // Assemble details panel
        Panel facilitiesPanel = new Panel(new BorderLayout(0, 5));
        facilitiesPanel.setBackground(PANEL_BG);
        facilitiesPanel.add(facilitiesHeader, BorderLayout.NORTH);
        facilitiesPanel.add(facilitiesArea, BorderLayout.CENTER);
        
        Panel descriptionPanel = new Panel(new BorderLayout(0, 5));
        descriptionPanel.setBackground(PANEL_BG);
        descriptionPanel.add(descriptionHeader, BorderLayout.NORTH);
        descriptionPanel.add(descriptionArea, BorderLayout.CENTER);
        
        Panel infoContentPanel = new Panel(new BorderLayout(0, 15));
        infoContentPanel.setBackground(PANEL_BG);
        infoContentPanel.add(detailsPanel, BorderLayout.NORTH);
        infoContentPanel.add(facilitiesPanel, BorderLayout.CENTER);
        
        infoPanel.add(infoContentPanel, BorderLayout.CENTER);
        infoPanel.add(descriptionPanel, BorderLayout.SOUTH);
        
        // Add booking button
        Button bookButton = new Button("Book This Hall");
        bookButton.setBackground(PRIMARY_COLOR);
        bookButton.setForeground(Color.WHITE);
        bookButton.setFont(new Font("Arial", Font.BOLD, 14));
        bookButton.addActionListener(e -> {
            detailsDialog.dispose();
            cardLayout.show(mainPanel, BOOK_HALL_PANEL);
        });
        
        // Footer panel with buttons
        Panel buttonPanel = new Panel(new BorderLayout());
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.setPreferredSize(new Dimension(800, 100));
        
        Panel buttonsWrapper = new Panel(new BorderLayout());
        buttonsWrapper.setBackground(new Color(240, 240, 240));
        
        Panel actionButtonsPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        actionButtonsPanel.setBackground(new Color(240, 240, 240));
        
        Button closeButton = new Button("Close");
        closeButton.setBackground(TEXT_SECONDARY);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.addActionListener(e -> detailsDialog.dispose());
        
        actionButtonsPanel.add(bookButton);
        actionButtonsPanel.add(closeButton);
        
        buttonsWrapper.add(actionButtonsPanel, BorderLayout.CENTER);
        buttonsWrapper.add(ratingPanel, BorderLayout.NORTH);
        
        buttonPanel.add(buttonsWrapper, BorderLayout.CENTER);
        
        // Add all to dialog
        mainContentPanel.add(imagePanel, BorderLayout.WEST);
        mainContentPanel.add(infoPanel, BorderLayout.CENTER);
        
        contentPanel.add(mainContentPanel, BorderLayout.CENTER);
        
        detailsDialog.add(headerPanel, BorderLayout.NORTH);
        detailsDialog.add(contentPanel, BorderLayout.CENTER);
        detailsDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        detailsDialog.setVisible(true);
    }
    
    private void addDetailRow(Panel parent, String label, String value) {
        Label labelComponent = new Label(label);
        labelComponent.setFont(new Font("Arial", Font.BOLD, 14));
        labelComponent.setForeground(TEXT_PRIMARY);
        
        Label valueComponent = new Label(value);
        valueComponent.setFont(new Font("Arial", Font.PLAIN, 14));
        valueComponent.setForeground(TEXT_PRIMARY);
        
        parent.add(labelComponent);
        parent.add(valueComponent);
    }
    
        private void showHallFeedback(int hallId, String hallName) {
        Dialog feedbackDialog = new Dialog(this, "Feedback for " + hallName, true);
        feedbackDialog.setSize(700, 500);
        feedbackDialog.setLocationRelativeTo(this);
        feedbackDialog.setLayout(new BorderLayout());
        feedbackDialog.setBackground(PANEL_BG);
        
        // Header
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(700, 60));
        
        Label titleLabel = new Label("Reviews for " + hallName, Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        // Create feedback list panel
        FeedbackListPanel feedbackPanel = new FeedbackListPanel(this, false, hallId);
        
        // Add close button
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.setPreferredSize(new Dimension(700, 60));
        
        Button closeButton = new Button("Close");
        closeButton.setBackground(SECONDARY_COLOR);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Arial", Font.BOLD, 14));
        closeButton.addActionListener(e -> feedbackDialog.dispose());
        buttonPanel.add(closeButton);
        
        feedbackDialog.add(headerPanel, BorderLayout.NORTH);
        feedbackDialog.add(feedbackPanel, BorderLayout.CENTER);
        feedbackDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        feedbackDialog.setVisible(true);
    }
    
    private Panel createMyBookingsPanel() {
        Panel panel = new Panel(new BorderLayout(0, 15));
        panel.setBackground(BG_COLOR);
        
        // Panel title
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(BG_COLOR);
        
        Label titleLabel = new Label("My Bookings", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(TEXT_PRIMARY);
        
        titlePanel.add(titleLabel, BorderLayout.WEST);
        panel.add(titlePanel, BorderLayout.NORTH);
        
        // Main content
        Panel contentPanel = new Panel(new BorderLayout());
        contentPanel.setBackground(BG_COLOR);
        
        if (userBookings.isEmpty()) {
            Panel emptyPanel = new Panel(new BorderLayout());
            emptyPanel.setBackground(PANEL_BG);
            
            Label emptyLabel = new Label("You don't have any bookings yet.", Label.CENTER);
            emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            emptyLabel.setForeground(TEXT_SECONDARY);
            
            Panel emptyContent = new Panel(new BorderLayout());
            emptyContent.setBackground(PANEL_BG);
            emptyContent.add(emptyLabel, BorderLayout.CENTER);
            
            Button newBookingButton = new Button("Book a Hall Now");
            newBookingButton.setBackground(PRIMARY_COLOR);
            newBookingButton.setForeground(Color.WHITE);
            newBookingButton.setFont(new Font("Arial", Font.BOLD, 14));
            newBookingButton.addActionListener(e -> cardLayout.show(mainPanel, BOOK_HALL_PANEL));
            
            Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.setBackground(PANEL_BG);
            buttonPanel.add(newBookingButton);
            
            emptyContent.add(buttonPanel, BorderLayout.SOUTH);
            emptyPanel.add(emptyContent, BorderLayout.CENTER);
            
            contentPanel.add(emptyPanel, BorderLayout.CENTER);
        } else {
            // Create tabbed view for different booking statuses
            Panel tabsPanel = new Panel(new BorderLayout());
            tabsPanel.setBackground(PANEL_BG);
            
            Panel tabButtons = new Panel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            tabButtons.setBackground(PANEL_BG);
            
            CardLayout tabsCardLayout = new CardLayout();
            Panel tabsContent = new Panel(tabsCardLayout);
            tabsContent.setBackground(BG_COLOR);
            
            // Create tab buttons and content
            String[] tabs = {"All Bookings", "Pending", "Approved", "Rejected", "Cancelled"};
            Button[] tabButtonArray = new Button[tabs.length];
            
            for (int i = 0; i < tabs.length; i++) {
                String tabName = tabs[i];
                
                // Create filtered list of bookings
                List<Booking> filteredBookings;
                if (i == 0) {
                    filteredBookings = new ArrayList<>(userBookings); // All bookings
                } else {
                    String status = tabName.toLowerCase();
                    filteredBookings = userBookings.stream()
                        .filter(b -> b.getStatus().equals(status))
                        .collect(java.util.stream.Collectors.toList());
                }
                
                // Create tab button
                Button tabButton = new Button(tabName);
                tabButton.setFont(new Font("Arial", Font.BOLD, 14));
                
                if (i == 0) {
                    // Active by default
                    tabButton.setBackground(PRIMARY_COLOR);
                    tabButton.setForeground(Color.WHITE);
                } else {
                    tabButton.setBackground(new Color(220, 220, 220));
                    tabButton.setForeground(TEXT_PRIMARY);
                }
                
                final int tabIndex = i;
                tabButton.addActionListener(e -> {
                    // Update tab button appearances
                    for (int j = 0; j < tabButtonArray.length; j++) {
                        if (j == tabIndex) {
                            tabButtonArray[j].setBackground(PRIMARY_COLOR);
                            tabButtonArray[j].setForeground(Color.WHITE);
                        } else {
                            tabButtonArray[j].setBackground(new Color(220, 220, 220));
                            tabButtonArray[j].setForeground(TEXT_PRIMARY);
                        }
                    }
                    
                    // Show corresponding tab content
                    tabsCardLayout.show(tabsContent, tabName);
                });
                
                tabButtonArray[i] = tabButton;
                tabButtons.add(tabButton);
                
                // Create tab content panel
                Panel bookingsListPanel = createBookingsList(filteredBookings);
                tabsContent.add(bookingsListPanel, tabName);
            }
            
            tabsPanel.add(tabButtons, BorderLayout.NORTH);
            tabsPanel.add(tabsContent, BorderLayout.CENTER);
            
            contentPanel.add(tabsPanel, BorderLayout.CENTER);
        }
        
        // Add refresh button at the bottom
        Button refreshButton = new Button("Refresh Bookings");
        refreshButton.setBackground(SECONDARY_COLOR);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        refreshButton.addActionListener(e -> refreshMyBookings());
        
        Panel bottomPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(refreshButton);
        bottomPanel.setBackground(BG_COLOR);
        
        panel.add(contentPanel, BorderLayout.CENTER);
        panel.add(bottomPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private Panel createBookingsList(List<Booking> bookings) {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(BG_COLOR);
        
        if (bookings.isEmpty()) {
            Label emptyLabel = new Label("No bookings in this category", Label.CENTER);
            emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            emptyLabel.setForeground(TEXT_SECONDARY);
            panel.add(emptyLabel, BorderLayout.CENTER);
            return panel;
        }
        
        // Panel to hold all booking cards
        Panel bookingsPanel = new Panel();
        bookingsPanel.setLayout(new BoxLayout(bookingsPanel, BoxLayout.Y_AXIS));
        bookingsPanel.setBackground(BG_COLOR);
        
        for (Booking booking : bookings) {
            Panel bookingCard = createBookingCard(booking);
            bookingsPanel.add(bookingCard);
        }
        
        // Wrap in scroll pane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setBackground(BG_COLOR);
        scrollPane.add(bookingsPanel);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }
    
    private Panel createBookingCard(Booking booking) {
        Panel cardPanel = new Panel(new BorderLayout(0, 0));
        cardPanel.setBackground(PANEL_BG);
        
        // Status indicator bar at top
        Panel statusBarPanel = new Panel(new BorderLayout());
        Color statusColor;
        
        switch (booking.getStatus()) {
            case "approved":
                statusColor = SUCCESS_COLOR;
                break;
            case "rejected":
            case "declined":
                statusColor = ERROR_COLOR;
                break;
            case "cancelled":
                statusColor = TEXT_SECONDARY;
                break;
            default:
                statusColor = WARNING_COLOR; // Pending
                break;
        }
        
        statusBarPanel.setBackground(statusColor);
        statusBarPanel.setPreferredSize(new Dimension(600, 5));
        
        // Header with hall name and status
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(new Color(245, 245, 245));
        
        Label hallLabel = new Label(booking.getHallName(), Label.LEFT);
        hallLabel.setFont(new Font("Arial", Font.BOLD, 16));
        hallLabel.setForeground(TEXT_PRIMARY);
        
        String statusText = "Status: " + capitalizeFirstLetter(booking.getStatus());
        Label statusLabel = new Label(statusText, Label.RIGHT);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        statusLabel.setForeground(statusColor);
        
        headerPanel.add(hallLabel, BorderLayout.WEST);
        headerPanel.add(statusLabel, BorderLayout.EAST);
        
        // Main content with details
        Panel contentPanel = new Panel(new BorderLayout(15, 0));
        contentPanel.setBackground(PANEL_BG);
        
        // Left side - event details
        Panel detailsPanel = new Panel(new GridLayout(0, 1, 0, 5));
        detailsPanel.setBackground(PANEL_BG);
        
        Label eventLabel = new Label("Event: " + booking.getEventName());
        eventLabel.setFont(new Font("Arial", Font.BOLD, 14));
        eventLabel.setForeground(TEXT_PRIMARY);
        
        Label dateLabel = new Label("Date: " + booking.getBookingDate().toString());
        dateLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        dateLabel.setForeground(TEXT_PRIMARY);
        
        Label timeLabel = new Label("Time: " + booking.getStartTime().toString() + 
                                   " - " + booking.getEndTime().toString());
        timeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        timeLabel.setForeground(TEXT_PRIMARY);
        
        detailsPanel.add(eventLabel);
        detailsPanel.add(dateLabel);
        detailsPanel.add(timeLabel);
        
        // Add decline reason if status is declined/rejected
        if (("rejected".equals(booking.getStatus()) || "declined".equals(booking.getStatus())) 
                && booking.getDeclineReason() != null && !booking.getDeclineReason().isEmpty()) {
            Label reasonLabel = new Label("Reason: " + booking.getDeclineReason());
            reasonLabel.setFont(new Font("Arial", Font.ITALIC, 14));
            reasonLabel.setForeground(ERROR_COLOR);
            detailsPanel.add(reasonLabel);
        }
        
        contentPanel.add(detailsPanel, BorderLayout.CENTER);
        
        // Footer with action buttons
        Panel actionPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        actionPanel.setBackground(PANEL_BG);
        
        // Cancel button for pending/approved bookings
        if (booking.getStatus().equals("pending") || booking.getStatus().equals("approved")) {
            Button cancelButton = new Button("Cancel Booking");
            cancelButton.setBackground(ERROR_COLOR);
            cancelButton.setForeground(Color.WHITE);
            cancelButton.setFont(new Font("Arial", Font.BOLD, 12));
            
            final int bookingId = booking.getBookingId();
            cancelButton.addActionListener(e -> cancelBooking(bookingId));
            actionPanel.add(cancelButton);
        }
        
        // Add feedback button for completed bookings
        if (booking.getStatus().equals("approved")) {
            // Check if the booking date is in the past
            java.util.Date today = new java.util.Date();
            if (booking.getBookingDate().before(new java.sql.Date(today.getTime()))) {
                Button feedbackButton = new Button(booking.getHasFeedback() ? "Update Feedback" : "Provide Feedback");
                feedbackButton.setBackground(SUCCESS_COLOR);
                feedbackButton.setForeground(Color.WHITE);
                feedbackButton.setFont(new Font("Arial", Font.BOLD, 12));
                
                final Booking currentBooking = booking;
                feedbackButton.addActionListener(e -> showFeedbackForm(currentBooking));
                
                actionPanel.add(feedbackButton);
            }
        }
        
        // Assemble the card
        cardPanel.add(statusBarPanel, BorderLayout.NORTH);
        cardPanel.add(headerPanel, BorderLayout.CENTER);
        
        Panel bottomSection = new Panel(new BorderLayout());
        bottomSection.setBackground(PANEL_BG);
        bottomSection.add(contentPanel, BorderLayout.CENTER);
        bottomSection.add(actionPanel, BorderLayout.SOUTH);
        
        cardPanel.add(bottomSection, BorderLayout.SOUTH);
        
        // Wrap in a panel with margin
        Panel wrapperPanel = new Panel(new BorderLayout(0, 10));
        wrapperPanel.setBackground(BG_COLOR);
        wrapperPanel.add(cardPanel, BorderLayout.CENTER);
        
        return wrapperPanel;
    }
    
    private String capitalizeFirstLetter(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return text.substring(0, 1).toUpperCase() + text.substring(1);
    }
    
    private Panel createMyFeedbackPanel() {
        Panel panel = new Panel(new BorderLayout(0, 15));
        panel.setBackground(BG_COLOR);
        
        // Panel title
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(BG_COLOR);
        
        Label titleLabel = new Label("My Feedback & Ratings", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(TEXT_PRIMARY);
        
        titlePanel.add(titleLabel, BorderLayout.WEST);
        panel.add(titlePanel, BorderLayout.NORTH);
        
        // Main content
        Panel contentPanel = new Panel(new BorderLayout(0, 15));
        contentPanel.setBackground(BG_COLOR);
        
        // Get feedback data
        FeedbackDAO feedbackDAO = new FeedbackDAO();
        List<Feedback> userFeedback = feedbackDAO.getFeedbackByUserId(currentUser.getUserId());
        
        // Check if there are bookings eligible for feedback
        BookingDAO bookingDAO = new BookingDAO();
        List<Booking> pendingFeedbackBookings = bookingDAO.getCompletedBookingsWithoutFeedback(currentUser.getUserId());
        
        // Create panel for reminders if there are pending feedback bookings
        if (!pendingFeedbackBookings.isEmpty()) {
            Panel reminderPanel = new Panel(new BorderLayout());
            reminderPanel.setBackground(new Color(255, 243, 224));
            
            Panel reminderHeader = new Panel(new FlowLayout(FlowLayout.LEFT));
            reminderHeader.setBackground(new Color(255, 236, 179));
            
            Label reminderIcon = new Label("⚠");
            reminderIcon.setFont(new Font("Arial", Font.BOLD, 16));
            reminderIcon.setForeground(new Color(255, 152, 0));
            
            Label reminderTitle = new Label("Pending Feedback");
            reminderTitle.setFont(new Font("Arial", Font.BOLD, 16));
            reminderTitle.setForeground(new Color(230, 81, 0));
            
            reminderHeader.add(reminderIcon);
            reminderHeader.add(reminderTitle);
            
            Label reminderText = new Label(
                "You have " + pendingFeedbackBookings.size() + 
                " completed booking" + (pendingFeedbackBookings.size() > 1 ? "s" : "") + " that need feedback",
                Label.CENTER
            );
            reminderText.setFont(new Font("Arial", Font.PLAIN, 14));
            reminderText.setForeground(TEXT_PRIMARY);
            
            Panel bookingsPanel = new Panel();
            bookingsPanel.setLayout(new BoxLayout(bookingsPanel, BoxLayout.Y_AXIS));
            bookingsPanel.setBackground(new Color(255, 243, 224));
            
            for (Booking booking : pendingFeedbackBookings) {
                Panel bookingRow = new Panel(new BorderLayout());
                bookingRow.setBackground(new Color(255, 243, 224));
                
                String bookingInfo = booking.getEventName() + " at " + booking.getHallName() + 
                                   " on " + booking.getBookingDate();
                Label bookingLabel = new Label(bookingInfo, Label.LEFT);
                bookingLabel.setForeground(TEXT_PRIMARY);
                
                Button feedbackButton = new Button("Rate Now");
                feedbackButton.setBackground(WARNING_COLOR);
                feedbackButton.setForeground(Color.WHITE);
                feedbackButton.addActionListener(e -> showFeedbackForm(booking));
                
                bookingRow.add(bookingLabel, BorderLayout.WEST);
                bookingRow.add(feedbackButton, BorderLayout.EAST);
                bookingsPanel.add(bookingRow);
            }
            
            Panel reminderContent = new Panel(new BorderLayout(0, 10));
            reminderContent.setBackground(new Color(255, 243, 224));
            reminderContent.add(reminderText, BorderLayout.NORTH);
            reminderContent.add(bookingsPanel, BorderLayout.CENTER);
            
            reminderPanel.add(reminderHeader, BorderLayout.NORTH);
            reminderPanel.add(reminderContent, BorderLayout.CENTER);
            
            contentPanel.add(reminderPanel, BorderLayout.NORTH);
        }
        
        // Display feedback list
        Panel feedbackListContainer = new Panel(new BorderLayout());
        feedbackListContainer.setBackground(PANEL_BG);
        
        if (userFeedback.isEmpty()) {
            Panel emptyPanel = new Panel(new BorderLayout());
            emptyPanel.setBackground(PANEL_BG);
            
            Label emptyLabel = new Label("You haven't provided any feedback yet.", Label.CENTER);
            emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            emptyLabel.setForeground(TEXT_SECONDARY);
            
            emptyPanel.add(emptyLabel, BorderLayout.CENTER);
            feedbackListContainer.add(emptyPanel, BorderLayout.CENTER);
        } else {
            // Create a container for all feedback entries
            Panel feedbackListPanel = new Panel();
            feedbackListPanel.setLayout(new BoxLayout(feedbackListPanel, BoxLayout.Y_AXIS));
            feedbackListPanel.setBackground(BG_COLOR);
            
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
            
            for (Feedback feedback : userFeedback) {
                Panel feedbackCard = new Panel(new BorderLayout(0, 0));
                feedbackCard.setBackground(PANEL_BG);
                
                // Header with hall name and date
                Panel headerPanel = new Panel(new BorderLayout());
                headerPanel.setBackground(new Color(236, 240, 241));
                headerPanel.setPreferredSize(new Dimension(600, 40));
                
                Label hallLabel = new Label(feedback.getHallName(), Label.LEFT);
                hallLabel.setFont(new Font("Arial", Font.BOLD, 16));
                hallLabel.setForeground(TEXT_PRIMARY);
                
                Label dateLabel = new Label(dateFormat.format(feedback.getCreatedAt()), Label.RIGHT);
                dateLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                dateLabel.setForeground(TEXT_SECONDARY);
                
                headerPanel.add(hallLabel, BorderLayout.WEST);
                headerPanel.add(dateLabel, BorderLayout.EAST);
                
                // Content
                Panel contentDetailPanel = new Panel(new BorderLayout(15, 10));
                contentDetailPanel.setBackground(PANEL_BG);
                
                // Event name and rating
                Panel topSection = new Panel(new BorderLayout());
                topSection.setBackground(PANEL_BG);
                
                Label eventLabel = new Label("Event: " + feedback.getEventName());
                eventLabel.setFont(new Font("Arial", Font.BOLD, 14));
                eventLabel.setForeground(TEXT_PRIMARY);
                
                Panel ratingPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
                ratingPanel.setBackground(PANEL_BG);
                
                Label ratingLabel = new Label("Rating:");
                ratingLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                ratingLabel.setForeground(TEXT_PRIMARY);
                
                Label starsLabel = new Label(feedback.getStarRating());
                starsLabel.setFont(new Font("Arial", Font.BOLD, 16));
                starsLabel.setForeground(Color.ORANGE);
                
                ratingPanel.add(ratingLabel);
                ratingPanel.add(starsLabel);
                
                topSection.add(eventLabel, BorderLayout.NORTH);
                topSection.add(ratingPanel, BorderLayout.CENTER);
                
                // Comments section
                Panel commentsSection = new Panel(new BorderLayout(0, 5));
                commentsSection.setBackground(PANEL_BG);
                
                Label commentHeader = new Label("Comments:");
                commentHeader.setFont(new Font("Arial", Font.BOLD, 14));
                commentHeader.setForeground(TEXT_PRIMARY);
                
                TextArea commentText = new TextArea(feedback.getComment(), 3, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
                commentText.setEditable(false);
                commentText.setBackground(new Color(245, 245, 245));
                
                commentsSection.add(commentHeader, BorderLayout.NORTH);
                commentsSection.add(commentText, BorderLayout.CENTER);
                
                contentDetailPanel.add(topSection, BorderLayout.NORTH);
                contentDetailPanel.add(commentsSection, BorderLayout.CENTER);
                
                // Action buttons
                Panel actionPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
                actionPanel.setBackground(PANEL_BG);
                
                Button editButton = new Button("Edit Feedback");
                editButton.setBackground(SECONDARY_COLOR);
                editButton.setForeground(Color.WHITE);
                editButton.addActionListener(e -> {
                    BookingDAO bDao = new BookingDAO();
                    Booking relatedBooking = bDao.getBookingById(feedback.getBookingId());
                    if (relatedBooking != null) {
                        showFeedbackForm(relatedBooking);
                    }
                });
                
                actionPanel.add(editButton);
                contentDetailPanel.add(actionPanel, BorderLayout.SOUTH);
                
                // Assemble the card
                feedbackCard.add(headerPanel, BorderLayout.NORTH);
                feedbackCard.add(contentDetailPanel, BorderLayout.CENTER);
                
                // Add margin around the card
                Panel cardWrapper = new Panel(new BorderLayout(0, 10));
                cardWrapper.setBackground(BG_COLOR);
                cardWrapper.add(feedbackCard, BorderLayout.CENTER);
                
                // Add to the container
                feedbackListPanel.add(cardWrapper);
            }
            
            // Add to scrollable panel
            ScrollPane scrollPane = new ScrollPane();
            scrollPane.setBackground(BG_COLOR);
            scrollPane.add(feedbackListPanel);
            
            feedbackListContainer.add(scrollPane, BorderLayout.CENTER);
        }
        
        contentPanel.add(feedbackListContainer, BorderLayout.CENTER);
        
        // Add refresh button at the bottom
        Button refreshButton = new Button("Refresh Feedback");
        refreshButton.setBackground(SECONDARY_COLOR);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        refreshButton.addActionListener(e -> refreshMyFeedback());
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(BG_COLOR);
        buttonPanel.add(refreshButton);
        
        panel.add(contentPanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private Panel createBookHallPanel() {
        Panel panel = new Panel(new BorderLayout(0, 15));
        panel.setBackground(BG_COLOR);
        
        // Panel title
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(BG_COLOR);
        
        Label titleLabel = new Label("Book a Hall", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(TEXT_PRIMARY);
        
        titlePanel.add(titleLabel, BorderLayout.WEST);
        panel.add(titlePanel, BorderLayout.NORTH);
        
        // Booking form panel
        Panel formCard = new Panel(new BorderLayout());
        formCard.setBackground(PANEL_BG);
        
        // Form header
        Label formHeaderLabel = new Label("New Booking Request", Label.CENTER);
        formHeaderLabel.setFont(new Font("Arial", Font.BOLD, 18));
        formHeaderLabel.setForeground(TEXT_PRIMARY);
        
        Panel formHeaderPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        formHeaderPanel.setBackground(new Color(236, 240, 241));
        formHeaderPanel.add(formHeaderLabel);
        
        // Form fields panel using GridBagLayout for better control
        Panel formPanel = new Panel(new GridBagLayout());
        formPanel.setBackground(PANEL_BG);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Hall selection
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        Label hallLabel = new Label("Select Hall:");
        hallLabel.setFont(new Font("Arial", Font.BOLD, 14));
        hallLabel.setForeground(TEXT_PRIMARY);
        formPanel.add(hallLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        Choice hallChoice = new Choice();
        for (Hall hall : hallList) {
            hallChoice.add(hall.getHallName() + " (Capacity: " + hall.getCapacity() + ")");
        }
        formPanel.add(hallChoice, gbc);
        
        // Event name
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        Label eventLabel = new Label("Event Name:");
        eventLabel.setFont(new Font("Arial", Font.BOLD, 14));
        eventLabel.setForeground(TEXT_PRIMARY);
        formPanel.add(eventLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        TextField eventField = new TextField(30);
        formPanel.add(eventField, gbc);
        
        // Event description
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        Label descriptionLabel = new Label("Description:");
        descriptionLabel.setFont(new Font("Arial", Font.BOLD, 14));
        descriptionLabel.setForeground(TEXT_PRIMARY);
        formPanel.add(descriptionLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        TextArea descriptionArea = new TextArea("", 3, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
        descriptionArea.setBackground(new Color(245, 245, 245));
        formPanel.add(descriptionArea, gbc);
        
        // Date
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        Label dateLabel = new Label("Date (yyyy-mm-dd):");
        dateLabel.setFont(new Font("Arial", Font.BOLD, 14));
        dateLabel.setForeground(TEXT_PRIMARY);
        formPanel.add(dateLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        TextField dateField = new TextField(10);
        formPanel.add(dateField, gbc);
        
        // Time range
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        Label timeRangeLabel = new Label("Time Range:");
        timeRangeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        timeRangeLabel.setForeground(TEXT_PRIMARY);
        formPanel.add(timeRangeLabel, gbc);
        
        // Create a panel for time range
        Panel timePanel = new Panel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        timePanel.setBackground(PANEL_BG);
        
        Label startTimeLabel = new Label("From:");
        startTimeLabel.setForeground(TEXT_PRIMARY);
        TextField startTimeField = new TextField(5);
        
        Label endTimeLabel = new Label("To:");
        endTimeLabel.setForeground(TEXT_PRIMARY);
        TextField endTimeField = new TextField(5);
        
        timePanel.add(startTimeLabel);
        timePanel.add(startTimeField);
        timePanel.add(endTimeLabel);
        timePanel.add(endTimeField);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        formPanel.add(timePanel, gbc);
        
        // Format hint
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        Label formatHintLabel = new Label("Format: HH:MM (24-hour format, e.g. 14:30)");
        formatHintLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        formatHintLabel.setForeground(TEXT_SECONDARY);
        formPanel.add(formatHintLabel, gbc);
        
        // Status label (for error/success messages)
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        Label statusLabel = new Label("", Label.CENTER);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(statusLabel, gbc);
        
        // Submit button
        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        Button submitButton = new Button("Submit Booking Request");
        submitButton.setBackground(PRIMARY_COLOR);
        submitButton.setForeground(Color.WHITE);
        submitButton.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(submitButton, gbc);
        
        // Add action listener for submit button
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    statusLabel.setText("");
                    
                    // Get selected hall
                    int hallIndex = hallChoice.getSelectedIndex();
                    if (hallIndex == -1) {
                        statusLabel.setText("Please select a hall");
                        statusLabel.setForeground(ERROR_COLOR);
                        return;
                    }
                    Hall selectedHall = hallList.get(hallIndex);
                    
                    // Validate event name
                    String eventName = eventField.getText().trim();
                    if (eventName.isEmpty()) {
                        statusLabel.setText("Please enter an event name");
                        statusLabel.setForeground(ERROR_COLOR);
                        return;
                    }
                    
                    // Get event description
                    String eventDescription = descriptionArea.getText().trim();
                    
                    // Validate and parse date
                    String dateStr = dateField.getText().trim();
                    if (!dateStr.matches("\\d{4}-\\d{2}-\\d{2}")) {
                        statusLabel.setText("Please enter date in format yyyy-mm-dd");
                        statusLabel.setForeground(ERROR_COLOR);
                        return;
                    }
                    java.sql.Date bookingDate = java.sql.Date.valueOf(dateStr);
                    
                    // Validate that date is not in the past
                    java.util.Date today = new java.util.Date();
                    if (bookingDate.before(new java.sql.Date(today.getTime()))) {
                        statusLabel.setText("Booking date cannot be in the past");
                        statusLabel.setForeground(ERROR_COLOR);
                        return;
                    }
                    
                    // Validate and parse start time
                    String startTimeStr = startTimeField.getText().trim();
                    if (!startTimeStr.matches("\\d{2}:\\d{2}")) {
                        statusLabel.setText("Please enter start time in format hh:mm");
                        statusLabel.setForeground(ERROR_COLOR);
                        return;
                    }
                    java.sql.Time startTime = java.sql.Time.valueOf(startTimeStr + ":00");
                    
                    // Validate and parse end time
                    String endTimeStr = endTimeField.getText().trim();
                    if (!endTimeStr.matches("\\d{2}:\\d{2}")) {
                        statusLabel.setText("Please enter end time in format hh:mm");
                        statusLabel.setForeground(ERROR_COLOR);
                        return;
                    }
                    java.sql.Time endTime = java.sql.Time.valueOf(endTimeStr + ":00");
                    
                    // Check if end time is after start time
                    if (endTime.before(startTime) || endTime.equals(startTime)) {
                        statusLabel.setText("End time must be after start time");
                        statusLabel.setForeground(ERROR_COLOR);
                        return;
                    }
                    
                    // Check hall availability
                    HallDAO hallDao = new HallDAO();
                    if (!hallDao.isHallAvailable(selectedHall.getHallId(), bookingDate, startTime, endTime)) {
                        statusLabel.setText("Hall is not available at the selected time");
                        statusLabel.setForeground(ERROR_COLOR);
                        return;
                    }
                    
                    // Create booking
                    Booking newBooking = new Booking(
                            selectedHall.getHallId(),
                            currentUser.getUserId(),
                            eventName,
                            eventDescription,
                            bookingDate,
                            startTime,
                            endTime);
                    
                    // Save booking to database
                    BookingDAO bookingDao = new BookingDAO();
                    boolean success = bookingDao.createBooking(newBooking);
                    
                    if (success) {
                        statusLabel.setForeground(SUCCESS_COLOR);
                        statusLabel.setText("Booking request submitted successfully!");
                        
                        // Clear form fields
                        eventField.setText("");
                        descriptionArea.setText("");
                        dateField.setText("");
                        startTimeField.setText("");
                        endTimeField.setText("");
                        
                        // Refresh bookings list
                        refreshMyBookings();
                        
                        // Automatically switch to My Bookings panel after a delay
                        new Thread(() -> {
                            try {
                                Thread.sleep(1500);
                                cardLayout.show(mainPanel, MY_BOOKINGS_PANEL);
                            } catch (InterruptedException ex) {
                                ex.printStackTrace();
                            }
                        }).start();
                    } else {
                        statusLabel.setForeground(ERROR_COLOR);
                        statusLabel.setText("Failed to submit booking request. Please try again.");
                    }
                    
                } catch (Exception ex) {
                    statusLabel.setForeground(ERROR_COLOR);
                    statusLabel.setText("Error: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });
        
        // Add the form components to the card
        formCard.add(formHeaderPanel, BorderLayout.NORTH);
        formCard.add(formPanel, BorderLayout.CENTER);
        
        // Add the form card to the main panel
        panel.add(formCard, BorderLayout.CENTER);
        
        return panel;
    }
    
        private Panel createEventCalendarPanel() {
    Panel panel = new Panel(new BorderLayout(0, 15));
    panel.setBackground(BG_COLOR);
    panel.setName(EVENT_CALENDAR_PANEL);
    
    // Header section
    Panel headerPanel = new Panel(new BorderLayout(0, 10));
    headerPanel.setBackground(BG_COLOR);
    
    // Title with icon
    Panel titlePanel = new Panel(new FlowLayout(FlowLayout.LEFT));
    titlePanel.setBackground(BG_COLOR);
    
    Label calendarIconLabel = new Label("📅");
    calendarIconLabel.setFont(new Font("Arial", Font.BOLD, 24));
    calendarIconLabel.setForeground(PRIMARY_COLOR);
    
    Label titleLabel = new Label("Upcoming Events Calendar");
    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
    titleLabel.setForeground(TEXT_PRIMARY);
    
    titlePanel.add(calendarIconLabel);
    titlePanel.add(titleLabel);
    
    // Calendar controls
    Panel controlsPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
    controlsPanel.setBackground(BG_COLOR);
    
    Label viewLabel = new Label("View:");
    viewLabel.setFont(new Font("Arial", Font.BOLD, 14));
    viewLabel.setForeground(TEXT_PRIMARY);
    
    Choice viewChoice = new Choice();
    viewChoice.add("All Events");
    viewChoice.add("Today");
    viewChoice.add("This Week");
    viewChoice.add("This Month");
    
    Button refreshButton = new Button("Refresh Calendar");
    refreshButton.setBackground(SECONDARY_COLOR);
    refreshButton.setForeground(Color.WHITE);
    refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
    refreshButton.addActionListener(e -> refreshCalendar());
    
    controlsPanel.add(viewLabel);
    controlsPanel.add(viewChoice);
    controlsPanel.add(refreshButton);
    
    headerPanel.add(titlePanel, BorderLayout.WEST);
    headerPanel.add(controlsPanel, BorderLayout.EAST);
    
    panel.add(headerPanel, BorderLayout.NORTH);
    
    // Get upcoming approved bookings
    BookingDAO bookingDao = new BookingDAO();
    List<Booking> upcomingBookings = bookingDao.getUpcomingApprovedBookings();
    
    // Main calendar content
    Panel calendarContent = new Panel(new BorderLayout());
    calendarContent.setBackground(BG_COLOR);
    
    if (upcomingBookings.isEmpty()) {
        // Create an empty state panel
        Panel emptyStatePanel = new Panel(new BorderLayout(0, 20));
        emptyStatePanel.setBackground(PANEL_BG);
        
        Label emptyIconLabel = new Label("🗓️", Label.CENTER);
        emptyIconLabel.setFont(new Font("Arial", Font.PLAIN, 48));
        emptyIconLabel.setForeground(TEXT_SECONDARY);
        
        Label emptyTitleLabel = new Label("No Upcoming Events", Label.CENTER);
        emptyTitleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        emptyTitleLabel.setForeground(TEXT_PRIMARY);
        
        Label emptyDescLabel = new Label("There are no scheduled events in the calendar.", Label.CENTER);
        emptyDescLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        emptyDescLabel.setForeground(TEXT_SECONDARY);
        
        Button bookEventButton = new Button("Book a New Event");
        bookEventButton.setBackground(PRIMARY_COLOR);
        bookEventButton.setForeground(Color.WHITE);
        bookEventButton.setFont(new Font("Arial", Font.BOLD, 14));
        bookEventButton.addActionListener(e -> cardLayout.show(mainPanel, BOOK_HALL_PANEL));
        
        Panel buttonPanel = new Panel();
        buttonPanel.setBackground(PANEL_BG);
        buttonPanel.add(bookEventButton);
        
        Panel textPanel = new Panel(new GridLayout(2, 1, 0, 10));
        textPanel.setBackground(PANEL_BG);
        textPanel.add(emptyTitleLabel);
        textPanel.add(emptyDescLabel);
        
        Panel centeredPanel = new Panel(new BorderLayout(0, 20));
        centeredPanel.setBackground(PANEL_BG);
        centeredPanel.add(emptyIconLabel, BorderLayout.NORTH);
        centeredPanel.add(textPanel, BorderLayout.CENTER);
        centeredPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        emptyStatePanel.add(new Label(""), BorderLayout.NORTH); // Padding
        emptyStatePanel.add(centeredPanel, BorderLayout.CENTER);
        emptyStatePanel.add(new Label(""), BorderLayout.SOUTH); // Padding
        
        calendarContent.add(emptyStatePanel, BorderLayout.CENTER);
    } else {
        // Group events by date
        Map<Date, List<Booking>> bookingsByDate = new TreeMap<>();
        for (Booking booking : upcomingBookings) {
            Date date = booking.getBookingDate();
            if (!bookingsByDate.containsKey(date)) {
                bookingsByDate.put(date, new ArrayList<>());
            }
            bookingsByDate.get(date).add(booking);
        }
        
        // Create modern calendar view
        Panel calendarPanel = new Panel();
        calendarPanel.setLayout(new BoxLayout(calendarPanel, BoxLayout.Y_AXIS));
        calendarPanel.setBackground(BG_COLOR);
        
        // Add date sections with events
        for (Map.Entry<Date, List<Booking>> entry : bookingsByDate.entrySet()) {
            Date date = entry.getKey();
            List<Booking> dayBookings = entry.getValue();
            
            // Create date header with rounded corners and gradient
            Panel dateHeaderPanel = createModernDateHeader(date);
            calendarPanel.add(dateHeaderPanel);
            
            // Add events for this date
            for (Booking booking : dayBookings) {
                Panel eventCard = createModernEventCard(booking);
                calendarPanel.add(eventCard);
            }
            
            // Add spacing between dates
            Panel spacerPanel = new Panel();
            spacerPanel.setPreferredSize(new Dimension(800, 20));
            spacerPanel.setBackground(BG_COLOR);
            calendarPanel.add(spacerPanel);
        }
        
        // Add to scrollable panel with custom styling
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setBackground(BG_COLOR);
        scrollPane.add(calendarPanel);
        
        calendarContent.add(scrollPane, BorderLayout.CENTER);
    }
    
    panel.add(calendarContent, BorderLayout.CENTER);
    
    // Add event listener to view choice
    viewChoice.addItemListener(e -> {
        // In a real implementation, this would filter events based on selection
        // For now, we'll just refresh the calendar
        refreshCalendar();
    });
    
    return panel;
}

private Panel createModernDateHeader(Date date) {
    Panel datePanel = new Panel(new BorderLayout());
    datePanel.setBackground(PRIMARY_COLOR);
    
    // Format date in multiple ways
    SimpleDateFormat fullDateFormat = new SimpleDateFormat("EEEE, MMMM d, yyyy");
    SimpleDateFormat dayFormat = new SimpleDateFormat("d");
    SimpleDateFormat monthFormat = new SimpleDateFormat("MMM");
    SimpleDateFormat dayOfWeekFormat = new SimpleDateFormat("EEEE");
    
    String fullDate = fullDateFormat.format(date);
    String dayNumber = dayFormat.format(date);
    String month = monthFormat.format(date);
    String dayOfWeek = dayOfWeekFormat.format(date);
    
    // Create a panel with day number, month, and day of week
    Panel dateInfoPanel = new Panel(new BorderLayout(10, 0));
    dateInfoPanel.setBackground(PRIMARY_COLOR);
    
    // Day number with larger font
    Label dayLabel = new Label(dayNumber, Label.CENTER);
    dayLabel.setFont(new Font("Arial", Font.BOLD, 28));
    dayLabel.setForeground(Color.WHITE);
    
    // Month and day of week
    Panel dateTextPanel = new Panel(new GridLayout(2, 1));
    dateTextPanel.setBackground(PRIMARY_COLOR);
    
    Label monthLabel = new Label(month.toUpperCase(), Label.LEFT);
    monthLabel.setFont(new Font("Arial", Font.BOLD, 14));
    monthLabel.setForeground(Color.WHITE);
    
    Label dayOfWeekLabel = new Label(dayOfWeek, Label.LEFT);
    dayOfWeekLabel.setFont(new Font("Arial", Font.PLAIN, 14));
    dayOfWeekLabel.setForeground(new Color(220, 220, 220));
    
    dateTextPanel.add(monthLabel);
    dateTextPanel.add(dayOfWeekLabel);
    
    Panel dateCombinedPanel = new Panel(new FlowLayout(FlowLayout.LEFT, 10, 5));
    dateCombinedPanel.setBackground(PRIMARY_COLOR);
    
    // Create a "day badge" with rounded appearance
    Panel dayBadge = new Panel(new BorderLayout());
    dayBadge.setBackground(new Color(255, 255, 255, 80)); // Semi-transparent white
    dayBadge.setPreferredSize(new Dimension(40, 40));
    dayBadge.add(dayLabel, BorderLayout.CENTER);
    
    dateCombinedPanel.add(dayBadge);
    dateCombinedPanel.add(dateTextPanel);
    
    dateInfoPanel.add(dateCombinedPanel, BorderLayout.WEST);
    
    // Add full date on right side
    Label fullDateLabel = new Label(fullDate, Label.RIGHT);
    fullDateLabel.setFont(new Font("Arial", Font.BOLD, 16));
    fullDateLabel.setForeground(Color.WHITE);
    
    dateInfoPanel.add(fullDateLabel, BorderLayout.EAST);
    
    // Add padding
    Panel paddedDatePanel = new Panel(new BorderLayout());
    paddedDatePanel.setBackground(PRIMARY_COLOR);
    paddedDatePanel.add(dateInfoPanel, BorderLayout.CENTER);
    
    datePanel.add(paddedDatePanel, BorderLayout.CENTER);
    
    return datePanel;
}

private Panel createModernEventCard(Booking booking) {
    Panel eventPanel = new Panel(new BorderLayout(0, 0));
    eventPanel.setBackground(PANEL_BG);
    
    // Left time column with visual indicator
    Panel timePanel = new Panel(new BorderLayout());
    timePanel.setBackground(new Color(245, 245, 245));
    timePanel.setPreferredSize(new Dimension(120, 0));
    
    // Colored time indicator bar
    Panel timeIndicator = new Panel();
    timeIndicator.setBackground(SECONDARY_COLOR);
    timeIndicator.setPreferredSize(new Dimension(5, 0));
    timePanel.add(timeIndicator, BorderLayout.WEST);
    
    // Format time display
    SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a");
    String startTimeStr = timeFormat.format(booking.getStartTime());
    String endTimeStr = timeFormat.format(booking.getEndTime());
    
    // Time details layout
    Panel timeDetailsPanel = new Panel(new GridLayout(2, 1));
    timeDetailsPanel.setBackground(new Color(245, 245, 245));
    
    Label startTimeLabel = new Label(startTimeStr, Label.CENTER);
    startTimeLabel.setFont(new Font("Arial", Font.BOLD, 16));
    startTimeLabel.setForeground(TEXT_PRIMARY);
    
    Label endTimeLabel = new Label(endTimeStr, Label.CENTER);
    endTimeLabel.setFont(new Font("Arial", Font.ITALIC, 14));
    endTimeLabel.setForeground(TEXT_SECONDARY);
    
    timeDetailsPanel.add(startTimeLabel);
    timeDetailsPanel.add(endTimeLabel);
    
    timePanel.add(timeDetailsPanel, BorderLayout.CENTER);
    
    // Main content panel
    Panel contentPanel = new Panel(new BorderLayout(15, 0));
    contentPanel.setBackground(PANEL_BG);
    
    // Event details section
    Panel detailsPanel = new Panel(new BorderLayout(0, 5));
    detailsPanel.setBackground(PANEL_BG);
    
    // Event title with location
    Panel headerPanel = new Panel(new BorderLayout());
    headerPanel.setBackground(PANEL_BG);
    
    Label titleLabel = new Label(booking.getEventName(), Label.LEFT);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
    titleLabel.setForeground(TEXT_PRIMARY);
    
    Panel locationPanel = new Panel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
    locationPanel.setBackground(PANEL_BG);
    
    Label locationIconLabel = new Label("📍");
    locationIconLabel.setFont(new Font("Arial", Font.PLAIN, 14));
    
    Label locationLabel = new Label(booking.getHallName());
    locationLabel.setFont(new Font("Arial", Font.ITALIC, 14));
    locationLabel.setForeground(SECONDARY_COLOR);
    
    locationPanel.add(locationIconLabel);
    locationPanel.add(locationLabel);
    
    headerPanel.add(titleLabel, BorderLayout.WEST);
    headerPanel.add(locationPanel, BorderLayout.EAST);
    
    // Event description
    Panel descriptionPanel = new Panel(new BorderLayout());
    descriptionPanel.setBackground(PANEL_BG);
    
    if (booking.getEventDescription() != null && !booking.getEventDescription().isEmpty()) {
        TextArea descriptionArea = new TextArea(booking.getEventDescription(), 2, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
        descriptionArea.setEditable(false);
        descriptionArea.setBackground(new Color(250, 250, 250));
        descriptionPanel.add(descriptionArea, BorderLayout.CENTER);
    } else {
        Label noDescLabel = new Label("No description provided", Label.LEFT);
        noDescLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        noDescLabel.setForeground(TEXT_SECONDARY);
        descriptionPanel.add(noDescLabel, BorderLayout.CENTER);
    }
    
    detailsPanel.add(headerPanel, BorderLayout.NORTH);
    detailsPanel.add(descriptionPanel, BorderLayout.CENTER);
    
    // Right side - hall image (if available)
    Panel imagePanel = new Panel(new BorderLayout());
    imagePanel.setBackground(PANEL_BG);
    imagePanel.setPreferredSize(new Dimension(80, 0));
    
    try {
        HallDAO hallDAO = new HallDAO();
        Hall hall = hallDAO.getHallById(booking.getHallId());
        
        if (hall != null && hall.getImagePath() != null && !hall.getImagePath().isEmpty()) {
            Image thumbnail = ImageManager.loadHallThumbnail(hall.getImagePath(), 80, 60);
            
            if (thumbnail != null) {
                Canvas imageCanvas = new Canvas() {
                    @Override
                    public void paint(Graphics g) {
                        // Draw rounded rectangle for the image
                        g.drawImage(thumbnail, 0, 0, this);
                    }
                };
                imageCanvas.setSize(80, 60);
                
                // Add click handler to view full size
                imageCanvas.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        viewFullSizeImage(hall.getImagePath());
                    }
                });
                
                imagePanel.add(imageCanvas, BorderLayout.CENTER);
            }
        }
    } catch (Exception ex) {
        System.err.println("Error loading hall image: " + ex.getMessage());
    }
    
    contentPanel.add(detailsPanel, BorderLayout.CENTER);
    contentPanel.add(imagePanel, BorderLayout.EAST);
    
    // Add padding around content
    Panel paddedContentPanel = new Panel(new BorderLayout(0, 10));
    paddedContentPanel.setBackground(PANEL_BG);
    paddedContentPanel.add(contentPanel, BorderLayout.CENTER);
    
    // Assemble the event card
    eventPanel.add(timePanel, BorderLayout.WEST);
    eventPanel.add(paddedContentPanel, BorderLayout.CENTER);
    
    // Add hover effect with mouse listeners
    eventPanel.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {
            eventPanel.setBackground(new Color(240, 247, 255));
            paddedContentPanel.setBackground(new Color(240, 247, 255));
            contentPanel.setBackground(new Color(240, 247, 255));
            headerPanel.setBackground(new Color(240, 247, 255));
            descriptionPanel.setBackground(new Color(240, 247, 255));
            imagePanel.setBackground(new Color(240, 247, 255));
            detailsPanel.setBackground(new Color(240, 247, 255));
            locationPanel.setBackground(new Color(240, 247, 255));
        }
        
        @Override
        public void mouseExited(MouseEvent e) {
            eventPanel.setBackground(PANEL_BG);
            paddedContentPanel.setBackground(PANEL_BG);
            contentPanel.setBackground(PANEL_BG);
            headerPanel.setBackground(PANEL_BG);
            descriptionPanel.setBackground(PANEL_BG);
            imagePanel.setBackground(PANEL_BG);
            detailsPanel.setBackground(PANEL_BG);
            locationPanel.setBackground(PANEL_BG);
        }
    });
    
    // Wrap the card in a panel with margin
    Panel cardWrapper = new Panel(new BorderLayout(0, 10));
    cardWrapper.setBackground(BG_COLOR);
    cardWrapper.add(eventPanel, BorderLayout.CENTER);
    
    return cardWrapper;
}

    
    private Panel createDateHeader(Date date) {
        Panel datePanel = new Panel(new BorderLayout());
        datePanel.setBackground(PRIMARY_COLOR);
        
        // Format date like "Monday, October 23, 2023"
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d, yyyy");
        String formattedDate = dateFormat.format(date);
        
        Label dateLabel = new Label(formattedDate, Label.LEFT);
        dateLabel.setFont(new Font("Arial", Font.BOLD, 16));
        dateLabel.setForeground(Color.WHITE);
        
        // Add some padding
        Panel paddedPanel = new Panel(new BorderLayout());
        paddedPanel.setBackground(PRIMARY_COLOR);
        paddedPanel.add(dateLabel, BorderLayout.CENTER);
        
        datePanel.add(paddedPanel, BorderLayout.CENTER);
        
        return datePanel;
    }
    
    private Panel createEventCard(Booking booking) {
        Panel eventPanel = new Panel(new BorderLayout(10, 0));
        eventPanel.setBackground(PANEL_BG);
        
        // Left time panel
        Panel timePanel = new Panel(new BorderLayout());
        timePanel.setBackground(new Color(236, 240, 241));
        timePanel.setPreferredSize(new Dimension(120, 0));
        
        SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a");
        String startTimeStr = timeFormat.format(booking.getStartTime());
        String endTimeStr = timeFormat.format(booking.getEndTime());
        
        Label timeLabel = new Label(startTimeStr, Label.CENTER);
        timeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        timeLabel.setForeground(TEXT_PRIMARY);
        
        Label endTimeLabel = new Label(endTimeStr, Label.CENTER);
        endTimeLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        endTimeLabel.setForeground(TEXT_SECONDARY);
        
        Panel timeTextPanel = new Panel(new GridLayout(2, 1));
        timeTextPanel.setBackground(new Color(236, 240, 241));
        timeTextPanel.add(timeLabel);
        timeTextPanel.add(endTimeLabel);
        
        timePanel.add(timeTextPanel, BorderLayout.CENTER);
        
        // Event details panel
        Panel detailsPanel = new Panel(new BorderLayout(10, 5));
        detailsPanel.setBackground(PANEL_BG);
        
        // Event title and location
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PANEL_BG);
        
        Label titleLabel = new Label(booking.getEventName(), Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(TEXT_PRIMARY);
        
        Label locationLabel = new Label("at " + booking.getHallName(), Label.RIGHT);
        locationLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        locationLabel.setForeground(SECONDARY_COLOR);
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(locationLabel, BorderLayout.EAST);
        
        // Event description if available
        Panel descriptionPanel = new Panel(new BorderLayout());
        descriptionPanel.setBackground(PANEL_BG);
        
        if (booking.getEventDescription() != null && !booking.getEventDescription().isEmpty()) {
            TextArea descriptionArea = new TextArea(booking.getEventDescription(), 2, 30, TextArea.SCROLLBARS_VERTICAL_ONLY);
            descriptionArea.setEditable(false);
            descriptionArea.setBackground(new Color(245, 245, 245));
            descriptionPanel.add(descriptionArea, BorderLayout.CENTER);
        } else {
            Label noDescLabel = new Label("No description provided", Label.LEFT);
            noDescLabel.setFont(new Font("Arial", Font.ITALIC, 12));
            noDescLabel.setForeground(TEXT_SECONDARY);
            descriptionPanel.add(noDescLabel, BorderLayout.CENTER);
        }
        
        detailsPanel.add(headerPanel, BorderLayout.NORTH);
        detailsPanel.add(descriptionPanel, BorderLayout.CENTER);
        
        // Add hall image if available
        try {
            HallDAO hallDAO = new HallDAO();
            Hall hall = hallDAO.getHallById(booking.getHallId());
            
            if (hall != null && hall.getImagePath() != null && !hall.getImagePath().isEmpty()) {
                Image thumbnail = ImageManager.loadHallThumbnail(hall.getImagePath(), 80, 60);
                
                if (thumbnail != null) {
                    Panel imagePanel = new Panel(new BorderLayout());
                    imagePanel.setBackground(PANEL_BG);
                    imagePanel.setPreferredSize(new Dimension(80, 60));
                    
                    Canvas imageCanvas = new Canvas() {
                        @Override
                        public void paint(Graphics g) {
                            g.drawImage(thumbnail, 0, 0, this);
                        }
                    };
                    imageCanvas.setSize(80, 60);
                    
                    // Add click handler to view full size
                    imageCanvas.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent e) {
                            viewFullSizeImage(hall.getImagePath());
                        }
                    });
                    
                    imagePanel.add(imageCanvas, BorderLayout.CENTER);
                    detailsPanel.add(imagePanel, BorderLayout.EAST);
                }
            }
        } catch (Exception ex) {
            System.err.println("Error loading hall image: " + ex.getMessage());
        }
        
        // Assemble the event card
        eventPanel.add(timePanel, BorderLayout.WEST);
        eventPanel.add(detailsPanel, BorderLayout.CENTER);
        
        return eventPanel;
    }
    
    private void refreshMyBookings() {
        BookingDAO bookingDao = new BookingDAO();
        userBookings = bookingDao.getBookingsByUserId(currentUser.getUserId());
        
        // Find the index of the My Bookings panel
        int myBookingsPanelIndex = -1;
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            if (mainPanel.getComponent(i).getName() != null && 
                mainPanel.getComponent(i).getName().equals(MY_BOOKINGS_PANEL)) {
                myBookingsPanelIndex = i;
                break;
            }
        }
        
        if (myBookingsPanelIndex == -1) {
            myBookingsPanelIndex = 1; // Default index if not found
        }
        
        // Recreate the My Bookings panel
        mainPanel.remove(myBookingsPanelIndex);
        mainPanel.add(createMyBookingsPanel(), MY_BOOKINGS_PANEL, myBookingsPanelIndex);
        
        cardLayout.show(mainPanel, MY_BOOKINGS_PANEL);
    }
    
    private void refreshMyFeedback() {
        // Find the index of the My Feedback panel
        int myFeedbackPanelIndex = -1;
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            if (mainPanel.getComponent(i).getName() != null && 
                mainPanel.getComponent(i).getName().equals(MY_FEEDBACK_PANEL)) {
                myFeedbackPanelIndex = i;
                break;
            }
        }
        
        if (myFeedbackPanelIndex == -1) {
            myFeedbackPanelIndex = 4; // Default index if not found
        }
        
        // Recreate the My Feedback panel
        mainPanel.remove(myFeedbackPanelIndex);
        mainPanel.add(createMyFeedbackPanel(), MY_FEEDBACK_PANEL, myFeedbackPanelIndex);
        
        cardLayout.show(mainPanel, MY_FEEDBACK_PANEL);
    }
    
    private void refreshCalendar() {
        // Find the index of the Event Calendar panel
        int calendarPanelIndex = -1;
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            if (mainPanel.getComponent(i).getName() != null && 
                mainPanel.getComponent(i).getName().equals(EVENT_CALENDAR_PANEL)) {
                calendarPanelIndex = i;
                break;
            }
        }
        
        if (calendarPanelIndex == -1) {
            calendarPanelIndex = 3; // Default index if not found
        }
        
        // Recreate the Event Calendar panel
        mainPanel.remove(calendarPanelIndex);
        mainPanel.add(createEventCalendarPanel(), EVENT_CALENDAR_PANEL, calendarPanelIndex);
        
        cardLayout.show(mainPanel, EVENT_CALENDAR_PANEL);
    }
    
    private void cancelBooking(int bookingId) {
        Dialog confirmDialog = new Dialog(this, "Confirm Cancellation", true);
        confirmDialog.setSize(400, 180);
        confirmDialog.setLocationRelativeTo(this);
        confirmDialog.setLayout(new BorderLayout(15, 15));
        confirmDialog.setBackground(PANEL_BG);
        
        Label messageLabel = new Label("Are you sure you want to cancel this booking?", Label.CENTER);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        messageLabel.setForeground(TEXT_PRIMARY);
        
        Label noteLabel = new Label("This action cannot be undone.", Label.CENTER);
        noteLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        noteLabel.setForeground(TEXT_SECONDARY);
        
        Panel messagePanel = new Panel(new GridLayout(2, 1, 0, 10));
        messagePanel.setBackground(PANEL_BG);
        messagePanel.add(messageLabel);
        messagePanel.add(noteLabel);
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setBackground(PANEL_BG);
        
        Button yesButton = new Button("Yes, Cancel Booking");
        yesButton.setBackground(ERROR_COLOR);
        yesButton.setForeground(Color.WHITE);
        yesButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        Button noButton = new Button("No, Keep Booking");
        noButton.setBackground(SECONDARY_COLOR);
        noButton.setForeground(Color.WHITE);
        noButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        buttonPanel.add(yesButton);
        buttonPanel.add(noButton);
        
        confirmDialog.add(messagePanel, BorderLayout.CENTER);
        confirmDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        yesButton.addActionListener(e -> {
            confirmDialog.dispose();
            
            BookingDAO bookingDao = new BookingDAO();
            boolean success = bookingDao.cancelBooking(bookingId, currentUser.getUserId());
            
            if (success) {
                showInfoDialog("Your booking has been successfully cancelled.", "Success");
                refreshMyBookings();
            } else {
                showInfoDialog("Failed to cancel booking. Please try again or contact support.", "Error");
            }
        });
        
        noButton.addActionListener(e -> confirmDialog.dispose());
        
        confirmDialog.setVisible(true);
    }
    
    private void showFeedbackForm(Booking booking) {
        FeedbackDAO feedbackDAO = new FeedbackDAO();
        boolean hasFeedback = feedbackDAO.hasBookingFeedback(booking.getBookingId());
        
        String dialogTitle = hasFeedback ? "Update Feedback" : "Provide Feedback";
        Dialog confirmDialog = new Dialog(this, dialogTitle, true);
        confirmDialog.setLayout(new BorderLayout(10, 10));
        confirmDialog.setSize(400, 180);
        confirmDialog.setLocationRelativeTo(this);
        confirmDialog.setBackground(PANEL_BG);
        
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(400, 50));
        
        Label headerLabel = new Label(dialogTitle, Label.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        
        Panel contentPanel = new Panel(new BorderLayout(0, 15));
        contentPanel.setBackground(PANEL_BG);
        
        Label confirmLabel = new Label(
            hasFeedback ? 
            "You have already provided feedback for this booking. Would you like to update it?" :
            "Would you like to provide feedback for this booking?", 
            Label.CENTER
        );
        confirmLabel.setFont(new Font("Arial", Font.BOLD, 14));
        confirmLabel.setForeground(TEXT_PRIMARY);
        
        Label eventLabel = new Label(
            "Event: " + booking.getEventName() + " at " + booking.getHallName(),
            Label.CENTER
        );
        eventLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        eventLabel.setForeground(TEXT_SECONDARY);
        
        Panel textPanel = new Panel(new GridLayout(2, 1, 0, 10));
        textPanel.setBackground(PANEL_BG);
        textPanel.add(confirmLabel);
        textPanel.add(eventLabel);
        
        contentPanel.add(textPanel, BorderLayout.CENTER);
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(PANEL_BG);
        
        Button yesButton = new Button(hasFeedback ? "Update Feedback" : "Provide Feedback");
        yesButton.setBackground(PRIMARY_COLOR);
        yesButton.setForeground(Color.WHITE);
        yesButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        Button noButton = new Button("Cancel");
        noButton.setBackground(TEXT_SECONDARY);
        noButton.setForeground(Color.WHITE);
        noButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        yesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirmDialog.dispose();
                // Open the feedback form
                FeedbackForm feedbackForm = new FeedbackForm(UserDashboard.this, booking, currentUser, UserDashboard.this::refreshMyFeedback);
                feedbackForm.setVisible(true);
            }
        });
        
        noButton.addActionListener(e -> confirmDialog.dispose());
        
        buttonPanel.add(yesButton);
        buttonPanel.add(noButton);
        
        confirmDialog.add(headerPanel, BorderLayout.NORTH);
        confirmDialog.add(contentPanel, BorderLayout.CENTER);
        confirmDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        confirmDialog.setVisible(true);
    }
    
    private void viewFullSizeImage(String imagePath) {
        if (imagePath == null || imagePath.isEmpty()) {
            return;
        }
        
        try {
            Image fullImage = ImageManager.loadHallImage(imagePath);
            if (fullImage == null) {
                return;
            }
            
            Dialog imageDialog = new Dialog(this, "Hall Image", true);
            imageDialog.setSize(800, 600);
            imageDialog.setLocationRelativeTo(this);
            imageDialog.setLayout(new BorderLayout());
            imageDialog.setBackground(new Color(40, 40, 40));
            
            // Create an image canvas that scales the image to fit
            Canvas imageCanvas = new Canvas() {
                @Override
                public void paint(Graphics g) {
                    // Fill background
                    g.setColor(new Color(40, 40, 40));
                    g.fillRect(0, 0, getWidth(), getHeight());
                    
                    // Calculate scaling to fit the canvas
                    int imgWidth = fullImage.getWidth(this);
                    int imgHeight = fullImage.getHeight(this);
                    int canvasWidth = getWidth();
                    int canvasHeight = getHeight();
                    
                    double scale = Math.min(
                        (double) canvasWidth / imgWidth,
                        (double) canvasHeight / imgHeight
                    );
                    
                    int scaledWidth = (int) (imgWidth * scale);
                    int scaledHeight = (int) (imgHeight * scale);
                    
                    // Center the image
                    int x = (canvasWidth - scaledWidth) / 2;
                    int y = (canvasHeight - scaledHeight) / 2;
                    
                    g.drawImage(fullImage, x, y, scaledWidth, scaledHeight, this);
                }
            };
            
            // Add a close button at the bottom
            Button closeButton = new Button("Close");
            closeButton.setBackground(SECONDARY_COLOR);
            closeButton.setForeground(Color.WHITE);
            closeButton.setFont(new Font("Arial", Font.BOLD, 14));
            closeButton.addActionListener(e -> imageDialog.dispose());
            
            Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.setBackground(new Color(40, 40, 40));
            buttonPanel.add(closeButton);
            
            imageDialog.add(imageCanvas, BorderLayout.CENTER);
            imageDialog.add(buttonPanel, BorderLayout.SOUTH);
            
            imageDialog.setVisible(true);
        } catch (IOException e) {
            showInfoDialog("Error loading image: " + e.getMessage(), "Image Error");
        }
    }
    
    // Helper method to show styled dialog messages
    private void showInfoDialog(String message, String title) {
        Dialog dialog = new Dialog(this, title, true);
        dialog.setSize(400, 180);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(15, 15));
        dialog.setBackground(PANEL_BG);
        
        // Header
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(400, 50));
        
        Label headerLabel = new Label(title, Label.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        
        // Message
        Label messageLabel = new Label(message, Label.CENTER);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        messageLabel.setForeground(TEXT_PRIMARY);
        
        // Button
        Button okButton = new Button("OK");
        okButton.setBackground(SECONDARY_COLOR);
        okButton.setForeground(Color.WHITE);
        okButton.setFont(new Font("Arial", Font.BOLD, 14));
        okButton.addActionListener(e -> dialog.dispose());
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(PANEL_BG);
        buttonPanel.add(okButton);
        
        dialog.add(headerPanel, BorderLayout.NORTH);
        dialog.add(messageLabel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.setVisible(true);
    }
    
    private void logout() {
        Dialog confirmDialog = new Dialog(this, "Confirm Logout", true);
        confirmDialog.setSize(350, 150);
        confirmDialog.setLocationRelativeTo(this);
        confirmDialog.setLayout(new BorderLayout(15, 15));
        confirmDialog.setBackground(PANEL_BG);
        
        Label confirmLabel = new Label("Are you sure you want to logout?", Label.CENTER);
        confirmLabel.setFont(new Font("Arial", Font.BOLD, 16));
        confirmLabel.setForeground(TEXT_PRIMARY);
        
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setBackground(PANEL_BG);
        
        Button yesButton = new Button("Yes, Logout");
        yesButton.setBackground(ERROR_COLOR);
        yesButton.setForeground(Color.WHITE);
        yesButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        Button noButton = new Button("No, Stay Logged In");
        noButton.setBackground(SECONDARY_COLOR);
        noButton.setForeground(Color.WHITE);
        noButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        yesButton.addActionListener(e -> {
            confirmDialog.dispose();
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            dispose();
        });
        
        noButton.addActionListener(e -> confirmDialog.dispose());
        
        buttonPanel.add(yesButton);
        buttonPanel.add(noButton);
        
        confirmDialog.add(confirmLabel, BorderLayout.CENTER);
        confirmDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        confirmDialog.setVisible(true);
    }
}
