package seminarhallbookingsystem.ui;

import seminarhallbookingsystem.dao.UserDAO;
import seminarhallbookingsystem.models.User;

import java.awt.*;
import java.awt.event.*;

/**
 * Enhanced Registration Frame with improved UI
 * @author bhavi
 */
public class RegistrationFrame extends Frame {
    private TextField usernameField;
    private TextField passwordField;
    private TextField confirmPasswordField;
    private TextField emailField;
    private TextField fullNameField;
    private Button registerButton;
    private Button backButton;
    private Label statusLabel;
    
    // Colors - matching the LoginFrame theme
    private final Color PRIMARY_COLOR = new Color(70, 130, 180);  // Steel blue
    private final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Light gray
    private final Color TEXT_COLOR = new Color(25, 25, 25);       // Near black
    private final Color ERROR_COLOR = new Color(178, 34, 34);     // Firebrick red
    private final Color SUCCESS_COLOR = new Color(46, 139, 87);   // Sea green
    
    public RegistrationFrame() {
        // Frame setup
        setTitle("Seminar Hall Booking System - Registration");
        setSize(500, 450);
        setLayout(null); // Using absolute positioning
        setLocationRelativeTo(null); // Center on screen
        setResizable(false);
        setBackground(BACKGROUND_COLOR);
        
        // Add components
        Font titleFont = new Font("Arial", Font.BOLD, 20);
        Font labelFont = new Font("Arial", Font.BOLD, 14);
        Font inputFont = new Font("Arial", Font.PLAIN, 14);
        
        // Title
        Label titleLabel = new Label("User Registration", Label.CENTER);
        titleLabel.setBounds(50, 40, 400, 30);
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(PRIMARY_COLOR);
        add(titleLabel);
        
        // Add separator line
        Canvas separator = new Canvas();
        separator.setBounds(50, 80, 400, 1);
        separator.setBackground(Color.LIGHT_GRAY);
        add(separator);
        
        // Username
        Label usernameLabel = new Label("Username:");
        usernameLabel.setBounds(100, 100, 120, 25);
        usernameLabel.setFont(labelFont);
        usernameLabel.setForeground(TEXT_COLOR);
        add(usernameLabel);
        
        usernameField = new TextField();
        usernameField.setBounds(230, 100, 200, 30);
        usernameField.setFont(inputFont);
        add(usernameField);
        
        // Password
        Label passwordLabel = new Label("Password:");
        passwordLabel.setBounds(100, 140, 120, 25);
        passwordLabel.setFont(labelFont);
        passwordLabel.setForeground(TEXT_COLOR);
        add(passwordLabel);
        
        passwordField = new TextField();
        passwordField.setEchoChar('*');
        passwordField.setBounds(230, 140, 200, 30);
        passwordField.setFont(inputFont);
        add(passwordField);
        
        // Confirm Password
        Label confirmPasswordLabel = new Label("Confirm Password:");
        confirmPasswordLabel.setBounds(100, 180, 130, 25);
        confirmPasswordLabel.setFont(labelFont);
        confirmPasswordLabel.setForeground(TEXT_COLOR);
        add(confirmPasswordLabel);
        
        confirmPasswordField = new TextField();
        confirmPasswordField.setEchoChar('*');
        confirmPasswordField.setBounds(230, 180, 200, 30);
        confirmPasswordField.setFont(inputFont);
        add(confirmPasswordField);
        
        // Email
        Label emailLabel = new Label("Email:");
        emailLabel.setBounds(100, 220, 120, 25);
        emailLabel.setFont(labelFont);
        emailLabel.setForeground(TEXT_COLOR);
        add(emailLabel);
        
        emailField = new TextField();
        emailField.setBounds(230, 220, 200, 30);
        emailField.setFont(inputFont);
        add(emailField);
        
        // Full Name
        Label fullNameLabel = new Label("Full Name:");
        fullNameLabel.setBounds(100, 260, 120, 25);
        fullNameLabel.setFont(labelFont);
        fullNameLabel.setForeground(TEXT_COLOR);
        add(fullNameLabel);
        
        fullNameField = new TextField();
        fullNameField.setBounds(230, 260, 200, 30);
        fullNameField.setFont(inputFont);
        add(fullNameField);
        
        // Status label (moved above buttons for better visibility)
        statusLabel = new Label("", Label.CENTER);
        statusLabel.setBounds(75, 305, 350, 25);
        statusLabel.setForeground(ERROR_COLOR);
        add(statusLabel);
        
        // Buttons with improved styling
        registerButton = new Button("Register");
        registerButton.setBounds(150, 350, 120, 35);
        registerButton.setBackground(PRIMARY_COLOR);
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(labelFont);
        add(registerButton);
        
        backButton = new Button("Back to Login");
        backButton.setBounds(280, 350, 120, 35);
        backButton.setBackground(Color.WHITE);
        backButton.setForeground(PRIMARY_COLOR);
        backButton.setFont(labelFont);
        add(backButton);
        
        // Event listeners
        registerButton.addActionListener(e -> registerUser());
        
        backButton.addActionListener(e -> goBackToLogin());
        
        // Handle window close
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                dispose();
            }
        });
        
        // Add keyboard listener for Enter key
        KeyAdapter enterKeyListener = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    registerUser();
                }
            }
        };
        
        // Add the listener to all text fields
        usernameField.addKeyListener(enterKeyListener);
        passwordField.addKeyListener(enterKeyListener);
        confirmPasswordField.addKeyListener(enterKeyListener);
        emailField.addKeyListener(enterKeyListener);
        fullNameField.addKeyListener(enterKeyListener);
    }
    
    private void registerUser() {
        // Get input values
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String confirmPassword = confirmPasswordField.getText().trim();
        String email = emailField.getText().trim();
        String fullName = fullNameField.getText().trim();
        
        // Validate input
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || 
            email.isEmpty() || fullName.isEmpty()) {
            statusLabel.setText("All fields are required");
            statusLabel.setForeground(ERROR_COLOR);
            return;
        }
        
        if (username.length() < 4) {
            statusLabel.setText("Username must be at least 4 characters");
            statusLabel.setForeground(ERROR_COLOR);
            return;
        }
        
        if (password.length() < 6) {
            statusLabel.setText("Password must be at least 6 characters");
            statusLabel.setForeground(ERROR_COLOR);
            return;
        }
        
        if (!password.equals(confirmPassword)) {
            statusLabel.setText("Passwords do not match");
            statusLabel.setForeground(ERROR_COLOR);
            return;
        }
        
        if (!email.contains("@") || !email.contains(".")) {
            statusLabel.setText("Please enter a valid email address");
            statusLabel.setForeground(ERROR_COLOR);
            return;
        }
        
        // Check if username or email already exists
        UserDAO userDao = new UserDAO();
        if (userDao.usernameExists(username)) {
            statusLabel.setText("Username already exists");
            statusLabel.setForeground(ERROR_COLOR);
            return;
        }
        
        if (userDao.emailExists(email)) {
            statusLabel.setText("Email already exists");
            statusLabel.setForeground(ERROR_COLOR);
            return;
        }
        
        // Create and register the user
        User newUser = new User(username, password, email, fullName, false);
        boolean success = userDao.registerUser(newUser);
        
        if (success) {
            statusLabel.setForeground(SUCCESS_COLOR);
            statusLabel.setText("Registration successful! Redirecting to login...");
            
            // Disable the buttons to prevent multiple submissions
            registerButton.setEnabled(false);
            backButton.setEnabled(false);
            
            // Delay before redirecting to login
            new Thread(() -> {
                try {
                    Thread.sleep(1500);
                    goBackToLogin();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        } else {
            statusLabel.setText("Registration failed. Please try again.");
            statusLabel.setForeground(ERROR_COLOR);
        }
    }
    
    private void goBackToLogin() {
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
        dispose();
    }
}
