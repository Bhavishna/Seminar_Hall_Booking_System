package seminarhallbookingsystem.ui;

import seminarhallbookingsystem.dao.BookingDAO;
import seminarhallbookingsystem.dao.HallDAO;
import seminarhallbookingsystem.dao.UserDAO;
import seminarhallbookingsystem.models.Booking;
import seminarhallbookingsystem.models.Hall;
import seminarhallbookingsystem.models.User;
import seminarhallbookingsystem.util.ImageManager;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.BoxLayout;

public class AdminDashboard extends Frame {
    // Colors
    private final Color PRIMARY_COLOR = new Color(59, 89, 152); // Dark blue
    private final Color SECONDARY_COLOR = new Color(223, 227, 238); // Light blue-grey
    private final Color ACCENT_COLOR = new Color(66, 103, 178); // Bright blue
    private final Color HEADER_COLOR = new Color(240, 242, 245); // Very light grey
    private final Color SIDEBAR_COLOR = new Color(45, 70, 130); // Darker blue
    private final Color TEXT_COLOR = new Color(28, 30, 33); // Dark grey
    private final Color TEXT_SECONDARY = new Color(96, 103, 112); // Grey
    private final Color SUCCESS_COLOR = new Color(42, 187, 155); // Green
    private final Color WARNING_COLOR = new Color(255, 193, 7); // Amber
    private final Color DANGER_COLOR = new Color(220, 53, 69); // Red
    private final Color PANEL_BG = new Color(255, 255, 255); // White

    private User adminUser;
    private List<Hall> hallList;
    private List<Booking> pendingBookings;
    private List<Booking> allBookings;
    private List<User> userList;
    private Panel mainPanel;
    private CardLayout cardLayout;

    // Constants for card names
    private static final String MANAGE_HALLS_PANEL = "MANAGE_HALLS";
    private static final String PENDING_BOOKINGS_PANEL = "PENDING_BOOKINGS";
    private static final String ALL_BOOKINGS_PANEL = "ALL_BOOKINGS";
    private static final String MANAGE_USERS_PANEL = "MANAGE_USERS";
    private static final String EVENT_CALENDAR_PANEL = "EVENT_CALENDAR";
    private static final String FEEDBACK_PANEL = "FEEDBACK_PANEL";
    private static final String ANALYTICS_PANEL = "ANALYTICS_PANEL";
    
    // Section states
    private boolean bookingsExpanded = true;
    private boolean managementExpanded = true;
    private boolean reportsExpanded = true;

    public AdminDashboard(User admin) {
        this.adminUser = admin;

        // Verify this is an admin user
        if (!admin.isAdmin()) {
            throw new IllegalArgumentException("Only admin users can access this dashboard");
        }

        // Load data from database
        loadData();

        // Setup frame
        setTitle("Seminar Hall Booking System - Admin Dashboard");
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(0, 0));
        setBackground(HEADER_COLOR);

        // Create header panel
        Panel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);

        // Create sidebar panel
        Panel sidebarPanel = createModernSidebarPanel();
        add(sidebarPanel, BorderLayout.WEST);

        // Create main panel with card layout
        cardLayout = new CardLayout();
        mainPanel = new Panel(cardLayout);
        mainPanel.setBackground(HEADER_COLOR);

        // Add cards to main panel
        mainPanel.add(createManageHallsPanel(), MANAGE_HALLS_PANEL);
        mainPanel.add(createPendingBookingsPanel(), PENDING_BOOKINGS_PANEL);
        mainPanel.add(createAllBookingsPanel(), ALL_BOOKINGS_PANEL);
        mainPanel.add(createManageUsersPanel(), MANAGE_USERS_PANEL);
        mainPanel.add(createEventCalendarPanel(), EVENT_CALENDAR_PANEL);
        mainPanel.add(createFeedbackPanel(), FEEDBACK_PANEL);
        mainPanel.add(new AnalyticsPanel(this), ANALYTICS_PANEL);

        add(mainPanel, BorderLayout.CENTER);

        // Show the first card
        cardLayout.show(mainPanel, PENDING_BOOKINGS_PANEL);

        // Handle window close
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                logout();
            }
        });
    }

    private void loadData() {
        HallDAO hallDao = new HallDAO();
        hallList = hallDao.getAllHalls();

        BookingDAO bookingDao = new BookingDAO();
        pendingBookings = bookingDao.getPendingBookings();
        allBookings = bookingDao.getAllBookings();

        UserDAO userDao = new UserDAO();
        userList = userDao.getAllUsers();
    }

    private Panel createHeaderPanel() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(PRIMARY_COLOR);
        panel.setPreferredSize(new Dimension(1100, 60));
        
        // Title with logo
        Panel titlePanel = new Panel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        titlePanel.setBackground(PRIMARY_COLOR);
        
        Label titleLabel = new Label("Seminar Hall Booking System - Admin Panel");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        
        titlePanel.add(titleLabel);
        
        // User info and logout
        Panel userPanel = new Panel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        userPanel.setBackground(PRIMARY_COLOR);
        
        Label userLabel = new Label("Admin: " + adminUser.getFullName());
        userLabel.setFont(new Font("Arial", Font.BOLD, 14));
        userLabel.setForeground(Color.WHITE);
        
        Button logoutButton = new Button("Logout");
        logoutButton.setBackground(DANGER_COLOR);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.addActionListener(e -> logout());
        
        userPanel.add(userLabel);
        userPanel.add(logoutButton);
        
        panel.add(titlePanel, BorderLayout.WEST);
        panel.add(userPanel, BorderLayout.EAST);
        
        return panel;
    }

    private Panel createModernSidebarPanel() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(SIDEBAR_COLOR);
        panel.setPreferredSize(new Dimension(240, 700));
        
        // Create a panel for the system title
        Panel titlePanel = new Panel(new GridLayout(2, 1));
        titlePanel.setBackground(new Color(37, 57, 104)); // Slightly darker than sidebar
        titlePanel.setPreferredSize(new Dimension(240, 80));
        
        // Add system title
        Label systemLabel = new Label("Seminar Hall", Label.CENTER);
        systemLabel.setFont(new Font("Arial", Font.BOLD, 18));
        systemLabel.setForeground(Color.WHITE);
        
        Label bookingLabel = new Label("Booking System", Label.CENTER);
        bookingLabel.setFont(new Font("Arial", Font.BOLD, 16));
        bookingLabel.setForeground(Color.WHITE);
        
        titlePanel.add(systemLabel);
        titlePanel.add(bookingLabel);
        
        // Create menu panel
        Panel menuPanel = new Panel();
        menuPanel.setLayout(new GridLayout(10, 1, 0, 0));
        menuPanel.setBackground(SIDEBAR_COLOR);
        
        // BOOKINGS SECTION HEADER
        Panel bookingsHeader = new Panel();
        bookingsHeader.setBackground(new Color(35, 55, 100));
        bookingsHeader.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 10));
        
        Label bookingsLabel = new Label("BOOKINGS");
        bookingsLabel.setFont(new Font("Arial", Font.BOLD, 12));
        bookingsLabel.setForeground(Color.WHITE);
        
        bookingsHeader.add(bookingsLabel);
        menuPanel.add(bookingsHeader);
        
        // BOOKINGS MENU ITEMS
        Button pendingButton = new Button("Pending Bookings (" + pendingBookings.size() + ")");
        styleMenuButton(pendingButton, true);
        pendingButton.addActionListener(e -> {
            refreshPendingBookings();
            cardLayout.show(mainPanel, PENDING_BOOKINGS_PANEL);
            
            // Update button style
            resetMenuButtonsStyle(menuPanel);
            styleMenuButton(pendingButton, true);
        });
        menuPanel.add(pendingButton);
        
        Button allBookingsButton = new Button("All Bookings");
        styleMenuButton(allBookingsButton, false);
        allBookingsButton.addActionListener(e -> {
            refreshAllBookings();
            cardLayout.show(mainPanel, ALL_BOOKINGS_PANEL);
            
            // Update button style
            resetMenuButtonsStyle(menuPanel);
            styleMenuButton(allBookingsButton, true);
        });
        menuPanel.add(allBookingsButton);
        
        Button calendarButton = new Button("Event Calendar");
        styleMenuButton(calendarButton, false);
        calendarButton.addActionListener(e -> {
            refreshCalendar();
            cardLayout.show(mainPanel, EVENT_CALENDAR_PANEL);
            
            // Update button style
            resetMenuButtonsStyle(menuPanel);
            styleMenuButton(calendarButton, true);
        });
        menuPanel.add(calendarButton);
        
        // MANAGEMENT SECTION HEADER
        Panel managementHeader = new Panel();
        managementHeader.setBackground(new Color(35, 55, 100));
        managementHeader.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 10));
        
        Label managementLabel = new Label("MANAGEMENT");
        managementLabel.setFont(new Font("Arial", Font.BOLD, 12));
        managementLabel.setForeground(Color.WHITE);
        
        managementHeader.add(managementLabel);
        menuPanel.add(managementHeader);
        
        // MANAGEMENT MENU ITEMS
        Button hallsButton = new Button("Manage Halls");
        styleMenuButton(hallsButton, false);
        hallsButton.addActionListener(e -> {
            refreshHalls();
            cardLayout.show(mainPanel, MANAGE_HALLS_PANEL);
            
            // Update button style
            resetMenuButtonsStyle(menuPanel);
            styleMenuButton(hallsButton, true);
        });
        menuPanel.add(hallsButton);
        
        Button usersButton = new Button("Manage Users");
        styleMenuButton(usersButton, false);
        usersButton.addActionListener(e -> {
            refreshUsers();
            cardLayout.show(mainPanel, MANAGE_USERS_PANEL);
            
            // Update button style
            resetMenuButtonsStyle(menuPanel);
            styleMenuButton(usersButton, true);
        });
        menuPanel.add(usersButton);
        
        // REPORTS SECTION HEADER
        Panel reportsHeader = new Panel();
        reportsHeader.setBackground(new Color(35, 55, 100));
        reportsHeader.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 10));
        
        Label reportsLabel = new Label("REPORTS & ANALYTICS");
        reportsLabel.setFont(new Font("Arial", Font.BOLD, 12));
        reportsLabel.setForeground(Color.WHITE);
        
        reportsHeader.add(reportsLabel);
        menuPanel.add(reportsHeader);
        
        // REPORTS MENU ITEMS
        Button feedbackButton = new Button("View Feedback");
        styleMenuButton(feedbackButton, false);
        feedbackButton.addActionListener(e -> {
            refreshFeedback();
            cardLayout.show(mainPanel, FEEDBACK_PANEL);
            
            // Update button style
            resetMenuButtonsStyle(menuPanel);
            styleMenuButton(feedbackButton, true);
        });
        menuPanel.add(feedbackButton);
        
        Button analyticsButton = new Button("Analytics & Reports");
        styleMenuButton(analyticsButton, false);
        analyticsButton.addActionListener(e -> {
            cardLayout.show(mainPanel, ANALYTICS_PANEL);
            
            // Update button style
            resetMenuButtonsStyle(menuPanel);
            styleMenuButton(analyticsButton, true);
        });
        menuPanel.add(analyticsButton);
        
        // Add scrollable container for menu
        Panel scrollContainer = new Panel(new BorderLayout());
        scrollContainer.add(menuPanel, BorderLayout.NORTH);
        
        // Create logout button at bottom
        Panel logoutPanel = new Panel(new BorderLayout());
        logoutPanel.setBackground(DANGER_COLOR);
        logoutPanel.setPreferredSize(new Dimension(240, 50));
        
        Button logoutButton = new Button("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 16));
        logoutButton.setBackground(DANGER_COLOR);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.addActionListener(e -> logout());
        
        Panel buttonWrapper = new Panel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        buttonWrapper.setBackground(DANGER_COLOR);
        buttonWrapper.add(logoutButton);
        
        logoutPanel.add(buttonWrapper, BorderLayout.CENTER);
        
        // Add all components to sidebar
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(scrollContainer, BorderLayout.CENTER);
        panel.add(logoutPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void styleMenuButton(Button button, boolean isActive) {
        if (isActive) {
            button.setBackground(ACCENT_COLOR);
        } else {
            button.setBackground(SIDEBAR_COLOR);
        }
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.PLAIN, 14));
    }
    
    private void resetMenuButtonsStyle(Panel menuPanel) {
        for (Component comp : menuPanel.getComponents()) {
            if (comp instanceof Button) {
                styleMenuButton((Button) comp, false);
            }
        }
    }

    private Panel createManageHallsPanel() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(HEADER_COLOR);
        panel.setName(MANAGE_HALLS_PANEL);
        
        // Panel title
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(PANEL_BG);
        
        Label titleLabel = new Label("Manage Seminar Halls", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(TEXT_COLOR);
        titleLabel.setBackground(PANEL_BG);
        
        Panel titleWrapper = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        titleWrapper.setBackground(PANEL_BG);
        titleWrapper.add(titleLabel);
        
        titlePanel.add(titleWrapper, BorderLayout.CENTER);
        
        // Table header
        Panel headerPanel = new Panel(new GridLayout(1, 6));
        headerPanel.setBackground(PRIMARY_COLOR);
        
        String[] headers = {"Image", "Hall Name", "Capacity", "Description", "Facilities", "Actions"};
        for (String header : headers) {
            Label headerLabel = new Label(header, Label.CENTER);
            headerLabel.setForeground(Color.WHITE);
            headerLabel.setFont(new Font("Arial", Font.BOLD, 14));
            headerPanel.add(headerLabel);
        }
        
        // Hall rows container
        Panel hallsContainer = new Panel();
        hallsContainer.setLayout(new BoxLayout(hallsContainer, BoxLayout.Y_AXIS));
        hallsContainer.setBackground(HEADER_COLOR);
        
        // Add rows for halls
        for (Hall hall : hallList) {
            Panel hallRow = createHallRow(hall);
            hallsContainer.add(hallRow);
            
            // Add separator
            Panel separator = new Panel();
            separator.setPreferredSize(new Dimension(1, 1));
            separator.setBackground(new Color(220, 220, 220));
            hallsContainer.add(separator);
        }
        
        // Add scrollability
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.add(hallsContainer);
        
        // Content panel
        Panel contentPanel = new Panel(new BorderLayout());
        contentPanel.add(headerPanel, BorderLayout.NORTH);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Add form to create a new hall
        Panel formPanel = createAddHallForm();
        
        // Add all to main panel
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);
        panel.add(formPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private Panel createHallRow(Hall hall) {
        Panel rowPanel = new Panel(new GridLayout(1, 6));
        rowPanel.setBackground(PANEL_BG);
        
        // Image cell
        Panel imageCell = new Panel(new BorderLayout());
        imageCell.setBackground(PANEL_BG);
        
        if (hall.getImagePath() != null && !hall.getImagePath().isEmpty()) {
            try {
                Image thumbnail = ImageManager.loadHallThumbnail(hall.getImagePath(), 60, 45);
                if (thumbnail != null) {
                    Canvas imageCanvas = new Canvas() {
                        @Override
                        public void paint(Graphics g) {
                            g.drawImage(thumbnail, 0, 0, this);
                        }
                    };
                    imageCanvas.setSize(60, 45);
                    
                    // Add click handler
                    imageCanvas.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent e) {
                            viewFullSizeImage(hall.getImagePath());
                        }
                    });
                    
                    Panel imageCentering = new Panel(new FlowLayout(FlowLayout.CENTER));
                    imageCentering.setBackground(PANEL_BG);
                    imageCentering.add(imageCanvas);
                    imageCell.add(imageCentering, BorderLayout.CENTER);
                } else {
                    Label noImage = new Label("No image", Label.CENTER);
                    imageCell.add(noImage, BorderLayout.CENTER);
                }
            } catch (IOException e) {
                Label errorLabel = new Label("Error", Label.CENTER);
                imageCell.add(errorLabel, BorderLayout.CENTER);
            }
        } else {
            Label noImage = new Label("No image", Label.CENTER);
            imageCell.add(noImage, BorderLayout.CENTER);
        }
        
        // Name cell
        Label nameLabel = new Label(hall.getHallName(), Label.CENTER);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Capacity cell
        Label capacityLabel = new Label(String.valueOf(hall.getCapacity()), Label.CENTER);
        
        // Description cell (truncated)
        String desc = hall.getDescription();
        if (desc.length() > 30) {
            desc = desc.substring(0, 27) + "...";
        }
        Label descLabel = new Label(desc, Label.CENTER);
        
        // Facilities cell (truncated)
        String facilities = hall.getFacilities();
        if (facilities.length() > 30) {
            facilities = facilities.substring(0, 27) + "...";
        }
        Label facilitiesLabel = new Label(facilities, Label.CENTER);
        
        // Actions cell
        Panel actionsCell = new Panel(new FlowLayout(FlowLayout.CENTER));
        actionsCell.setBackground(PANEL_BG);
        
        Button uploadBtn = new Button("Upload");
        uploadBtn.setBackground(ACCENT_COLOR);
        uploadBtn.setForeground(Color.WHITE);
        
        Button deleteBtn = new Button("Delete");
        deleteBtn.setBackground(DANGER_COLOR);
        deleteBtn.setForeground(Color.WHITE);
        
        final int hallId = hall.getHallId();
        uploadBtn.addActionListener(e -> uploadHallImage(hallId));
        deleteBtn.addActionListener(e -> deleteHall(hallId));
        
        actionsCell.add(uploadBtn);
        actionsCell.add(deleteBtn);
        
        // Add all cells to row
        rowPanel.add(imageCell);
        rowPanel.add(nameLabel);
        rowPanel.add(capacityLabel);
        rowPanel.add(descLabel);
        rowPanel.add(facilitiesLabel);
        rowPanel.add(actionsCell);
        
        return rowPanel;
    }
    
    private Panel createAddHallForm() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(new Color(240, 240, 240));
        panel.setPreferredSize(new Dimension(900, 120));
        
        // Form title
        Label titleLabel = new Label("Add New Hall", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        Panel titlePanel = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        titlePanel.setBackground(new Color(240, 240, 240));
        titlePanel.add(titleLabel);
        
        // Form fields in grid layout
        Panel fieldsPanel = new Panel(new GridLayout(1, 6, 5, 0));
        fieldsPanel.setBackground(new Color(240, 240, 240));
        
        // Name field
        Panel namePanel = new Panel(new BorderLayout());
        namePanel.setBackground(new Color(240, 240, 240));
        Label nameLabel = new Label("Name:", Label.LEFT);
        TextField nameField = new TextField(15);
        namePanel.add(nameLabel, BorderLayout.NORTH);
        namePanel.add(nameField, BorderLayout.CENTER);
        
        // Capacity field
        Panel capacityPanel = new Panel(new BorderLayout());
        capacityPanel.setBackground(new Color(240, 240, 240));
        Label capacityLabel = new Label("Capacity:", Label.LEFT);
        TextField capacityField = new TextField(5);
        capacityPanel.add(capacityLabel, BorderLayout.NORTH);
        capacityPanel.add(capacityField, BorderLayout.CENTER);
        
        // Description field
        Panel descPanel = new Panel(new BorderLayout());
        descPanel.setBackground(new Color(240, 240, 240));
        Label descLabel = new Label("Description:", Label.LEFT);
        TextArea descField = new TextArea(2, 15);
        descPanel.add(descLabel, BorderLayout.NORTH);
        descPanel.add(descField, BorderLayout.CENTER);
        
        // Facilities field
        Panel facilitiesPanel = new Panel(new BorderLayout());
        facilitiesPanel.setBackground(new Color(240, 240, 240));
        Label facilitiesLabel = new Label("Facilities:", Label.LEFT);
        TextField facilitiesField = new TextField(15);
        facilitiesPanel.add(facilitiesLabel, BorderLayout.NORTH);
        facilitiesPanel.add(facilitiesField, BorderLayout.CENTER);
        
        // Image upload
        Panel imagePanel = new Panel(new BorderLayout());
        imagePanel.setBackground(new Color(240, 240, 240));
        Label imageLabel = new Label("Image:", Label.LEFT);
        Button imageButton = new Button("Select Image");
        imageButton.setBackground(PRIMARY_COLOR);
        imageButton.setForeground(Color.WHITE);
        Label imagePathLabel = new Label("No image selected", Label.LEFT);
        imagePathLabel.setForeground(TEXT_SECONDARY);
        
        Panel imageBtnPanel = new Panel(new BorderLayout());
        imageBtnPanel.setBackground(new Color(240, 240, 240));
        imageBtnPanel.add(imageButton, BorderLayout.WEST);
        imageBtnPanel.add(imagePathLabel, BorderLayout.CENTER);
        
        imagePanel.add(imageLabel, BorderLayout.NORTH);
        imagePanel.add(imageBtnPanel, BorderLayout.CENTER);
        
        // Submit button
        Panel submitPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        submitPanel.setBackground(new Color(240, 240, 240));
        Button submitButton = new Button("Add Hall");
        submitButton.setFont(new Font("Arial", Font.BOLD, 14));
        submitButton.setBackground(SUCCESS_COLOR);
        submitButton.setForeground(Color.WHITE);
        submitPanel.add(submitButton);
        
        // Add all fields to panel
        fieldsPanel.add(namePanel);
        fieldsPanel.add(capacityPanel);
        fieldsPanel.add(descPanel);
        fieldsPanel.add(facilitiesPanel);
        fieldsPanel.add(imagePanel);
        fieldsPanel.add(submitPanel);
        
        // File selection variable
        final File[] selectedImageFile = {null};
        
        // Image button action
        imageButton.addActionListener(e -> {
            FileDialog fileDialog = new FileDialog(AdminDashboard.this, "Select Hall Image", FileDialog.LOAD);
            fileDialog.setFilenameFilter((dir, name) -> {
                String lowercaseName = name.toLowerCase();
                return lowercaseName.endsWith(".jpg") || lowercaseName.endsWith(".jpeg")
                        || lowercaseName.endsWith(".png") || lowercaseName.endsWith(".gif");
            });
            fileDialog.setVisible(true);

            String directory = fileDialog.getDirectory();
            String filename = fileDialog.getFile();

            if (filename != null) {
                selectedImageFile[0] = new File(directory, filename);
                imagePathLabel.setText(filename);
            }
        });
        
        // Submit button action
        submitButton.addActionListener(e -> {
            // Validate input
            String name = nameField.getText().trim();
            String capacityStr = capacityField.getText().trim();
            String description = descField.getText().trim();
            String facilities = facilitiesField.getText().trim();

            if (name.isEmpty() || capacityStr.isEmpty()) {
                showMessageDialog("Error", "Hall name and capacity are required fields.", DANGER_COLOR);
                return;
            }

            // Parse capacity
            int capacity;
            try {
                capacity = Integer.parseInt(capacityStr);
                if (capacity <= 0) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException ex) {
                showMessageDialog("Error", "Capacity must be a positive number.", DANGER_COLOR);
                return;
            }

            // Save image if selected
            String imagePath = null;
            if (selectedImageFile[0] != null) {
                try {
                    imagePath = ImageManager.saveHallImage(selectedImageFile[0]);
                } catch (IOException ex) {
                    showMessageDialog("Error", "Failed to save image: " + ex.getMessage(), DANGER_COLOR);
                    return;
                }
            }

            // Create new hall
            Hall newHall = new Hall(name, capacity, description, facilities, imagePath);

            // Add to database
            HallDAO hallDao = new HallDAO();
            boolean success = hallDao.addHall(newHall);

            if (success) {
                showMessageDialog("Success", "Hall added successfully.", SUCCESS_COLOR);

                // Clear form
                nameField.setText("");
                capacityField.setText("");
                descField.setText("");
                facilitiesField.setText("");
                imagePathLabel.setText("No image selected");
                selectedImageFile[0] = null;

                // Refresh halls
                refreshHalls();
            } else {
                showMessageDialog("Error", "Failed to add hall. Please try again.", DANGER_COLOR);
            }
        });
        
        // Add title and fields to panel
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(fieldsPanel, BorderLayout.CENTER);
        
        return panel;
    }

    private Panel createPendingBookingsPanel() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(HEADER_COLOR);
        panel.setName(PENDING_BOOKINGS_PANEL);
        
        // Title panel
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(PANEL_BG);
        
        Label titleLabel = new Label("Pending Booking Requests", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(TEXT_COLOR);
        
        Panel titleWrapper = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        titleWrapper.setBackground(PANEL_BG);
        titleWrapper.add(titleLabel);
        
        // Refresh button
        Button refreshButton = new Button("Refresh");
        refreshButton.setBackground(ACCENT_COLOR);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.addActionListener(e -> refreshPendingBookings());
        
        Panel buttonWrapper = new Panel(new FlowLayout(FlowLayout.RIGHT, 20, 15));
        buttonWrapper.setBackground(PANEL_BG);
        buttonWrapper.add(refreshButton);
        
        titlePanel.add(titleWrapper, BorderLayout.WEST);
        titlePanel.add(buttonWrapper, BorderLayout.EAST);
        
        // Content panel
        Panel contentPanel = new Panel(new BorderLayout());
        contentPanel.setBackground(HEADER_COLOR);
        
        if (pendingBookings.isEmpty()) {
            // Empty state
            Panel emptyPanel = new Panel(new BorderLayout());
            emptyPanel.setBackground(PANEL_BG);
            
            Label emptyLabel = new Label("No pending booking requests", Label.CENTER);
            emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            
            emptyPanel.add(emptyLabel, BorderLayout.CENTER);
            contentPanel.add(emptyPanel, BorderLayout.CENTER);
        } else {
            // Table header
            Panel headerPanel = new Panel(new GridLayout(1, 7));
            headerPanel.setBackground(PRIMARY_COLOR);
            
            String[] headers = {"Hall", "User", "Date", "Time", "Event", "Requested On", "Actions"};
            for (String header : headers) {
                Label headerLabel = new Label(header, Label.CENTER);
                headerLabel.setForeground(Color.WHITE);
                headerLabel.setFont(new Font("Arial", Font.BOLD, 14));
                headerPanel.add(headerLabel);
            }
            
            // Booking rows
            Panel bookingsPanel = new Panel();
            bookingsPanel.setLayout(new BoxLayout(bookingsPanel, BoxLayout.Y_AXIS));
            bookingsPanel.setBackground(HEADER_COLOR);
            
            for (Booking booking : pendingBookings) {
                Panel bookingRow = createPendingBookingRow(booking);
                bookingsPanel.add(bookingRow);
                
                // Add separator
                Panel separator = new Panel();
                separator.setPreferredSize(new Dimension(1, 1));
                separator.setBackground(new Color(220, 220, 220));
                bookingsPanel.add(separator);
            }
            
            // Add scrollability
            ScrollPane scrollPane = new ScrollPane();
            scrollPane.add(bookingsPanel);
            
            Panel bookingsContainer = new Panel(new BorderLayout());
            bookingsContainer.add(headerPanel, BorderLayout.NORTH);
            bookingsContainer.add(scrollPane, BorderLayout.CENTER);
            
            contentPanel.add(bookingsContainer, BorderLayout.CENTER);
        }
        
        // Add to main panel
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private Panel createPendingBookingRow(Booking booking) {
        Panel rowPanel = new Panel(new GridLayout(1, 7));
        rowPanel.setBackground(PANEL_BG);
        
        // Hall name
        Label hallLabel = new Label(booking.getHallName(), Label.CENTER);
        hallLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // User name
        Label userLabel = new Label(booking.getUserName(), Label.CENTER);
        userLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Date
        Label dateLabel = new Label(booking.getBookingDate().toString(), Label.CENTER);
        dateLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Time
        Label timeLabel = new Label(booking.getStartTime() + " - " + booking.getEndTime(), Label.CENTER);
        timeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Event
        Label eventLabel = new Label(booking.getEventName(), Label.CENTER);
        eventLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Created date
        Label createdLabel = new Label(booking.getCreatedAt().toString(), Label.CENTER);
        createdLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Actions
        Panel actionsCell = new Panel(new FlowLayout(FlowLayout.CENTER));
        actionsCell.setBackground(PANEL_BG);
        
        Button approveBtn = new Button("Approve");
        approveBtn.setBackground(SUCCESS_COLOR);
        approveBtn.setForeground(Color.WHITE);
        
        Button declineBtn = new Button("Decline");
        declineBtn.setBackground(DANGER_COLOR);
        declineBtn.setForeground(Color.WHITE);
        
        // Add action listeners
        final int bookingId = booking.getBookingId();
        approveBtn.addActionListener(e -> approveBooking(bookingId, true));
        declineBtn.addActionListener(e -> declineBooking(bookingId, true));
        
        actionsCell.add(approveBtn);
        actionsCell.add(declineBtn);
        
        // Add cells to row
        rowPanel.add(hallLabel);
        rowPanel.add(userLabel);
        rowPanel.add(dateLabel);
        rowPanel.add(timeLabel);
        rowPanel.add(eventLabel);
        rowPanel.add(createdLabel);
        rowPanel.add(actionsCell);
        
        return rowPanel;
    }

    private Panel createAllBookingsPanel() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(HEADER_COLOR);
        panel.setName(ALL_BOOKINGS_PANEL);
        
        // Title panel
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(PANEL_BG);
        
        Label titleLabel = new Label("All Bookings", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(TEXT_COLOR);
        
        Panel titleWrapper = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        titleWrapper.setBackground(PANEL_BG);
        titleWrapper.add(titleLabel);
        
        // Filter and refresh
        Panel controlPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        controlPanel.setBackground(PANEL_BG);
        
        Label filterLabel = new Label("Filter by status:");
        filterLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        Choice statusFilter = new Choice();
        statusFilter.add("All Statuses");
        statusFilter.add("Pending");
        statusFilter.add("Approved");
        statusFilter.add("Rejected");
        statusFilter.add("Cancelled");
        
        Button refreshButton = new Button("Refresh");
        refreshButton.setBackground(ACCENT_COLOR);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.addActionListener(e -> refreshAllBookings());
        
        controlPanel.add(filterLabel);
        controlPanel.add(statusFilter);
        controlPanel.add(refreshButton);
        
        titlePanel.add(titleWrapper, BorderLayout.WEST);
        titlePanel.add(controlPanel, BorderLayout.EAST);
        
        // Content panel
        Panel contentPanel = new Panel(new BorderLayout());
        contentPanel.setBackground(HEADER_COLOR);
        
        if (allBookings.isEmpty()) {
            // Empty state
            Panel emptyPanel = new Panel(new BorderLayout());
            emptyPanel.setBackground(PANEL_BG);
            
            Label emptyLabel = new Label("No bookings found", Label.CENTER);
            emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            
            emptyPanel.add(emptyLabel, BorderLayout.CENTER);
            contentPanel.add(emptyPanel, BorderLayout.CENTER);
        } else {
            // Table header
            Panel headerPanel = new Panel(new GridLayout(1, 7));
            headerPanel.setBackground(PRIMARY_COLOR);
            
            String[] headers = {"Hall", "User", "Date", "Time", "Event", "Status", "Actions"};
            for (String header : headers) {
                Label headerLabel = new Label(header, Label.CENTER);
                headerLabel.setForeground(Color.WHITE);
                headerLabel.setFont(new Font("Arial", Font.BOLD, 14));
                headerPanel.add(headerLabel);
            }
            
            // Booking rows
            Panel bookingsPanel = new Panel();
            bookingsPanel.setLayout(new BoxLayout(bookingsPanel, BoxLayout.Y_AXIS));
            bookingsPanel.setBackground(HEADER_COLOR);
            
            for (Booking booking : allBookings) {
                Panel bookingRow = createBookingRow(booking);
                bookingsPanel.add(bookingRow);
                
                // Add separator
                Panel separator = new Panel();
                separator.setPreferredSize(new Dimension(1, 1));
                separator.setBackground(new Color(220, 220, 220));
                bookingsPanel.add(separator);
            }
            
            // Add scrollability
            ScrollPane scrollPane = new ScrollPane();
            scrollPane.add(bookingsPanel);
            
            Panel bookingsContainer = new Panel(new BorderLayout());
            bookingsContainer.add(headerPanel, BorderLayout.NORTH);
            bookingsContainer.add(scrollPane, BorderLayout.CENTER);
            
            contentPanel.add(bookingsContainer, BorderLayout.CENTER);
            
            // Add filter functionality
                        statusFilter.addItemListener(e -> {
                String selected = statusFilter.getSelectedItem();
                if ("All Statuses".equals(selected)) {
                    // Just refresh to show all bookings
                    refreshAllBookings();
                    return;
                }
                
                // Filter bookings by status
                BookingDAO bookingDao = new BookingDAO();
                allBookings = bookingDao.getBookingsByStatus(selected.toLowerCase());
                
                // Update the panel to show filtered bookings
                refreshAllBookings();
            });
        }
        
        // Add to main panel
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private Panel createBookingRow(Booking booking) {
        Panel rowPanel = new Panel(new GridLayout(1, 7));
        rowPanel.setBackground(PANEL_BG);
        
        // Hall name
        Label hallLabel = new Label(booking.getHallName(), Label.CENTER);
        hallLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // User name
        Label userLabel = new Label(booking.getUserName(), Label.CENTER);
        userLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Date
        Label dateLabel = new Label(booking.getBookingDate().toString(), Label.CENTER);
        dateLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Time
        Label timeLabel = new Label(booking.getStartTime() + " - " + booking.getEndTime(), Label.CENTER);
        timeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Event
        Label eventLabel = new Label(booking.getEventName(), Label.CENTER);
        eventLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Status with color
        Label statusLabel = new Label(capitalizeFirstLetter(booking.getStatus()), Label.CENTER);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        // Color based on status
        if ("approved".equals(booking.getStatus())) {
            statusLabel.setForeground(SUCCESS_COLOR);
        } else if ("rejected".equals(booking.getStatus()) || "declined".equals(booking.getStatus())) {
            statusLabel.setForeground(DANGER_COLOR);
        } else if ("cancelled".equals(booking.getStatus())) {
            statusLabel.setForeground(TEXT_SECONDARY);
        } else {
            statusLabel.setForeground(WARNING_COLOR); // Pending
        }
        
        // Actions
        Panel actionsCell = new Panel(new FlowLayout(FlowLayout.CENTER));
        actionsCell.setBackground(PANEL_BG);
        
        if ("pending".equals(booking.getStatus())) {
            // For pending bookings, show approve/decline
            Button approveBtn = new Button("Approve");
            approveBtn.setBackground(SUCCESS_COLOR);
            approveBtn.setForeground(Color.WHITE);
            
            Button declineBtn = new Button("Decline");
            declineBtn.setBackground(DANGER_COLOR);
            declineBtn.setForeground(Color.WHITE);
            
            final int bookingId = booking.getBookingId();
            approveBtn.addActionListener(e -> approveBooking(bookingId, false));
            declineBtn.addActionListener(e -> declineBooking(bookingId, false));
            
            actionsCell.add(approveBtn);
            actionsCell.add(declineBtn);
        } else {
            // For other statuses, show view details
            Button viewBtn = new Button("View Details");
            viewBtn.setBackground(ACCENT_COLOR);
            viewBtn.setForeground(Color.WHITE);
            
            viewBtn.addActionListener(e -> viewBookingDetails(booking));
            
            actionsCell.add(viewBtn);
        }
        
        // Add cells to row
        rowPanel.add(hallLabel);
        rowPanel.add(userLabel);
        rowPanel.add(dateLabel);
        rowPanel.add(timeLabel);
        rowPanel.add(eventLabel);
        rowPanel.add(statusLabel);
        rowPanel.add(actionsCell);
        
        return rowPanel;
    }

    private Panel createManageUsersPanel() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(HEADER_COLOR);
        panel.setName(MANAGE_USERS_PANEL);
        
        // Title panel
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(PANEL_BG);
        
        Label titleLabel = new Label("Manage Users", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(TEXT_COLOR);
        
        Panel titleWrapper = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        titleWrapper.setBackground(PANEL_BG);
        titleWrapper.add(titleLabel);
        
        // Search and refresh
        Panel controlPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        controlPanel.setBackground(PANEL_BG);
        
        TextField searchField = new TextField(20);
        Button searchButton = new Button("Search");
        searchButton.setBackground(ACCENT_COLOR);
        searchButton.setForeground(Color.WHITE);
        
        Button refreshButton = new Button("Refresh");
        refreshButton.setBackground(SECONDARY_COLOR);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.addActionListener(e -> refreshUsers());
        
        controlPanel.add(searchField);
        controlPanel.add(searchButton);
        controlPanel.add(refreshButton);
        
        titlePanel.add(titleWrapper, BorderLayout.WEST);
        titlePanel.add(controlPanel, BorderLayout.EAST);
        
        // Content panel
        Panel contentPanel = new Panel(new BorderLayout());
        contentPanel.setBackground(HEADER_COLOR);
        
        if (userList.isEmpty()) {
            // Empty state
            Panel emptyPanel = new Panel(new BorderLayout());
            emptyPanel.setBackground(PANEL_BG);
            
            Label emptyLabel = new Label("No users found", Label.CENTER);
            emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
            
            emptyPanel.add(emptyLabel, BorderLayout.CENTER);
            contentPanel.add(emptyPanel, BorderLayout.CENTER);
        } else {
            // Table header
            Panel headerPanel = new Panel(new GridLayout(1, 5));
            headerPanel.setBackground(PRIMARY_COLOR);
            
            String[] headers = {"ID", "Username", "Email", "Full Name", "Role"};
            for (String header : headers) {
                Label headerLabel = new Label(header, Label.CENTER);
                headerLabel.setForeground(Color.WHITE);
                headerLabel.setFont(new Font("Arial", Font.BOLD, 14));
                headerPanel.add(headerLabel);
            }
            
            // User rows
            Panel usersPanel = new Panel();
            usersPanel.setLayout(new BoxLayout(usersPanel, BoxLayout.Y_AXIS));
            usersPanel.setBackground(HEADER_COLOR);
            
            for (User user : userList) {
                Panel userRow = createUserRow(user);
                usersPanel.add(userRow);
                
                // Add separator
                Panel separator = new Panel();
                separator.setPreferredSize(new Dimension(1, 1));
                separator.setBackground(new Color(220, 220, 220));
                usersPanel.add(separator);
            }
            
            // Add scrollability
            ScrollPane scrollPane = new ScrollPane();
            scrollPane.add(usersPanel);
            
            Panel usersContainer = new Panel(new BorderLayout());
            usersContainer.add(headerPanel, BorderLayout.NORTH);
            usersContainer.add(scrollPane, BorderLayout.CENTER);
            
            contentPanel.add(usersContainer, BorderLayout.CENTER);
            
            // Add search functionality
            searchButton.addActionListener(e -> {
                String term = searchField.getText().trim().toLowerCase();
                if (term.isEmpty()) {
                    refreshUsers();
                    return;
                }
                
                // Filter users by search term
                UserDAO userDao = new UserDAO();
                userList = userDao.searchUsers(term);
                
                // Refresh panel
                refreshUsers();
            });
        }
        
        // Add to main panel
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    private Panel createUserRow(User user) {
        Panel rowPanel = new Panel(new GridLayout(1, 5));
        rowPanel.setBackground(PANEL_BG);
        
        // User ID
        Label idLabel = new Label(String.valueOf(user.getUserId()), Label.CENTER);
        idLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Username
        Label usernameLabel = new Label(user.getUsername(), Label.CENTER);
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Email
        Label emailLabel = new Label(user.getEmail(), Label.CENTER);
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Full name
        Label nameLabel = new Label(user.getFullName(), Label.CENTER);
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Role
        Label roleLabel = new Label(user.isAdmin() ? "Admin" : "User", Label.CENTER);
        roleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        roleLabel.setForeground(user.isAdmin() ? ACCENT_COLOR : TEXT_SECONDARY);
        
        // Add cells to row
        rowPanel.add(idLabel);
        rowPanel.add(usernameLabel);
        rowPanel.add(emailLabel);
        rowPanel.add(nameLabel);
        rowPanel.add(roleLabel);
        
        return rowPanel;
    }

private Panel createEventCalendarPanel() {
    Panel panel = new Panel(new BorderLayout());
    panel.setBackground(HEADER_COLOR);
    panel.setName(EVENT_CALENDAR_PANEL);
    
    // Title panel
    Panel headerContainer = new Panel(new BorderLayout());
    headerContainer.setBackground(Color.WHITE);
    
    Label titleLabel = new Label("Event Calendar", Label.LEFT);
    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
    titleLabel.setForeground(TEXT_COLOR);
    
    Panel titleWrapper = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 15));
    titleWrapper.setBackground(Color.WHITE);
    titleWrapper.add(titleLabel);
    
    // Refresh button
    Button refreshButton = new Button("Refresh Calendar");
    refreshButton.setBackground(new Color(59, 89, 152)); // Blue color matching the UI
    refreshButton.setForeground(Color.WHITE);
    refreshButton.addActionListener(e -> refreshCalendar());
    
    Panel buttonWrapper = new Panel(new FlowLayout(FlowLayout.RIGHT, 20, 15));
    buttonWrapper.setBackground(Color.WHITE);
    buttonWrapper.add(refreshButton);
    
    headerContainer.add(titleWrapper, BorderLayout.WEST);
    headerContainer.add(buttonWrapper, BorderLayout.EAST);
    
    // Content panel
    Panel contentPanel = new Panel(new BorderLayout());
    contentPanel.setBackground(Color.WHITE);
    
    // Get upcoming approved bookings
    BookingDAO bookingDao = new BookingDAO();
    List<Booking> upcomingBookings = bookingDao.getUpcomingApprovedBookings();
    
    if (upcomingBookings.isEmpty()) {
        // Empty state
        Panel emptyPanel = new Panel(new BorderLayout());
        emptyPanel.setBackground(Color.WHITE);
        
        Label emptyLabel = new Label("No upcoming events scheduled", Label.CENTER);
        emptyLabel.setFont(new Font("Arial", Font.ITALIC, 16));
        
        emptyPanel.add(emptyLabel, BorderLayout.CENTER);
        contentPanel.add(emptyPanel, BorderLayout.CENTER);
    } else {
        // Group events by date
        Map<Date, List<Booking>> bookingsByDate = new TreeMap<>();
        for (Booking booking : upcomingBookings) {
            Date date = booking.getBookingDate();
            if (!bookingsByDate.containsKey(date)) {
                bookingsByDate.put(date, new ArrayList<>());
            }
            bookingsByDate.get(date).add(booking);
        }
        
        // Create calendar view
        Panel calendarPanel = new Panel();
        calendarPanel.setLayout(new BoxLayout(calendarPanel, BoxLayout.Y_AXIS));
        calendarPanel.setBackground(Color.WHITE);
        
        // Add date headers and events
        for (Map.Entry<Date, List<Booking>> entry : bookingsByDate.entrySet()) {
            Date date = entry.getKey();
            List<Booking> dayBookings = entry.getValue();
            
            // Date header
            Panel dateHeaderPanel = new Panel(new BorderLayout());
            dateHeaderPanel.setBackground(new Color(59, 89, 152)); // Blue header color matching the UI
            
            SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d, yyyy");
            Label dateLabel = new Label(dateFormat.format(date), Label.LEFT);
            dateLabel.setFont(new Font("Arial", Font.BOLD, 16));
            dateLabel.setForeground(Color.WHITE);
            
            Panel datePadding = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 10));
            datePadding.setBackground(new Color(59, 89, 152));
            datePadding.add(dateLabel);
            
            dateHeaderPanel.add(datePadding, BorderLayout.CENTER);
            calendarPanel.add(dateHeaderPanel);
            
            // Events for this date
            for (Booking booking : dayBookings) {
                Panel eventPanel = new Panel(new BorderLayout());
                eventPanel.setBackground(Color.WHITE);
                
                // Time column
                Panel timeCol = new Panel(new BorderLayout());
                timeCol.setBackground(new Color(240, 240, 240));
                timeCol.setPreferredSize(new Dimension(150, 0));
                
                // Format the time correctly (10:45:00 - 12:30:00)
                Label timeLabel = new Label(booking.getStartTime() + " - " + booking.getEndTime(), Label.CENTER);
                timeLabel.setFont(new Font("Arial", Font.BOLD, 14));
                
                timeCol.add(timeLabel, BorderLayout.CENTER);
                
                // Event details
                Panel detailsPanel = new Panel(new BorderLayout());
                detailsPanel.setBackground(Color.WHITE);
                
                Label eventTitleLabel = new Label(booking.getEventName(), Label.LEFT);
                eventTitleLabel.setFont(new Font("Arial", Font.BOLD, 16));
                
                Panel locationPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
                locationPanel.setBackground(Color.WHITE);
                
                Label locationLabel = new Label("Location: " + booking.getHallName());
                locationLabel.setFont(new Font("Arial", Font.ITALIC, 14));
                locationLabel.setForeground(new Color(59, 89, 152));
                
                Label organizerLabel = new Label("Organizer: " + booking.getUserName());
                organizerLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                
                locationPanel.add(locationLabel);
                locationPanel.add(new Label(" | "));
                locationPanel.add(organizerLabel);
                
                Panel titleInfoPanel = new Panel(new BorderLayout());
                titleInfoPanel.setBackground(Color.WHITE);
                titleInfoPanel.add(eventTitleLabel, BorderLayout.NORTH);
                titleInfoPanel.add(locationPanel, BorderLayout.CENTER);
                
                // Description if available
                if (booking.getEventDescription() != null && !booking.getEventDescription().isEmpty()) {
                    Label descLabel = new Label(booking.getEventDescription(), Label.LEFT);
                    descLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                    descLabel.setForeground(Color.DARK_GRAY);
                    
                    titleInfoPanel.add(descLabel, BorderLayout.SOUTH);
                }
                
                detailsPanel.add(titleInfoPanel, BorderLayout.CENTER);
                
                // Action buttons
                Panel actionPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
                actionPanel.setBackground(Color.WHITE);
                
                Button viewBtn = new Button("View Details");
                viewBtn.setBackground(new Color(59, 89, 152));
                viewBtn.setForeground(Color.WHITE);
                viewBtn.addActionListener(e -> viewBookingDetails(booking));
                
                actionPanel.add(viewBtn);
                detailsPanel.add(actionPanel, BorderLayout.EAST);
                
                // Add to event panel with padding
                Panel paddedDetails = new Panel(new BorderLayout(10, 10));
                paddedDetails.setBackground(Color.WHITE);
                paddedDetails.add(detailsPanel, BorderLayout.CENTER);
                
                eventPanel.add(timeCol, BorderLayout.WEST);
                eventPanel.add(paddedDetails, BorderLayout.CENTER);
                
                calendarPanel.add(eventPanel);
                
                // Add separator
                Panel separator = new Panel();
                separator.setPreferredSize(new Dimension(1, 1));
                separator.setBackground(new Color(220, 220, 220));
                calendarPanel.add(separator);
            }
            
            // Add spacing between dates
            Panel dateSpacer = new Panel();
            dateSpacer.setPreferredSize(new Dimension(1, 20));
            dateSpacer.setBackground(Color.WHITE);
            calendarPanel.add(dateSpacer);
        }
        
        // Add scrollability
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.add(calendarPanel);
        
        contentPanel.add(scrollPane, BorderLayout.CENTER);
    }
    
    // Add to main panel
    panel.add(headerContainer, BorderLayout.NORTH);
    panel.add(contentPanel, BorderLayout.CENTER);
    
    return panel;
}


    private Panel createFeedbackPanel() {
        Panel panel = new Panel(new BorderLayout());
        panel.setBackground(HEADER_COLOR);
        panel.setName(FEEDBACK_PANEL);
        
        // Title panel
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(PANEL_BG);
        
        Label titleLabel = new Label("Feedback & Ratings", Label.LEFT);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(TEXT_COLOR);
        
        Panel titleWrapper = new Panel(new FlowLayout(FlowLayout.LEFT, 20, 15));
        titleWrapper.setBackground(PANEL_BG);
        titleWrapper.add(titleLabel);
        
        // Refresh button
        Button refreshButton = new Button("Refresh");
        refreshButton.setBackground(ACCENT_COLOR);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.addActionListener(e -> refreshFeedback());
        
        Panel buttonWrapper = new Panel(new FlowLayout(FlowLayout.RIGHT, 20, 15));
        buttonWrapper.setBackground(PANEL_BG);
        buttonWrapper.add(refreshButton);
        
        titlePanel.add(titleWrapper, BorderLayout.WEST);
        titlePanel.add(buttonWrapper, BorderLayout.EAST);
        
        // Content panel - use the existing FeedbackListPanel
        FeedbackListPanel feedbackListPanel = new FeedbackListPanel(this, true);
        
        // Add to main panel
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(feedbackListPanel, BorderLayout.CENTER);
        
        return panel;
    }

    // Refresh methods
    private void refreshPendingBookings() {
        BookingDAO bookingDao = new BookingDAO();
        pendingBookings = bookingDao.getPendingBookings();
        
        // Replace the panel in main container
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            Component comp = mainPanel.getComponent(i);
            if (comp instanceof Panel && comp.getName() != null && 
                comp.getName().equals(PENDING_BOOKINGS_PANEL)) {
                mainPanel.remove(i);
                mainPanel.add(createPendingBookingsPanel(), PENDING_BOOKINGS_PANEL, i);
                break;
            }
        }
        
        cardLayout.show(mainPanel, PENDING_BOOKINGS_PANEL);
    }
    
    private void refreshAllBookings() {
        BookingDAO bookingDao = new BookingDAO();
        allBookings = bookingDao.getAllBookings();
        
        // Replace the panel in main container
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            Component comp = mainPanel.getComponent(i);
            if (comp instanceof Panel && comp.getName() != null && 
                comp.getName().equals(ALL_BOOKINGS_PANEL)) {
                mainPanel.remove(i);
                mainPanel.add(createAllBookingsPanel(), ALL_BOOKINGS_PANEL, i);
                break;
            }
        }
        
        cardLayout.show(mainPanel, ALL_BOOKINGS_PANEL);
    }
    
    private void refreshHalls() {
        HallDAO hallDao = new HallDAO();
        hallList = hallDao.getAllHalls();
        
        // Replace the panel in main container
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            Component comp = mainPanel.getComponent(i);
            if (comp instanceof Panel && comp.getName() != null && 
                comp.getName().equals(MANAGE_HALLS_PANEL)) {
                mainPanel.remove(i);
                mainPanel.add(createManageHallsPanel(), MANAGE_HALLS_PANEL, i);
                break;
            }
        }
        
        cardLayout.show(mainPanel, MANAGE_HALLS_PANEL);
    }
    
    private void refreshUsers() {
        UserDAO userDao = new UserDAO();
        userList = userDao.getAllUsers();
        
        // Replace the panel in main container
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            Component comp = mainPanel.getComponent(i);
            if (comp instanceof Panel && comp.getName() != null && 
                comp.getName().equals(MANAGE_USERS_PANEL)) {
                mainPanel.remove(i);
                mainPanel.add(createManageUsersPanel(), MANAGE_USERS_PANEL, i);
                break;
            }
        }
        
        cardLayout.show(mainPanel, MANAGE_USERS_PANEL);
    }
    
    private void refreshCalendar() {
        // Replace the panel in main container
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            Component comp = mainPanel.getComponent(i);
            if (comp instanceof Panel && comp.getName() != null && 
                comp.getName().equals(EVENT_CALENDAR_PANEL)) {
                mainPanel.remove(i);
                mainPanel.add(createEventCalendarPanel(), EVENT_CALENDAR_PANEL, i);
                break;
            }
        }
        
        cardLayout.show(mainPanel, EVENT_CALENDAR_PANEL);
    }
    
    private void refreshFeedback() {
        // Replace the panel in main container
        for (int i = 0; i < mainPanel.getComponentCount(); i++) {
            Component comp = mainPanel.getComponent(i);
            if (comp instanceof Panel && comp.getName() != null && 
                comp.getName().equals(FEEDBACK_PANEL)) {
                mainPanel.remove(i);
                mainPanel.add(createFeedbackPanel(), FEEDBACK_PANEL, i);
                break;
            }
        }
        
        cardLayout.show(mainPanel, FEEDBACK_PANEL);
    }
    
    // Helper methods
    private String capitalizeFirstLetter(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        return text.substring(0, 1).toUpperCase() + text.substring(1);
    }
    
    // Actions
    private void approveBooking(int bookingId, boolean refreshPending) {
        BookingDAO bookingDao = new BookingDAO();
        boolean success = bookingDao.updateBookingStatus(bookingId, "approved");
        
        if (success) {
            showMessageDialog("Success", "Booking has been approved.", SUCCESS_COLOR);
            
            // Refresh appropriate panel
            if (refreshPending) {
                refreshPendingBookings();
            } else {
                refreshAllBookings();
            }
        } else {
            showMessageDialog("Error", "Failed to approve booking.", DANGER_COLOR);
        }
    }
    
    private void declineBooking(int bookingId, boolean refreshPending) {
        // Show dialog to get reason
        Dialog reasonDialog = new Dialog(this, "Decline Reason", true);
        reasonDialog.setSize(400, 250);
        reasonDialog.setLocationRelativeTo(this);
        reasonDialog.setLayout(new BorderLayout());
        reasonDialog.setBackground(PANEL_BG);
        
        // Dialog header
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(400, 40));
        
        Label headerLabel = new Label("Provide Decline Reason", Label.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 16));
        headerLabel.setForeground(Color.WHITE);
        
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        
        // Dialog content
        Panel contentPanel = new Panel(new BorderLayout(10, 10));
        contentPanel.setBackground(PANEL_BG);
        
        Label instructionLabel = new Label("Please provide a reason for declining:", Label.LEFT);
        instructionLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        TextArea reasonField = new TextArea("", 5, 40);
        
        contentPanel.add(instructionLabel, BorderLayout.NORTH);
        contentPanel.add(reasonField, BorderLayout.CENTER);
        
        // Buttons
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(PANEL_BG);
        
        Button submitButton = new Button("Submit");
        submitButton.setBackground(PRIMARY_COLOR);
        submitButton.setForeground(Color.WHITE);
        
        Button cancelButton = new Button("Cancel");
        cancelButton.setBackground(TEXT_SECONDARY);
        cancelButton.setForeground(Color.WHITE);
        
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        
        // Add to dialog
        reasonDialog.add(headerPanel, BorderLayout.NORTH);
        reasonDialog.add(contentPanel, BorderLayout.CENTER);
        reasonDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Button actions
        submitButton.addActionListener(e -> {
            String reason = reasonField.getText().trim();
            
            if (reason.isEmpty()) {
                // Show error
                showMessageDialog("Error", "Please provide a reason for declining.", DANGER_COLOR);
                return;
            }
            
            reasonDialog.dispose();
            
            // Update booking status with reason
            BookingDAO bookingDao = new BookingDAO();
            boolean success = bookingDao.updateBookingStatus(bookingId, "rejected", reason);
            
            if (success) {
                showMessageDialog("Success", "Booking has been declined.", SUCCESS_COLOR);
                
                // Refresh appropriate panel
                if (refreshPending) {
                    refreshPendingBookings();
                } else {
                    refreshAllBookings();
                }
            } else {
                showMessageDialog("Error", "Failed to decline booking.", DANGER_COLOR);
            }
        });
        
        cancelButton.addActionListener(e -> reasonDialog.dispose());
        
        // Show dialog
        reasonDialog.setVisible(true);
    }
    
    private void uploadHallImage(int hallId) {
        FileDialog fileDialog = new FileDialog(this, "Select Hall Image", FileDialog.LOAD);
        fileDialog.setFilenameFilter((dir, name) -> {
            String lowercaseName = name.toLowerCase();
            return lowercaseName.endsWith(".jpg") || lowercaseName.endsWith(".jpeg")
                    || lowercaseName.endsWith(".png") || lowercaseName.endsWith(".gif");
        });
        fileDialog.setVisible(true);

        String directory = fileDialog.getDirectory();
        String filename = fileDialog.getFile();

        if (filename != null) {
            File selectedFile = new File(directory, filename);

            try {
                // Save the image and get its path
                String imagePath = ImageManager.saveHallImage(selectedFile);

                // Update the hall in the database
                HallDAO hallDao = new HallDAO();
                Hall hall = hallDao.getHallById(hallId);

                if (hall != null) {
                    // Delete old image if exists
                    if (hall.getImagePath() != null && !hall.getImagePath().isEmpty()) {
                        ImageManager.deleteHallImage(hall.getImagePath());
                    }

                    // Update with new image path
                    hall.setImagePath(imagePath);
                    boolean success = hallDao.updateHall(hall);

                    if (success) {
                        showMessageDialog("Success", "Hall image updated successfully.", SUCCESS_COLOR);
                        refreshHalls();
                    } else {
                        showMessageDialog("Error", "Failed to update hall image.", DANGER_COLOR);
                    }
                }
            } catch (IOException e) {
                showMessageDialog("Error", "Failed to save image: " + e.getMessage(), DANGER_COLOR);
            }
        }
    }
    
    private void deleteHall(int hallId) {
        // Confirmation dialog
        Dialog confirmDialog = new Dialog(this, "Confirm Delete", true);
        confirmDialog.setSize(400, 180);
        confirmDialog.setLocationRelativeTo(this);
        confirmDialog.setLayout(new BorderLayout());
        confirmDialog.setBackground(PANEL_BG);
        
        // Dialog content
        Label confirmLabel = new Label("Are you sure you want to delete this hall?", Label.CENTER);
        confirmLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        Label warningLabel = new Label("This action cannot be undone!", Label.CENTER);
        warningLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        warningLabel.setForeground(DANGER_COLOR);
        
        Panel contentPanel = new Panel(new GridLayout(2, 1));
        contentPanel.setBackground(PANEL_BG);
        contentPanel.add(confirmLabel);
        contentPanel.add(warningLabel);
        
        // Buttons
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(PANEL_BG);
        
        Button yesButton = new Button("Yes, Delete");
        yesButton.setBackground(DANGER_COLOR);
        yesButton.setForeground(Color.WHITE);
        
        Button noButton = new Button("Cancel");
        noButton.setBackground(TEXT_SECONDARY);
        noButton.setForeground(Color.WHITE);
        
        buttonPanel.add(yesButton);
        buttonPanel.add(noButton);
        
        confirmDialog.add(contentPanel, BorderLayout.CENTER);
        confirmDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Button actions
        yesButton.addActionListener(e -> {
            confirmDialog.dispose();
            
            // Get hall to access image path
            HallDAO hallDao = new HallDAO();
            Hall hall = hallDao.getHallById(hallId);
            
            // Delete the hall
            boolean success = hallDao.deleteHall(hallId);
            
            if (success) {
                // Delete image if exists
                if (hall != null && hall.getImagePath() != null && !hall.getImagePath().isEmpty()) {
                    ImageManager.deleteHallImage(hall.getImagePath());
                }
                
                showMessageDialog("Success", "Hall deleted successfully.", SUCCESS_COLOR);
                refreshHalls();
            } else {
                showMessageDialog("Error", "Cannot delete hall. It may have active bookings.", DANGER_COLOR);
            }
        });
        
        noButton.addActionListener(e -> confirmDialog.dispose());
        
        confirmDialog.setVisible(true);
    }
    
    private void viewBookingDetails(Booking booking) {
        Dialog detailsDialog = new Dialog(this, "Booking Details", true);
        detailsDialog.setSize(500, 400);
        detailsDialog.setLocationRelativeTo(this);
        detailsDialog.setLayout(new BorderLayout());
        detailsDialog.setBackground(PANEL_BG);
        
        // Header
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(500, 60));
        
        Label headerLabel = new Label("Booking Details", Label.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        
        // Content
        Panel contentPanel = new Panel(new BorderLayout(10, 10));
        contentPanel.setBackground(PANEL_BG);
        
        // Event title and status
        Panel titlePanel = new Panel(new BorderLayout());
        titlePanel.setBackground(PANEL_BG);
        
        Label eventTitle = new Label("Event: " + booking.getEventName(), Label.LEFT);
        eventTitle.setFont(new Font("Arial", Font.BOLD, 18));
        
        Panel statusPanel = new Panel(new FlowLayout(FlowLayout.RIGHT));
        statusPanel.setBackground(PANEL_BG);
        
        Label statusLabel = new Label("Status: " + capitalizeFirstLetter(booking.getStatus()));
        statusLabel.setFont(new Font("Arial", Font.BOLD, 16));
        
        // Set color based on status
        if ("approved".equals(booking.getStatus())) {
            statusLabel.setForeground(SUCCESS_COLOR);
        } else if ("rejected".equals(booking.getStatus()) || "declined".equals(booking.getStatus())) {
            statusLabel.setForeground(DANGER_COLOR);
        } else if ("cancelled".equals(booking.getStatus())) {
            statusLabel.setForeground(TEXT_SECONDARY);
        } else {
            statusLabel.setForeground(WARNING_COLOR); // Pending
        }
        
        statusPanel.add(statusLabel);
        
        titlePanel.add(eventTitle, BorderLayout.WEST);
        titlePanel.add(statusPanel, BorderLayout.EAST);
        
        // Details in grid
        Panel detailsPanel = new Panel(new GridLayout(0, 2, 10, 10));
        detailsPanel.setBackground(PANEL_BG);
        
        // Add all detail rows
        addDetailField(detailsPanel, "Booking ID:", String.valueOf(booking.getBookingId()));
        addDetailField(detailsPanel, "Hall:", booking.getHallName());
        addDetailField(detailsPanel, "User:", booking.getUserName());
        addDetailField(detailsPanel, "Date:", booking.getBookingDate().toString());
        addDetailField(detailsPanel, "Time:", booking.getStartTime() + " - " + booking.getEndTime());
        
        if (booking.getEventDescription() != null && !booking.getEventDescription().isEmpty()) {
            addDetailField(detailsPanel, "Description:", booking.getEventDescription());
        }
        
        if (("rejected".equals(booking.getStatus()) || "declined".equals(booking.getStatus())) && 
            booking.getDeclineReason() != null && !booking.getDeclineReason().isEmpty()) {
            
            Label reasonLabel = new Label("Decline Reason:", Label.RIGHT);
            reasonLabel.setFont(new Font("Arial", Font.BOLD, 14));
            
            Label reasonValue = new Label(booking.getDeclineReason(), Label.LEFT);
            reasonValue.setFont(new Font("Arial", Font.ITALIC, 14));
            reasonValue.setForeground(DANGER_COLOR);
            
            detailsPanel.add(reasonLabel);
            detailsPanel.add(reasonValue);
        }
        
        addDetailField(detailsPanel, "Created At:", booking.getCreatedAt().toString());
        
        // Close button
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(PANEL_BG);
        
        Button closeButton = new Button("Close");
        closeButton.setBackground(ACCENT_COLOR);
        closeButton.setForeground(Color.WHITE);
        closeButton.addActionListener(e -> detailsDialog.dispose());
        
        buttonPanel.add(closeButton);
        
        // Add to content panel
        contentPanel.add(titlePanel, BorderLayout.NORTH);
        contentPanel.add(detailsPanel, BorderLayout.CENTER);
        
        // Add all to dialog
        detailsDialog.add(headerPanel, BorderLayout.NORTH);
        detailsDialog.add(contentPanel, BorderLayout.CENTER);
        detailsDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        detailsDialog.setVisible(true);
    }
    
    private void viewFullSizeImage(String imagePath) {
        if (imagePath == null || imagePath.isEmpty()) {
            return;
        }

        try {
            Image fullImage = ImageManager.loadHallImage(imagePath);
            if (fullImage == null) {
                return;
            }

            Dialog imageDialog = new Dialog(this, "Hall Image", true);
            imageDialog.setSize(800, 600);
            imageDialog.setLocationRelativeTo(this);
            imageDialog.setLayout(new BorderLayout());
            imageDialog.setBackground(new Color(40, 40, 40));

            // Create an image canvas that scales the image to fit
            Canvas imageCanvas = new Canvas() {
                                    @Override
                    public void paint(Graphics g) {
                        g.setColor(new Color(40, 40, 40));
                        g.fillRect(0, 0, getWidth(), getHeight());
                        
                        // Calculate scaling to fit the canvas
                        int imgWidth = fullImage.getWidth(this);
                        int imgHeight = fullImage.getHeight(this);
                        int canvasWidth = getWidth();
                        int canvasHeight = getHeight();
                        
                        double scale = Math.min(
                            (double) canvasWidth / imgWidth,
                            (double) canvasHeight / imgHeight
                        );
                        
                        int scaledWidth = (int) (imgWidth * scale);
                        int scaledHeight = (int) (imgHeight * scale);
                        
                        // Center the image
                        int x = (canvasWidth - scaledWidth) / 2;
                        int y = (canvasHeight - scaledHeight) / 2;
                        
                        g.drawImage(fullImage, x, y, scaledWidth, scaledHeight, this);
                    }
            };

            // Button panel
            Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
            buttonPanel.setBackground(new Color(40, 40, 40));
            
            Button closeButton = new Button("Close");
            closeButton.setBackground(ACCENT_COLOR);
            closeButton.setForeground(Color.WHITE);
            closeButton.setFont(new Font("Arial", Font.BOLD, 14));
            closeButton.addActionListener(e -> imageDialog.dispose());
            
            buttonPanel.add(closeButton);
            
            imageDialog.add(imageCanvas, BorderLayout.CENTER);
            imageDialog.add(buttonPanel, BorderLayout.SOUTH);
            
            imageDialog.setVisible(true);
        } catch (IOException e) {
            showMessageDialog("Error", "Failed to load image: " + e.getMessage(), DANGER_COLOR);
        }
    }
    
    // Helper method for detail fields
    private void addDetailField(Panel parent, String label, String value) {
        Label labelComp = new Label(label, Label.RIGHT);
        labelComp.setFont(new Font("Arial", Font.BOLD, 14));
        
        Label valueComp = new Label(value, Label.LEFT);
        valueComp.setFont(new Font("Arial", Font.PLAIN, 14));
        
        parent.add(labelComp);
        parent.add(valueComp);
    }
    
    // Modern dialog utility
    private void showMessageDialog(String title, String message, Color headerColor) {
        Dialog dialog = new Dialog(this, title, true);
        dialog.setSize(400, 180);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        dialog.setBackground(PANEL_BG);
        
        // Header
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(headerColor);
        headerPanel.setPreferredSize(new Dimension(400, 40));
        
        Label titleLabel = new Label(title, Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        // Message
        Panel messagePanel = new Panel(new BorderLayout());
        messagePanel.setBackground(PANEL_BG);
        
        Label messageLabel = new Label(message, Label.CENTER);
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        
        messagePanel.add(messageLabel, BorderLayout.CENTER);
        
        // Button
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(PANEL_BG);
        
        Button okButton = new Button("OK");
        okButton.setBackground(headerColor);
        okButton.setForeground(Color.WHITE);
        okButton.setFont(new Font("Arial", Font.BOLD, 14));
        okButton.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(okButton);
        
        // Add to dialog
        dialog.add(headerPanel, BorderLayout.NORTH);
        dialog.add(messagePanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.setVisible(true);
    }
    
    private void logout() {
        // Show confirmation dialog
        Dialog confirmDialog = new Dialog(this, "Confirm Logout", true);
        confirmDialog.setSize(400, 180);
        confirmDialog.setLocationRelativeTo(this);
        confirmDialog.setLayout(new BorderLayout());
        confirmDialog.setBackground(PANEL_BG);
        
        // Header
        Panel headerPanel = new Panel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(400, 40));
        
        Label titleLabel = new Label("Confirm Logout", Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);
        
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        // Message
        Panel messagePanel = new Panel(new BorderLayout());
        messagePanel.setBackground(PANEL_BG);
        
        Label messageLabel = new Label("Are you sure you want to logout?", Label.CENTER);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        messagePanel.add(messageLabel, BorderLayout.CENTER);
        
        // Buttons
        Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.setBackground(PANEL_BG);
        
        Button yesButton = new Button("Yes, Logout");
        yesButton.setBackground(DANGER_COLOR);
        yesButton.setForeground(Color.WHITE);
        yesButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        Button noButton = new Button("Cancel");
        noButton.setBackground(TEXT_SECONDARY);
        noButton.setForeground(Color.WHITE);
        noButton.setFont(new Font("Arial", Font.BOLD, 14));
        
        buttonPanel.add(yesButton);
        buttonPanel.add(noButton);
        
        yesButton.addActionListener(e -> {
            confirmDialog.dispose();
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            dispose();
        });
        
        noButton.addActionListener(e -> confirmDialog.dispose());
        
        // Add to dialog
        confirmDialog.add(headerPanel, BorderLayout.NORTH);
        confirmDialog.add(messagePanel, BorderLayout.CENTER);
        confirmDialog.add(buttonPanel, BorderLayout.SOUTH);
        
        confirmDialog.setVisible(true);
    }
}
